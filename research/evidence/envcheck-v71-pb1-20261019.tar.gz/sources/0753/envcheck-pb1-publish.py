"""Publish PB-1 only after native controls and the existing full consumer pass."""
from __future__ import annotations

import hashlib
import json
import runpy
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path('/Users/petermakhnatch/Developer/eval-lab/.worktrees/envcheck-v71-pb1-20261019')
LANE = ROOT / 'runs/envcheck-v71-pb1'
BRIDGE = Path('/Users/petermakhnatch/Developer/research-context/bridge')
NIGHT = BRIDGE / '2026-10-19-night'
DESTINATION = NIGHT / 'repairs-v7.1.json'


def sha(path):
    return 'sha256:' + hashlib.sha256(Path(path).read_bytes()).hexdigest()


def binding(path):
    return {'path': str(path), 'sha256': sha(path)}


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


admission_path = LANE / 'inputs-r3.json'
admission = json.loads(admission_path.read_bytes())
parent_path = BRIDGE / '2026-10-17-v7/heldout-v7.json'
released = json.loads(parent_path.read_bytes())
parents = {row['task_id'].rsplit('-', 1)[-1]: row['evaluation_target'] for row in released['tasks']}
freeze = runpy.run_path(str(ROOT / 'research/experiments/mimo-training-20261016/freeze.py'))
repairs, selections, sources = [], {}, {}
for task in sorted(admission['tasks']):
    candidate_path = LANE / 'candidates' / task / 'r2/candidate.json'
    candidate = json.loads(candidate_path.read_bytes())
    qualification_path = LANE / 'native-controls-r1' / f'format-code-task-{task}' / 'qualification.json'
    qualification = json.loads(qualification_path.read_bytes())
    assert qualification['qualified'] is True
    checks = {row['run']: row for row in qualification['checks']}
    reference, nop = qualification['checks'][:2]
    assert reference['status'] == nop['status'] == 'ok'
    assert reference['repeats'] == [1.0] * 3
    assert nop['repeats'] == [0.0] * 3
    reproducers = []
    for control in candidate['known_wrong_reproducers']:
        check = checks[control['run']]
        assert check['status'] == 'ok' and check['rewards'] == [0.0], check
        reproducers.append(control | {key:check.get(key) for key in ('status','rewards','error','job_dir','repeats')} | {'killed':True})
    assert any(row['validation_stage'] == 'fresh-s3' for row in reproducers)
    repair = {key:candidate[key] for key in (
        'task_id','package_path','package_digest','harbor_digest','verifier_digest',
        'parent_digest','native_record','native_record_sha256',
    )}
    repair.update(
        candidate=str(candidate_path), candidate_sha256=sha(candidate_path),
        qualification=str(qualification_path), qualification_sha256=sha(qualification_path),
        qualified_for_v7=True, status='complete', reference=reference['repeats'],
        do_nothing=nop['repeats'], reference_check=reference, do_nothing_check=nop,
        reproducers=reproducers, recorded_reproducer_count=len(reproducers),
        reproducers_killed=len(reproducers), unique_wrong_program_count=len({row['patch_sha256'] for row in reproducers}),
        fresh_replay_count=sum(row['validation_stage']=='fresh-s3' for row in reproducers),
        task_control_bindings_unchanged=True, no_original_assertion_weakened=True,
        training_allowed=False, unrepairable=[], adjudicated_correct_controls=[],
        correct_control_scope=admission['proof_limit'],
        observed_at=datetime.now(UTC).isoformat(),
    )
    selected = freeze['_successor_repair'](f'format-code-task-{task}', parents[task], repair, ROOT, sources)
    observations = selected['semantic_repair_controls']['observations']
    assert len(observations) == len(qualification['checks'])
    selections[task] = selected
    repairs.append(repair)
executions = [observation['native']['execution_id'] for selected in selections.values()
              for observation in selected['semantic_repair_controls']['observations']]
assert len(executions) == len(set(executions)) == 11
assert sum(row['unique_wrong_program_count'] for row in repairs) == 5
assert sum(row['fresh_replay_count'] for row in repairs) == 2
proof_path = LANE / 'native-consumer-proof.json'
write_new(proof_path, {'schema':'envcheck.v71.native-consumer-proof/v1',
    'status':'exact_parent_full_lineage_package_submission_and_physical_controls_verified',
    'created_at':datetime.now(UTC).isoformat(), 'selected_targets':selections,
    'physical_native_executions':len(executions), 'sources':sorted(sources.values(), key=lambda row:row['path']),
    'limits':['No scoring or training release is granted.', admission['proof_limit']]})
gate_path = LANE / 'spend-pb1-new-2usd.json'
gate = json.loads(gate_path.read_bytes())
assert gate['cap_usd'] == 2.0 and gate['executions'] == 11 and abs(gate['reserved_usd']-0.99)<1e-8
source_inputs = [binding(path) for path in (
    admission_path, parent_path, NIGHT/'v7-new-weak-graders.json',
    BRIDGE/'2026-10-17-v7/qa-task-v7-s2a-positive-confirmations-20261018.json',
    ROOT/'research/answer-keys/mimo-weak-tests-v2.1/findings-supported-v2.1.jsonl',
)]
manifest = {
    'schema':'envcheck.repairs-v7/v1', 'revision':'v7.1', 'queue_item':'PB-1',
    'created_at':datetime.now(UTC).isoformat(),
    'status':'native_qualified_awaiting_independent_release',
    'scoring_allowed':False, 'training_allowed':False, 'native_qualification_complete':True,
    'complete_count':2, 'partial_count':0, 'required_task_count':2,
    'required_tasks':[row['task_id'] for row in repairs],
    'recorded_reproducer_count':7, 'unique_wrong_program_count':5,
    'fresh_native_replay_count':2, 'adjudicated_correct_control_count':0,
    'native_control_completions_retained':11,
    'qualification_rule':'Reference [1,1,1]; nop [0,0,0]; all source-bound old/new wrongs 0; distinct fresh native replays of both new released-v7 wrongs 0; all supplied admitted correct alternates 1; no weakened assertions.',
    'source_inputs':source_inputs, 'producer_root':str(ROOT), 'repairs':repairs,
    'path_contract':'All native candidate, matrix, record, qualification, patch and script references are absolute; keep the protected producer runtime and source evidence intact.',
    'parent_release':binding(parent_path), 'native_consumer_proof':binding(proof_path),
    'new_paid_gate':binding(gate_path), 'reserved_usd':gate['reserved_usd'],
    'approved_new_cap_usd':2.0, 'reservation_is_invoice':False,
    'new_evaluation_model_calls':0,
    'independent_review':{'status':'pending_independent_grader_review','source_wrong_programs':'Independently adjudicated by QA Task; no new grader release is certified by this lane.'},
    'correct_control_scope':admission['proof_limit'],
    'notes':['Two-task delta extending the exact released-v7 parents; the released33 and train boundary are unchanged.',
             'Seven wrong control executions cover five distinct programs, including two required fresh-S3 replications.',
             'All native jobs use the owned Harbor0.24 runtime and retain actual physical execution evidence.',
             'Historical funding gates were not changed or reused. Reservations are not provider invoices.'],
}
write_new(DESTINATION, manifest)
accepted = freeze['_successor_repairs'](DESTINATION, {})
assert len(accepted['selections']) == 2
write_new(LANE/'publication-admission-proof.json', {'schema':'envcheck.v71.publication-proof/v1',
    'status':'existing_repair_handoff_consumer_accepted_both_qualified_rows',
    'created_at':datetime.now(UTC).isoformat(), 'manifest':binding(DESTINATION),
    'selected_tasks':sorted(accepted['selections']), 'native_consumer_proof':binding(proof_path)})
print(json.dumps({'manifest':str(DESTINATION), 'complete_count':2, 'unique_wrong_programs_killed':5,
    'fresh_native_replays':2, 'native_executions':11, 'reserved_usd':gate['reserved_usd'],
    'new_cap_usd':gate['cap_usd'], 'scoring_allowed':False, 'training_allowed':False}, indent=2))

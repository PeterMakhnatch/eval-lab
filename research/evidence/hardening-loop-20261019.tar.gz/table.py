"""Round table from executed evidence (no model or container calls)."""
from pathlib import Path
import collections, glob, json, math

HERE = Path(__file__).resolve().parent


def wilson(k, n, z=1.96):
    if n == 0:
        return None
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return round(max(0, c - h), 3), round(min(1, c + h), 3)


def ledger_by_prefix():
    rows = [json.loads(line) for line in (HERE / 'hosted/ledger.jsonl').read_text().splitlines() if line.strip()]
    out = collections.defaultdict(lambda: {'calls': 0, 'reserved_usd': 0.0, 'reported_usd': 0.0, 'unpriced': 0})
    for r in rows:
        key = r['call'].split('-')[0]
        o = out[key]
        o['calls'] += 1
        o['reserved_usd'] += r['reserved_usd']
        o['reported_usd'] += r.get('reported_usd') or 0.0
        o['unpriced'] += r.get('reported_usd') is None
    return dict(out)


def round_row(n):
    inputs = HERE / ('inputs.json' if n == 2 else f'inputs-r{n}.json')
    cases = json.loads(inputs.read_text())['cases']
    row = collections.Counter()
    tasks_with = set()
    for c in cases:
        p = HERE / f'round-{n}/{c["short"]}/summary.json'
        if not p.exists():
            row['not_run'] += 1
            continue
        s = json.loads(p.read_text())
        row['tasks'] += 1
        row['attacked'] += bool(s['model_calls'])
        row['graded_tasks'] += any(a.get('reward') is not None for a in s['attempts'])
        row['model_calls_recorded'] += s['model_calls']
        row['native_trials'] += s['native_trials']
        row['candidates'] += sum(1 for a in s['attempts'] if a['status'] == 'candidate')
        row['s2a_pass'] += sum(1 for a in s['attempts'] if a.get('reward') == 1.0)
        row['s2a_s3_pass'] += len(s.get('candidate_passes', []))
        fdir = HERE / f'findings/r{n}/{c["short"]}'
        probe = json.loads((fdir / 'probe.json').read_text()) if (fdir / 'probe.json').exists() else None
        disp = json.loads((fdir / 'disposition.json').read_text()) if (fdir / 'disposition.json').exists() else None
        if s.get('candidate_passes'):
            if disp:
                row['not_promoted'] += 1
            elif probe and probe['independently_verified_wrong']:
                row['verified_wrong'] += len(s['candidate_passes'])
                tasks_with.add(c['short'])
            elif probe:
                row['refuted_by_probe'] += 1
            else:
                row['pending'] += 1
        res = fdir / 'result.json'
        if res.exists():
            r = json.loads(res.read_text())
            row['repairs'] += 1
            row['qualified'] += r['qualified']
            row['qual_cells'] += len(r['rows'])
    return {'round': n, **row, 'tasks_with_verified_wrong': sorted(tasks_with)}


if __name__ == '__main__':
    rounds = sorted(int(p.name.split('-')[1]) for p in HERE.glob('round-[0-9]*') if p.is_dir())
    print(json.dumps({'rounds': [round_row(n) for n in rounds], 'llm': ledger_by_prefix(),
                      'modal': json.loads((HERE / 'modal-ledger.json').read_text()),
                      'wilson_1_17': wilson(1, 17), 'wilson_0_17': wilson(0, 17)}, indent=1))

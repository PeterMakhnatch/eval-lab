"""Fixer round driver: probe -> derive -> qualify for every finding with a parent-written spec.

findings/r<N>/<short>/spec.json: repo_path, code, command, requirement (parent-authored regression
test; never model-authored). Wrongs for qualification = this round's S2a+S3 candidates for the
task plus every earlier-round wrong program (EnvCheck candidate manifests + earlier hardening rounds).
"""
from pathlib import Path
import argparse, glob, hashlib, json, os

from evallab.registry import task_directory_digest
import fixer

HERE = Path(__file__).resolve().parent
WTS = Path('/Users/petermakhnatch/Developer/eval-lab/.worktrees')
ENVCHECK = [WTS / 'envcheck-heldout-v7-20261017/runs/envcheck-v7-20261017/candidates',
            WTS / 'envcheck-v71-pb1-20261019/runs/envcheck-v71-pb1/candidates']


def prior_controls(short: str) -> tuple[list[dict], list[dict]]:
    wrongs, corrects, seen = [], [], set()
    for root in ENVCHECK:
        for path in sorted(glob.glob(str(root / short / '*' / 'candidate.json'))):
            data = json.loads(Path(path).read_text())
            for kind, bucket in (('known_wrong_reproducers', wrongs), ('adjudicated_correct_controls', corrects)):
                for row in data.get(kind, []):
                    script = row.get('script')
                    key = (kind, row.get('patch_sha256') or row.get('script_sha256'))
                    if not script or not os.path.exists(script) or key in seen:
                        continue
                    seen.add(key)
                    bucket.append({'label': f"prior-{row.get('finding_id') or row.get('run')}", 'script': script,
                                   'finding_id': row.get('finding_id'), 'source': path,
                                   'patch_sha256': row.get('patch_sha256')})
    return wrongs, corrects


def round_wrongs(short: str, upto: int) -> list[dict]:
    """Verified wrong programs for this task from hardening rounds 2..upto (semantic patches)."""
    out = []
    for rnd in range(2, upto + 1):
        for spec_path in sorted(glob.glob(str(HERE / f'findings/r{rnd}/{short}/probe.json'))):
            probe = json.loads(Path(spec_path).read_text())
            if not probe.get('independently_verified_wrong'):
                continue
            for label in probe['wrong_labels']:
                patch = Path(probe['wrong_patches'][label]).read_text()
                out.append({'label': label, 'patch': patch, 'round': rnd})
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--round', type=int, required=True)
    p.add_argument('--task', action='append', required=True)
    p.add_argument('--parent', help='inputs json with current-round packages', default=None)
    p.add_argument('--refs', type=int, default=3)
    p.add_argument('--skip-probe', action='store_true')
    p.add_argument('--backend', choices=['modal', 'docker'], default='modal')
    args = p.parse_args()
    fixer.BACKEND = args.backend
    inputs = json.loads(Path(args.parent or (HERE / 'inputs.json')).read_text())['cases']
    for short in args.task:
        case = next(c for c in inputs if c['short'] == short)
        package = Path(case['package_path'])
        digest = task_directory_digest(package)
        assert digest == case['package_digest'], short
        fdir = HERE / f'findings/r{args.round}/{short}'
        spec = json.loads((fdir / 'spec.json').read_text())
        summary = json.loads((HERE / f'round-{args.round}/{short}/summary.json').read_text())
        wrong_patches = {f'r{args.round}-a{a}': str(HERE / f'round-{args.round}/{short}/attempt-{a}/proposal.patch')
                         for a in summary['candidate_passes']}
        wrongs = [(label, Path(path).read_text()) for label, path in wrong_patches.items()]
        if not args.skip_probe or not (fdir / 'probe.json').exists():
            record = fixer.probe(package, digest, spec, wrongs, fdir / 'probe')
            record.update(wrong_labels=list(wrong_patches), wrong_patches=wrong_patches)
            fixer.save(fdir / 'probe.json', record)
        record = json.loads((fdir / 'probe.json').read_text())
        print(json.dumps({'task': short, 'probe_arms': record['arms'], 'verified': record['independently_verified_wrong']}), flush=True)
        if not record['independently_verified_wrong']:
            continue
        if (fdir / 'variant.json').exists():  # same spec already derived (e.g. requalifying on another backend)
            variant = Path(json.loads((fdir / 'variant.json').read_text())['variant_path'])
        else:
            rec, variant = fixer.derive(package, spec, mutant_ids=list(wrong_patches), rationale=spec['requirement'])
            fixer.save(fdir / 'variant.json', {'record': rec.model_dump(mode='json'), 'variant_path': str(variant)})
        prior_w, prior_c = prior_controls(short)
        earlier = [w for w in round_wrongs(short, args.round - 1)]
        sem_wrongs = [(w['label'], w['patch']) for w in earlier] + wrongs
        result = fixer.qualify(variant, sem_wrongs, [], fdir / 'qualification', refs=args.refs,
                               script_wrongs=[(w['label'], Path(w['script']).read_text()) for w in prior_w],
                               script_corrects=[(c['label'], Path(c['script']).read_text()) for c in prior_c])
        result.update(parent_package=str(package), parent_digest=digest, prior_wrong_sources=prior_w,
                      prior_correct_sources=prior_c, earlier_round_wrongs=[w['label'] for w in earlier])
        fixer.save(fdir / 'result.json', result)
        print(json.dumps({'task': short, 'qualified': result['qualified'], 'complete': result['complete'],
                          'rows': [(r['label'], r['reward'], r['ok']) for r in result['rows']]}), flush=True)


if __name__ == '__main__':
    main()

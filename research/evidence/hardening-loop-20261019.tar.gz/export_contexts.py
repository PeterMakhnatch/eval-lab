"""Read allowlisted pristine production sources after the package healthcheck.

No reference/solution, tests or git objects are exported. One fresh airgapped container per
task. Tasks with a wave2 context are copied (same production bytes; test-only variants).
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shlex, shutil, sys
from hbackend import Backend

HERE = Path(__file__).resolve().parent
OUT = HERE / 'source-context'
READER = r'''
import hashlib,json,os,sys
root=os.path.realpath(sys.argv[1]); wanted=json.loads(sys.argv[2])
result={'root':root,'files':{},'metadata':{},'missing':[],'omitted':[]}
for rel in wanted:
    path=os.path.join(root,*rel.split('/'))
    if not os.path.isfile(path) or os.path.islink(path):
        result['missing'].append(rel);continue
    data=open(path,'rb').read(400001)
    if len(data)>400000:
        result['omitted'].append({'path':rel,'reason':'400000 byte cap'});continue
    try:text=data.decode('utf-8')
    except UnicodeError:
        result['omitted'].append({'path':rel,'reason':'not UTF-8'});continue
    result['files'][rel]=text
    result['metadata'][rel]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
print(json.dumps(result,sort_keys=True))
'''


def main() -> None:
    cases = json.loads((HERE / 'inputs.json').read_text())['cases']
    selected = set(sys.argv[1:])
    backend = Backend(repo_root=HERE.parents[1])
    for case in cases:
        short = case['short']
        if selected and short not in selected:
            continue
        dest = OUT / short / 'source-context.json'
        if dest.exists():
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        if case['wave2_context']:
            shutil.copyfile(case['wave2_context'], dest)
            print(json.dumps({'task': short, 'status': 'copied_wave2'}), flush=True)
            continue
        package = Path(case['package_path'])
        record = {'created': datetime.now(timezone.utc).isoformat(), 'task_id': case['task_id'],
                  'source_package': {'package_path': case['package_path'], 'package_digest': case['package_digest']},
                  'allowed_production_paths': case['allowed_production_paths'],
                  'reader_sha256': hashlib.sha256(READER.encode()).hexdigest(), 'model_calls': 0}
        try:
            with backend.slot('hardening-r2/source/' + short):
                image, _ = backend._ensure_images(package, case['package_digest'])
                workdir = backend.patch_workdir(package)
                command = 'python3 -c ' + shlex.quote(READER) + ' ' + shlex.quote(workdir) + ' ' + shlex.quote(json.dumps(case['allowed_production_paths']))
                result = backend._run_probe(package, image, command, timeout=400)
            record.update(image=image, returncode=result.returncode, stderr=result.stderr[-4000:])
            if result.returncode:
                record.update(status='unmeasured_source_probe_failed', stdout=result.stdout[-4000:])
            else:
                record.update(json.loads(result.stdout.strip().splitlines()[-1]))
                record['status'] = 'source_context_measured' if record['files'] else 'no_allowed_production_source_found'
        except Exception as exc:  # retained as unmeasured, never as a clean result
            record.update(status='unmeasured_source_probe_exception', exception=f'{type(exc).__name__}: {exc}')
        dest.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
        print(json.dumps({'task': short, 'status': record['status'], 'files': list(record.get('files', {})),
                          'missing': record.get('missing'), 'err': record.get('exception') or record.get('stderr', '')[-300:]}), flush=True)


if __name__ == '__main__':
    main()

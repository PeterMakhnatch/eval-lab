# @7 baseline: hold errexit off so every test phase runs on pristine.
set -T 2>/dev/null || true
shopt -s extdebug 2>/dev/null || true
trap 'set +e 2>/dev/null || true' DEBUG 2>/dev/null || true

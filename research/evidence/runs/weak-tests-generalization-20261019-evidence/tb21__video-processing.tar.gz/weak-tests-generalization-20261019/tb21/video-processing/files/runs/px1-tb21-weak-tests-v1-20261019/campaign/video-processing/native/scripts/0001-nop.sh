#!/usr/bin/env bash
# envcheck: capture-base
# expect: 0
set -e
mkdir -p /logs/artifacts/envcheck-capture/.ref-subset-states
if [ -L / ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -L /app ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -L /app/jump_analyzer.py ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -e /app/jump_analyzer.py ] && [ ! -f /app/jump_analyzer.py ]; then echo 'ref-subset: target is not a regular file' >&2; exit 97; fi
if [ -f /app/jump_analyzer.py ]; then printf 'present\n'; else printf 'absent\n'; fi > /logs/artifacts/envcheck-capture/.ref-subset-states/0
if [ -f /app/jump_analyzer.py ]; then stat -c '%a' -- /app/jump_analyzer.py > /logs/artifacts/envcheck-capture/.ref-subset-states/0.mode; fi
#!/usr/bin/env bash
# envcheck: capture-base
# expect: 0
if [ -e /app/jump_analyzer.py ]; then mkdir -p /logs/artifacts/envcheck-capture/app && cp -a /app/jump_analyzer.py /logs/artifacts/envcheck-capture/app/jump_analyzer.py; fi
printf 'complete\n' > /logs/artifacts/envcheck-capture/.ref-subset-states/complete

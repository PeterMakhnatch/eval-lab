"""Build the committed custody capsule: producers, inputs, per-round summaries, findings, controls.

Excludes container trial trees and prompts (large, rebuildable from inputs + producers); keeps every
decision record, compiled candidate patch, probe log and qualification row, plus member hashes.
"""
from pathlib import Path
import hashlib, io, json, tarfile, time

HERE = Path(__file__).resolve().parent
OUT = Path('/Users/petermakhnatch/Developer/eval-lab/.worktrees/hardening-pr-r-20261019/research/evidence/hardening-loop-20261019.tar.gz')
BRIDGE = Path('/Users/petermakhnatch/Developer/research-context/bridge/2026-10-19-deep')
KEEP_NAMES = {'attempt.json', 'summary.json', 'proposal.patch', 'response.txt', 'spec.json', 'probe.json', 'probe.log',
              'probe.sh', 'result.json', 'variant.json', 'disposition.json', 'qualification.json', 'semantic-candidate.json',
              'source-context.json', 'overtightening-adjudication.json', 'parent-v71-reference-x3.json', 'result.withdrawn-overtight.json', 'obs.json', 'agent.replay.diff', 'native-replay.json', 'reward.txt', 'test_output.log'}


def members():
    for path in sorted(HERE.glob('*.py')) + sorted((HERE / 'regrade').glob('*.py')):
        yield path
    for path in sorted(HERE.glob('inputs*.json')):
        yield path
    yield HERE / 'hosted/ledger.jsonl'
    yield HERE / 'modal-ledger.json'
    for path in sorted(HERE.glob('*.log')):
        yield path
    for root in ('round-2', 'round-3', 'round-4', 'round-5', 'round-6', 'findings', 'legit', 'regrade', 'source-context'):
        base = HERE / root
        if not base.exists():
            continue
        for path in sorted(base.rglob('*')):
            if path.is_file() and not path.is_symlink() and path.name in KEEP_NAMES and ('/trial/' not in str(path) or path.name in ('reward.txt', 'test_output.log')):
                yield path
    for path in sorted(BRIDGE.glob('hardening-round-*.json')) + sorted(BRIDGE.glob('repairs-round-*.json')):
        yield path


def main():
    manifest = []
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:gz', compresslevel=9) as tar:
        for path in members():
            data = path.read_bytes()
            arcname = ('bridge/' + path.name) if BRIDGE in path.parents else str(path.relative_to(HERE))
            info = tarfile.TarInfo(arcname)
            info.size, info.mtime, info.mode = len(data), int(time.time()), 0o644
            tar.addfile(info, io.BytesIO(data))
            manifest.append({'path': arcname, 'bytes': len(data), 'sha256': 'sha256:' + hashlib.sha256(data).hexdigest()})
        blob = json.dumps({'schema': 'hardening.capsule/v1', 'members': manifest}, indent=1).encode()
        info = tarfile.TarInfo('MANIFEST.json')
        info.size, info.mtime, info.mode = len(blob), int(time.time()), 0o644
        tar.addfile(info, io.BytesIO(blob))
    OUT.write_bytes(buffer.getvalue())
    print(json.dumps({'path': str(OUT), 'bytes': OUT.stat().st_size, 'members': len(manifest),
                      'sha256': 'sha256:' + hashlib.sha256(OUT.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()

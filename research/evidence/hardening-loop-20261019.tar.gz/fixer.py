"""Fixer side: independent wrongness probe, append-only repair derivation, native qualification.

probe:   one fresh native-Harbor Modal sandbox (package healthcheck/setup first, no verifier).
         Arms run in sequence on the pristine tree: each wrong candidate, the reference patch, and
         pristine; each arm applies its patch, writes the proposed regression test, runs it, then
         reverts. A finding is independently verified when every wrong arm FAILS the test and the
         reference PASSES it.
derive:  evallab.verifier_repair.derive_repair_variant (append-only: original test.patch prefix and
         original command preserved, new test appended, original exit status kept).
qualify: native Harbor trials on Modal on the repaired package: reference x3 == 1, nop == 0,
         every wrong program from all rounds == 0, admitted correct alternates == 1.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from functools import partial
import base64, hashlib, json, re, shlex

from evallab.qa.task import HarborBackend, mimo_semantic_patch_script
from evallab.registry import task_directory_digest
from evallab.task_variants import derive_task
from evallab.verifier_repair import RepairProposal, derive_repair_variant
import modal_lane
from build_inputs import reference_patch

HERE = Path(__file__).resolve().parent
WT = HERE.parents[1]
VARIANTS = 'runs/hardening-r2/task-store/variants'
BACKEND = 'modal'  # 'docker' = this lane's single local container (hbackend), sequential


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, default=str) + '\n')


def b64(text: str) -> str:
    return base64.b64encode(text.encode()).decode()


def probe(package: Path, digest: str, spec: dict, wrongs: list[tuple[str, str]], out: Path) -> dict:
    """wrongs: [(label, patch_text)]. spec: repo_path, code, command (run in workdir)."""
    workdir = HarborBackend.patch_workdir(package)
    arms = [*wrongs, ('reference', reference_patch(package)), ('pristine', '')]
    lines = ['set -u', f'cd {shlex.quote(workdir)}', 'git config --global --add safe.directory "$PWD" >/dev/null 2>&1 || true']
    for label, patch in arms:
        lines.append(f'echo "QA_ARM_BEGIN {label}"')
        run = [f'mkdir -p {shlex.quote(str(Path(spec["repo_path"]).parent))}',
               f'echo {b64(spec["code"])} | base64 -d > {shlex.quote(spec["repo_path"])}',
               f'( {spec["command"]} ) > /tmp/qa-arm.log 2>&1; rc=$?',
               'tail -c 3000 /tmp/qa-arm.log; echo',
               f'echo "QA_ARM_RESULT {label} rc=$rc"',
               f'rm -f {shlex.quote(spec["repo_path"])}',
               'find . -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null; true']
        if patch:
            lines.append(f'echo {b64(patch)} | base64 -d > /tmp/qa-arm.patch')
            lines.append('if git apply --whitespace=nowarn /tmp/qa-arm.patch; then')
            lines.extend('  ' + line for line in run)
            lines.append(f'  git apply -R --whitespace=nowarn /tmp/qa-arm.patch || echo "QA_ARM_REVERT_FAILED {label}"')
            lines.append(f'else echo "QA_ARM_RESULT {label} apply_failed"; fi')
        else:
            lines.extend(run)
    script = '\n'.join(lines) + '\nexit 0\n'
    out.mkdir(parents=True, exist_ok=True)
    (out / 'probe.sh').write_text(script)
    if BACKEND == 'docker':
        from hbackend import Backend
        local = Backend(repo_root=WT)
        with local.slot('hardening/probe/' + package.name):
            image, _ = local._ensure_images(package, digest)
            done = local._run_probe(package, image, script, timeout=1500)
        text = (done.stdout or '') + '\n' + (done.stderr or '')
        result = done
    else:
        with modal_lane.gate() as spend:
            mb = modal_lane.backend(spend)
            obs = mb._native_trial(package, digest=digest, mode='oracle', script=None, trial_dir=out / 'trial',
                                   timeout_seconds=1500, solve_override=script, with_solution=False,
                                   capture_logs=False, verifier=False)
        log = out / 'trial' / 'agent' / 'oracle.txt'
        text = (log.read_text(errors='replace') if log.exists() else '') + '\n' + str(obs.reason or '')
        result = type('R', (), {'returncode': 0 if obs.status == 'executed' else 1})
    (out / 'probe.log').write_text(text)
    rcs = {m[0]: m[1] for m in re.findall(r'^QA_ARM_RESULT (\S+) (\S+)$', text, re.M)}
    wrong_labels = [w[0] for w in wrongs]
    verified = (all(rcs.get(w, '').startswith('rc=') and rcs[w] != 'rc=0' for w in wrong_labels)
                and rcs.get('reference') == 'rc=0')
    record = {'created': now(), 'package_path': str(package), 'package_digest': digest, 'spec': spec,
              'test_sha256': hashlib.sha256(spec['code'].encode()).hexdigest(), 'arms': rcs,
              'probe_returncode': result.returncode, 'independently_verified_wrong': verified,
              'rule': 'every wrong arm fails the task-requirement test and the reference passes it',
              'model_calls': 0}
    save(out / 'probe.json', record)
    return record


def derive(package: Path, spec: dict, mutant_ids: list[str], rationale: str):
    from evallab.verifier_repair import MAX_RATIONALE_CHARS
    rationale = rationale[:MAX_RATIONALE_CHARS]
    proposal = RepairProposal.model_validate({
        'repairable': True, 'rationale': rationale, 'mutant_ids': mutant_ids,
        'tests': [{'id': Path(spec['repo_path']).stem[:64], 'repo_path': spec['repo_path'], 'code': spec['code']}],
        'command': spec['command'], 'edits': [], 'unrepairable': []})
    record = derive_repair_variant(package, proposal, repo_root=WT, created_by='hardening-loop-r2',
                                   rationale=rationale,
                                   derive_fn=partial(derive_task, variants_root=VARIANTS))
    variant = WT / VARIANTS / record.task_name.replace('/', '__') / record.variant_digest.split(':')[-1][:12]
    return record, variant


def qualify(variant: Path, wrongs: list[tuple[str, str]], corrects: list[tuple[str, str]], out: Path,
            *, refs: int = 3, nops: int = 1, timeout: int = 1500,
            script_wrongs: list[tuple[str, str]] = (), script_corrects: list[tuple[str, str]] = ()) -> dict:
    """Native Harbor on Modal, all cells in parallel. Reference/nop use the package's own
    channels; every program control replays through the oracle channel as solve.sh: archived
    EnvCheck scripts verbatim, semantic patches via the same workdir-bound apply script that
    grade_shortcut compiles (mimo_semantic_patch_script)."""
    digest = task_directory_digest(variant)
    plan = ([('reference', 'oracle', None, 1.0)] * refs + [('nop', 'nop', None, 0.0)] * nops
            + [(label, 'wrong', mimo_semantic_patch_script(variant, patch)[0], 0.0) for label, patch in wrongs]
            + [(label, 'wrong-script', script, 0.0) for label, script in script_wrongs]
            + [(label, 'correct', mimo_semantic_patch_script(variant, patch)[0], 1.0) for label, patch in corrects]
            + [(label, 'correct-script', script, 1.0) for label, script in script_corrects])

    def cell(args):
        index, (label, role, script, expected) = args
        tdir = out / f'{index:02d}-{role}-{label}' / 'trial'
        if role in ('oracle', 'nop'):
            obs = mb.run_container_trial(variant, digest=digest, mode=role, trial_dir=tdir, timeout_seconds=timeout)
        else:
            obs = mb.run_container_trial(variant, digest=digest, mode='oracle', solve_override=script,
                                         trial_dir=tdir, timeout_seconds=timeout)
        reward = obs.facts.get('reward') if obs.status == 'executed' and not obs.facts.get('exception') else None
        row = {'label': label, 'role': role, 'expected': expected, 'reward': reward, 'status': obs.status,
               'reason': obs.reason, 'ok': reward == expected, 'trial': str(tdir)}
        print(json.dumps({k: row[k] for k in ('label', 'role', 'expected', 'reward', 'ok')}), flush=True)
        return row

    if BACKEND == 'docker':
        from hbackend import Backend
        mb = Backend(repo_root=WT)
        rows = [cell(item) for item in enumerate(plan)]
    else:
        with modal_lane.gate() as spend:
            mb = modal_lane.backend(spend)
            with ThreadPoolExecutor(max_workers=8) as pool:
                rows = list(pool.map(cell, enumerate(plan)))
    complete = all(r['reward'] is not None for r in rows)
    qualified = complete and all(r['ok'] for r in rows)
    result = {'variant': str(variant), 'package_digest': digest, 'rows': rows, 'complete': complete,
              'qualified': qualified, 'created': now(),
              'backend': 'local-docker-qa-backend' if BACKEND == 'docker' else 'modal-native-harbor'}
    save(out / 'qualification.json', result)
    return result

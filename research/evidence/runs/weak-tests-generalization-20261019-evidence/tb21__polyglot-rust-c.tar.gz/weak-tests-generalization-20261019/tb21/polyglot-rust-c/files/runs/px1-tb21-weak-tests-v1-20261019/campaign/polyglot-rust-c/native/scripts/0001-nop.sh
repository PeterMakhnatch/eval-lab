#!/usr/bin/env bash
# envcheck: capture-base
# expect: 0
set -e
mkdir -p /logs/artifacts/envcheck-capture/.ref-subset-states
if [ -L / ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -L /app ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -L /app/polyglot ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -L /app/polyglot/main.rs ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -e /app/polyglot/main.rs ] && [ ! -f /app/polyglot/main.rs ]; then echo 'ref-subset: target is not a regular file' >&2; exit 97; fi
if [ -f /app/polyglot/main.rs ]; then printf 'present\n'; else printf 'absent\n'; fi > /logs/artifacts/envcheck-capture/.ref-subset-states/0
if [ -f /app/polyglot/main.rs ]; then stat -c '%a' -- /app/polyglot/main.rs > /logs/artifacts/envcheck-capture/.ref-subset-states/0.mode; fi
#!/usr/bin/env bash
# envcheck: capture-base
# expect: 0
if [ -e /app/polyglot/main.rs ]; then mkdir -p /logs/artifacts/envcheck-capture/app/polyglot && cp -a /app/polyglot/main.rs /logs/artifacts/envcheck-capture/app/polyglot/main.rs; fi
printf 'complete\n' > /logs/artifacts/envcheck-capture/.ref-subset-states/complete

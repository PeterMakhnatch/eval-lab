"""Local Docker QA backend, same runtime profile as QA Task wave2 (qualified_local_backend_v3).

Airgapped trial containers (--network none, NET_ADMIN/NET_RAW dropped, no-new-privileges).
A pinned read-only CPython is mounted only for the unchanged MiMo healthcheck/setup; an EXIT
trap restores the original python3 alias before any candidate, program or grader runs.
The package bytes are never edited. One trial at a time from this process.
"""
from contextlib import contextmanager
from pathlib import Path
import fcntl
import hashlib
import shlex
import threading

# Host-wide FIFO uses the repository default slot count; a private flock keeps this lane at
# one container across all of its processes.
from evallab.qa.task import HarborBackend
from evallab.separate_verifier import MIMO_STATE_DIR

_LOCAL = threading.local()
_THREAD_LOCK = threading.RLock()

HERE = Path(__file__).resolve().parent
HELPER = HERE / 'runtime-helper/cpython-3.12.11-linux-x86_64-gnu'
SETUP_ROOT = '/opt/evallab-qa-setup-python-20261018'


class Backend(HarborBackend):
    @contextmanager
    def slot(self, label):
        if getattr(_LOCAL, 'depth', 0):
            _LOCAL.depth += 1
            try:
                with super().slot(label):
                    yield
            finally:
                _LOCAL.depth -= 1
            return
        with _THREAD_LOCK, (HERE / 'docker.lock').open('a') as handle:
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            _LOCAL.depth = 1
            try:
                with super().slot(label):
                    yield
            finally:
                _LOCAL.depth = 0

    @staticmethod
    def _limits(env_cfg):
        if not (HELPER / 'bin/python3').is_file():
            raise RuntimeError('pinned isolated setup helper is unavailable')
        return [*HarborBackend._limits(env_cfg), '--network', 'none', '--cap-drop', 'NET_ADMIN',
                '--cap-drop', 'NET_RAW', '--security-opt', 'no-new-privileges',
                '--mount', f'type=bind,source={HELPER},target={SETUP_ROOT},readonly']

    def _run_healthcheck(self, container, env_cfg):
        spec = self._healthcheck_spec(env_cfg)
        if spec is None or MIMO_STATE_DIR not in str(spec['command']):
            return super()._run_healthcheck(container, env_cfg)
        original = '/usr/bin/python3.evallab-qa-original-20261018'
        inner = 'env PATH="' + SETUP_ROOT + '/bin:$PATH" sh -c ' + shlex.quote(str(spec['command']))
        command = (
            'set -eu; '
            f'test ! -e {original}; test ! -L {original}; had_python3=0; '
            f'if [ -e /usr/bin/python3 ] || [ -L /usr/bin/python3 ]; then '
            f'mv /usr/bin/python3 {original}; had_python3=1; fi; '
            "trap 'status=$?; rm -f /usr/bin/python3; "
            f'if [ "$had_python3" = 1 ]; then mv {original} /usr/bin/python3; fi; '
            "exit \"$status\"' EXIT; "
            f'ln -s {SETUP_ROOT}/bin/python3 /usr/bin/python3; '
            + inner
        )
        configured = {**env_cfg, 'healthcheck': {**spec, 'command': 'sh -c ' + shlex.quote(command)}}
        result = super()._run_healthcheck(container, configured)
        result['healthcheck'].update({
            'setup_helper': 'uv0.9.24/cpython-3.12.11-linux-x86_64-gnu',
            'setup_python_sha256': hashlib.sha256((HELPER / 'bin/python3.12').read_bytes()).hexdigest(),
            'path_scope': 'setup-only helper PATH prefix plus temporary system-python3 alias; EXIT trap restores alias; task/grader PATH unchanged',
            'helper_mount': 'read-only',
        })
        return result

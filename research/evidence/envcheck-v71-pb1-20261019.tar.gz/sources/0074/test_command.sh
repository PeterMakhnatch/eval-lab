(
(
bash /testbed/mimo_test_command.sh
)
REPAIR_RC=$?
cd /testbed || exit 1
if [ -x /opt/test_venv/bin/python3 ]; then
  PATH=/opt/test_venv/bin:$PATH
  export PATH
  python() { /opt/test_venv/bin/python3 "$@"; }
  python3() { /opt/test_venv/bin/python3 "$@"; }
fi
/usr/local/bin/python -m pytest -q mitiq/tests/test_measurement_key_equality_contract.py
REPAIR_NEW_RC=$?
if [ "$REPAIR_NEW_RC" -ne 0 ]; then exit 1; fi
exit "$REPAIR_RC"
)
REPAIR_RC=$?
cd /testbed || exit 1
if [ -x /opt/test_venv/bin/python3 ]; then
  PATH=/opt/test_venv/bin:$PATH
  export PATH
  python() { /opt/test_venv/bin/python3 "$@"; }
  python3() { /opt/test_venv/bin/python3 "$@"; }
fi
/usr/local/bin/python -m pytest -q mitiq/tests/test_v71_empty_measurement_keys.py
REPAIR_NEW_RC=$?
if [ "$REPAIR_NEW_RC" -ne 0 ]; then exit 1; fi
exit "$REPAIR_RC"

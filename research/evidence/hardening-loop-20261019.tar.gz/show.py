"""Print one candidate for parent review: instruction, counterexample, candidate patch, reference patch."""
import json, sys
from pathlib import Path
from build_inputs import reference_patch

HERE = Path(__file__).resolve().parent
rnd, short, attempt = sys.argv[1], sys.argv[2], sys.argv[3]
what = sys.argv[4] if len(sys.argv) > 4 else 'all'
case = next(c for c in json.loads((HERE / ('inputs.json' if rnd in ('2', 'v71glm') else f'inputs-r{rnd}.json')).read_text())['cases'] if c['short'] == short)
pkg = Path(case['package_path'])
adir = HERE / (rnd if not rnd.isdigit() else f'round-{rnd}') / short / f'attempt-{attempt}'
row = json.loads((adir / 'attempt.json').read_text()) if (adir / 'attempt.json').exists() else json.loads((adir / 'response.txt').read_text())
if what in ('all', 'i'):
    print('=== INSTRUCTION ===\n' + (pkg / 'instruction.md').read_text()[:6000])
print('=== COUNTEREXAMPLE ===\n' + json.dumps({k: row.get(k) for k in ('mechanism_hypothesis', 'counterexample')}, indent=1))
print('=== CANDIDATE ===\n' + (adir / 'proposal.patch').read_text())
if what in ('all', 'r'):
    print('=== REFERENCE ===\n' + reference_patch(pkg)[:8000])
if what in ('all', 't'):
    print('=== TEST COMMAND (patch headers) ===')
    for line in (pkg / 'tests/test.patch').read_text().splitlines():
        if line.startswith('diff --git'):
            print(line)

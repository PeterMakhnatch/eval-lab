set -u
cd /testbed
git config --global --add safe.directory "$PWD" >/dev/null 2>&1 || true
echo "QA_ARM_BEGIN r6-a1"
echo ZGlmZiAtLWdpdCBhL3dhcmVob3VzZS9maWx0ZXJzLnB5IGIvd2FyZWhvdXNlL2ZpbHRlcnMucHkKLS0tIGEvd2FyZWhvdXNlL2ZpbHRlcnMucHkKKysrIGIvd2FyZWhvdXNlL2ZpbHRlcnMucHkKQEAgLTEzNyw2ICsxMzcsMTcgQEAKICAgICAgICAgICAgICAgICBzdHJ1Y3R1cmVkW2tleV0gPSBbXQogICAgICAgICAgICAgc3RydWN0dXJlZFtrZXldLmFwcGVuZCh2YWx1ZVswXSkKIAorICAgICMgU29ydCB2YWx1ZXMgbmF0dXJhbGx5IHNvIG51bWVyaWMgc2VnbWVudHMgb3JkZXIgbnVtZXJpY2FsbHkKKyAgICAjIChlLmcuIDMuMTAgYWZ0ZXIgMy45KS4gWmVyby1wYWQgZGlnaXQgcnVucyBzbyBsZXhpY29ncmFwaGljCisgICAgIyBvcmRlciBtYXRjaGVzIG51bWVyaWMgb3JkZXIuCisgICAgZGVmIF9uYXR1cmFsX2tleSh2YWx1ZSk6CisgICAgICAgIHJldHVybiByZS5zdWIoCisgICAgICAgICAgICByIlxkKyIsIGxhbWJkYSBtOiBtLmdyb3VwKCkuemZpbGwoMiksIHZhbHVlCisgICAgICAgICkKKworICAgIGZvciBrZXkgaW4gc3RydWN0dXJlZDoKKyAgICAgICAgc3RydWN0dXJlZFtrZXldLnNvcnQoa2V5PV9uYXR1cmFsX2tleSkKKwogICAgIHJldHVybiBzdHJ1Y3R1cmVkCiAKIAo= | base64 -d > /tmp/qa-arm.patch
if git apply --whitespace=nowarn /tmp/qa-arm.patch; then
  mkdir -p tests/unit
  echo IiIiZm9ybWF0X2NsYXNzaWZpZXJzIHNvcnRzIG51bWVyaWMgY2xhc3NpZmllciBjb21wb25lbnRzIG5hdHVyYWxseSBhdCBhbnkgd2lkdGguIiIiCgpmcm9tIHdhcmVob3VzZSBpbXBvcnQgZmlsdGVycwoKCmRlZiB0ZXN0X3RocmVlX2RpZ2l0X2NvbXBvbmVudF9zb3J0c19hZnRlcl90d29fZGlnaXQoKToKICAgIHJlc3VsdCA9IGZpbHRlcnMuZm9ybWF0X2NsYXNzaWZpZXJzKFsiRm9vIDo6IDk5IiwgIkZvbyA6OiAxMDAiLCAiRm9vIDo6IDkiXSkKICAgIGFzc2VydCByZXN1bHQgPT0geyJGb28iOiBbIjkiLCAiOTkiLCAiMTAwIl19Cg== | base64 -d > tests/unit/test_hardening_glm_natural_sort.py
  ( cd /testbed && if [ -x /opt/test_venv/bin/python3 ]; then PY=/opt/test_venv/bin/python3; else PY=python; fi; $PY -m pytest -q -p no:cacheprovider tests/unit/test_hardening_glm_natural_sort.py ) > /tmp/qa-arm.log 2>&1; rc=$?
  tail -c 3000 /tmp/qa-arm.log; echo
  echo "QA_ARM_RESULT r6-a1 rc=$rc"
  rm -f tests/unit/test_hardening_glm_natural_sort.py
  find . -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null; true
  git apply -R --whitespace=nowarn /tmp/qa-arm.patch || echo "QA_ARM_REVERT_FAILED r6-a1"
else echo "QA_ARM_RESULT r6-a1 apply_failed"; fi
echo "QA_ARM_BEGIN reference"
echo ZGlmZiAtLWdpdCBhL3dhcmVob3VzZS9maWx0ZXJzLnB5IGIvd2FyZWhvdXNlL2ZpbHRlcnMucHkKaW5kZXggMDNjZmJjMGYyLi5kM2JjNTgxZTUgMTAwNjQ0Ci0tLSBhL3dhcmVob3VzZS9maWx0ZXJzLnB5CisrKyBiL3dhcmVob3VzZS9maWx0ZXJzLnB5CkBAIC0yOCw2ICsyOCw3IEBAIGltcG9ydCBqaW5qYTIKIGltcG9ydCBwYWNrYWdpbmcudmVyc2lvbgogaW1wb3J0IHB5dHoKIAorZnJvbSBuYXRzb3J0IGltcG9ydCBuYXRzb3J0ZWQKIGZyb20gcHlyYW1pZC50aHJlYWRsb2NhbCBpbXBvcnQgZ2V0X2N1cnJlbnRfcmVxdWVzdAogCiBmcm9tIHdhcmVob3VzZS51dGlscy5odHRwIGltcG9ydCBpc192YWxpZF91cmkKQEAgLTEzNyw2ICsxMzgsMTAgQEAgZGVmIGZvcm1hdF9jbGFzc2lmaWVycyhjbGFzc2lmaWVycyk6CiAgICAgICAgICAgICAgICAgc3RydWN0dXJlZFtrZXldID0gW10KICAgICAgICAgICAgIHN0cnVjdHVyZWRba2V5XS5hcHBlbmQodmFsdWVbMF0pCiAKKyAgICAjIFNvcnQgYWxsIHRoZSB2YWx1ZXMgaW4gb3VyIGRhdGEgc3RydWN0dXJlCisgICAgZm9yIGtleSwgdmFsdWUgaW4gc3RydWN0dXJlZC5pdGVtcygpOgorICAgICAgICBzdHJ1Y3R1cmVkW2tleV0gPSBuYXRzb3J0ZWQodmFsdWUpCisKICAgICByZXR1cm4gc3RydWN0dXJlZAogCiAK | base64 -d > /tmp/qa-arm.patch
if git apply --whitespace=nowarn /tmp/qa-arm.patch; then
  mkdir -p tests/unit
  echo IiIiZm9ybWF0X2NsYXNzaWZpZXJzIHNvcnRzIG51bWVyaWMgY2xhc3NpZmllciBjb21wb25lbnRzIG5hdHVyYWxseSBhdCBhbnkgd2lkdGguIiIiCgpmcm9tIHdhcmVob3VzZSBpbXBvcnQgZmlsdGVycwoKCmRlZiB0ZXN0X3RocmVlX2RpZ2l0X2NvbXBvbmVudF9zb3J0c19hZnRlcl90d29fZGlnaXQoKToKICAgIHJlc3VsdCA9IGZpbHRlcnMuZm9ybWF0X2NsYXNzaWZpZXJzKFsiRm9vIDo6IDk5IiwgIkZvbyA6OiAxMDAiLCAiRm9vIDo6IDkiXSkKICAgIGFzc2VydCByZXN1bHQgPT0geyJGb28iOiBbIjkiLCAiOTkiLCAiMTAwIl19Cg== | base64 -d > tests/unit/test_hardening_glm_natural_sort.py
  ( cd /testbed && if [ -x /opt/test_venv/bin/python3 ]; then PY=/opt/test_venv/bin/python3; else PY=python; fi; $PY -m pytest -q -p no:cacheprovider tests/unit/test_hardening_glm_natural_sort.py ) > /tmp/qa-arm.log 2>&1; rc=$?
  tail -c 3000 /tmp/qa-arm.log; echo
  echo "QA_ARM_RESULT reference rc=$rc"
  rm -f tests/unit/test_hardening_glm_natural_sort.py
  find . -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null; true
  git apply -R --whitespace=nowarn /tmp/qa-arm.patch || echo "QA_ARM_REVERT_FAILED reference"
else echo "QA_ARM_RESULT reference apply_failed"; fi
echo "QA_ARM_BEGIN pristine"
mkdir -p tests/unit
echo IiIiZm9ybWF0X2NsYXNzaWZpZXJzIHNvcnRzIG51bWVyaWMgY2xhc3NpZmllciBjb21wb25lbnRzIG5hdHVyYWxseSBhdCBhbnkgd2lkdGguIiIiCgpmcm9tIHdhcmVob3VzZSBpbXBvcnQgZmlsdGVycwoKCmRlZiB0ZXN0X3RocmVlX2RpZ2l0X2NvbXBvbmVudF9zb3J0c19hZnRlcl90d29fZGlnaXQoKToKICAgIHJlc3VsdCA9IGZpbHRlcnMuZm9ybWF0X2NsYXNzaWZpZXJzKFsiRm9vIDo6IDk5IiwgIkZvbyA6OiAxMDAiLCAiRm9vIDo6IDkiXSkKICAgIGFzc2VydCByZXN1bHQgPT0geyJGb28iOiBbIjkiLCAiOTkiLCAiMTAwIl19Cg== | base64 -d > tests/unit/test_hardening_glm_natural_sort.py
( cd /testbed && if [ -x /opt/test_venv/bin/python3 ]; then PY=/opt/test_venv/bin/python3; else PY=python; fi; $PY -m pytest -q -p no:cacheprovider tests/unit/test_hardening_glm_natural_sort.py ) > /tmp/qa-arm.log 2>&1; rc=$?
tail -c 3000 /tmp/qa-arm.log; echo
echo "QA_ARM_RESULT pristine rc=$rc"
rm -f tests/unit/test_hardening_glm_natural_sort.py
find . -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null; true
exit 0

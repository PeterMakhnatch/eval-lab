#!/usr/bin/env bash
# envcheck: capture-base
# expect: 0
set -e
mkdir -p /logs/artifacts/envcheck-capture/.ref-subset-states
if [ -L / ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -L /app ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -L /app/user.cpp ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -e /app/user.cpp ] && [ ! -f /app/user.cpp ]; then echo 'ref-subset: target is not a regular file' >&2; exit 97; fi
if [ -f /app/user.cpp ]; then printf 'present\n'; else printf 'absent\n'; fi > /logs/artifacts/envcheck-capture/.ref-subset-states/0
if [ -f /app/user.cpp ]; then stat -c '%a' -- /app/user.cpp > /logs/artifacts/envcheck-capture/.ref-subset-states/0.mode; fi
#!/usr/bin/env bash
# envcheck: capture-base
# expect: 0
if [ -e /app/user.cpp ]; then mkdir -p /logs/artifacts/envcheck-capture/app && cp -a /app/user.cpp /logs/artifacts/envcheck-capture/app/user.cpp; fi
printf 'complete\n' > /logs/artifacts/envcheck-capture/.ref-subset-states/complete

#!/usr/bin/env bash
# envcheck: capture-base
# expect: 0
set -e
mkdir -p /logs/artifacts/envcheck-capture/.ref-subset-states
if [ -L / ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -L /app ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -L /app/image.c ]; then echo 'ref-subset: symlink target' >&2; exit 97; fi
if [ -e /app/image.c ] && [ ! -f /app/image.c ]; then echo 'ref-subset: target is not a regular file' >&2; exit 97; fi
if [ -f /app/image.c ]; then printf 'present\n'; else printf 'absent\n'; fi > /logs/artifacts/envcheck-capture/.ref-subset-states/0
if [ -f /app/image.c ]; then stat -c '%a' -- /app/image.c > /logs/artifacts/envcheck-capture/.ref-subset-states/0.mode; fi
#!/usr/bin/env bash
# envcheck: capture-base
# expect: 0
if [ -e /app/image.c ]; then mkdir -p /logs/artifacts/envcheck-capture/app && cp -a /app/image.c /logs/artifacts/envcheck-capture/app/image.c; fi
printf 'complete\n' > /logs/artifacts/envcheck-capture/.ref-subset-states/complete

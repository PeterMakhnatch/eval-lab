#!/bin/bash
# separate-verifier@3 entry: patch-only grading in a pristine verifier checkout.
# Extends @2 with multi-runner drops, cross-language tamper gates, and
# structured per-runner grading (exit-code fallback for silent families).
# Exit 0 whenever grading completes (reward in /logs/verifier/reward.txt);
# exit 1 only for testbed problems (setup/patch failures: not scored).
set -u
SNAP="/var/tmp/mimo-separate"
M="/var/lib/mimo"
CWD="/testbed"
V=/logs/verifier
GRADE=/var/lib/mimo-grade
TS_BAK="$GRADE/tests"
mkdir -p "$V" "$GRADE"
mkdir -p "$GRADE/v10shim" "$GRADE/pycache"
echo "IyBtaW1vLXVuaXR0ZXN0LXNoaW0vMTogc3RydWN0dXJlZCB1bml0dGVzdCBvdXRjb21lcyArIGludGVncml0eS4KaW1wb3J0IGF0ZXhpdCBhcyBfdjEwX2F0ZXhpdAppbXBvcnQgb3MgYXMgX3YxMF9vcwppbXBvcnQgcmUgYXMgX3YxMF9yZQpfVjEwX0NBU0VTID0gW10KX1YxMF9VVCA9IE5vbmUKX1YxMF9PUklHX1RDID0gTm9uZQpfVjEwX09SSUdfUlVOTkVSID0gTm9uZQp0cnk6CiAgICBpbXBvcnQgdW5pdHRlc3QgYXMgX1YxMF9VVAogICAgaW1wb3J0IHVuaXR0ZXN0LnJ1bm5lciBhcyBfdjEwX3J1bm5lcgogICAgX1YxMF9PUklHX1RDID0gX1YxMF9VVC5UZXN0Q2FzZS5ydW4KICAgIF9WMTBfT1JJR19SVU5ORVIgPSBfdjEwX3J1bm5lci5UZXh0VGVzdFJ1bm5lci5ydW4KICAgIF92MTBfcmVzdWx0ID0gX3YxMF9ydW5uZXIuVGV4dFRlc3RSZXN1bHQKICAgIGRlZiBfdjEwX3dyYXAobmFtZSwgc3RhdHVzKToKICAgICAgICBfb3JpZyA9IGdldGF0dHIoX3YxMF9yZXN1bHQsIG5hbWUpCiAgICAgICAgZGVmIF93cmFwcGVkKHNlbGYsIHRlc3QsICphcmdzLCAqKmt3YXJncyk6CiAgICAgICAgICAgIF9WMTBfQ0FTRVMuYXBwZW5kKChzdHIodGVzdCksIHN0YXR1cykpCiAgICAgICAgICAgIHJldHVybiBfb3JpZyhzZWxmLCB0ZXN0LCAqYXJncywgKiprd2FyZ3MpCiAgICAgICAgc2V0YXR0cihfdjEwX3Jlc3VsdCwgbmFtZSwgX3dyYXBwZWQpCiAgICBfdjEwX3dyYXAoImFkZFN1Y2Nlc3MiLCAicGFzc2VkIikKICAgIF92MTBfd3JhcCgiYWRkRmFpbHVyZSIsICJmYWlsZWQiKQogICAgX3YxMF93cmFwKCJhZGRFcnJvciIsICJmYWlsZWQiKQogICAgX3YxMF93cmFwKCJhZGRTa2lwIiwgInNraXBwZWQiKQogICAgX3YxMF93cmFwKCJhZGRFeHBlY3RlZEZhaWx1cmUiLCAic2tpcHBlZCIpCiAgICBfdjEwX3dyYXAoImFkZFVuZXhwZWN0ZWRTdWNjZXNzIiwgImZhaWxlZCIpCmV4Y2VwdCBFeGNlcHRpb246CiAgICBfVjEwX1VUID0gTm9uZQpkZWYgX3YxMF9mbHVzaCgpOgogICAgdHJ5OgogICAgICAgIF9pZGlyID0gX3YxMF9vcy5lbnZpcm9uLmdldCgiTUlNT19WRVJJRklFUl9JTlRFR1JJVFlfRElSIiwgIiIpCiAgICAgICAgaWYgX2lkaXIgYW5kIF9WMTBfVVQgaXMgbm90IE5vbmU6CiAgICAgICAgICAgIF9jaGFuZ2VkID0gW10KICAgICAgICAgICAgaWYgX1YxMF9VVC5UZXN0Q2FzZS5ydW4gaXMgbm90IF9WMTBfT1JJR19UQzoKICAgICAgICAgICAgICAgIF9jaGFuZ2VkLmFwcGVuZCgidW5pdHRlc3QuVGVzdENhc2UucnVuIikKICAgICAgICAgICAgaW1wb3J0IHVuaXR0ZXN0LnJ1bm5lciBhcyBfdjEwX3JyCiAgICAgICAgICAgIGlmIF92MTBfcnIuVGV4dFRlc3RSdW5uZXIucnVuIGlzIG5vdCBfVjEwX09SSUdfUlVOTkVSOgogICAgICAgICAgICAgICAgX2NoYW5nZWQuYXBwZW5kKCJ1bml0dGVzdC5UZXh0VGVzdFJ1bm5lci5ydW4iKQogICAgICAgICAgICBfdjEwX29zLm1ha2VkaXJzKF9pZGlyLCBleGlzdF9vaz1UcnVlKQogICAgICAgICAgICBfdGV4dCA9ICgiQ0hBTkdFRCAiICsgIiwiLmpvaW4oX2NoYW5nZWQpKSBpZiBfY2hhbmdlZCBlbHNlICJPSyIKICAgICAgICAgICAgd2l0aCBvcGVuKF92MTBfb3MucGF0aC5qb2luKF9pZGlyLCAiaW50ZWdyaXR5LXVuaXR0ZXN0LnR4dCIpLCAidyIsIGVuY29kaW5nPSJ1dGYtOCIpIGFzIF9mOgogICAgICAgICAgICAgICAgX2Yud3JpdGUoX3RleHQgKyAiXG4iKQogICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICBwYXNzCiAgICB0cnk6CiAgICAgICAgX291dCA9IF92MTBfb3MuZW52aXJvbi5nZXQoIk1JTU9fVkVSSUZJRVJfVU5JVFRFU1RfSlVOSVQiLCAiIikKICAgICAgICBpZiBub3QgX291dDoKICAgICAgICAgICAgcmV0dXJuCiAgICAgICAgaW1wb3J0IHhtbC5ldHJlZS5FbGVtZW50VHJlZSBhcyBfRVQKICAgICAgICBfc3VpdGUgPSBfRVQuRWxlbWVudCgidGVzdHN1aXRlIiwgbmFtZT0idmVyaWZpZXItdW5pdHRlc3QiLCB0ZXN0cz1zdHIobGVuKF9WMTBfQ0FTRVMpKSkKICAgICAgICBmb3IgX2xhYmVsLCBfc3RhdHVzIGluIF9WMTBfQ0FTRVM6CiAgICAgICAgICAgIF9tID0gX3YxMF9yZS5tYXRjaChyIl4oLio/KVxzKlwoKFteKCldKilcKSQiLCBfbGFiZWwpCiAgICAgICAgICAgIGlmIF9tOgogICAgICAgICAgICAgICAgX25hbWUgPSBfbS5ncm91cCgxKQogICAgICAgICAgICAgICAgX2NuID0gX20uZ3JvdXAoMikKICAgICAgICAgICAgZWxzZToKICAgICAgICAgICAgICAgIF9uYW1lID0gX2xhYmVsCiAgICAgICAgICAgICAgICBfY24gPSAiIgogICAgICAgICAgICBfY2FzZSA9IF9FVC5TdWJFbGVtZW50KF9zdWl0ZSwgInRlc3RjYXNlIiwgY2xhc3NuYW1lPV9jbiwgbmFtZT1fbmFtZSkKICAgICAgICAgICAgaWYgX3N0YXR1cyA9PSAiZmFpbGVkIjoKICAgICAgICAgICAgICAgIF9FVC5TdWJFbGVtZW50KF9jYXNlLCAiZmFpbHVyZSIsIG1lc3NhZ2U9ImZhaWxlZCIpCiAgICAgICAgICAgIGVsaWYgX3N0YXR1cyA9PSAic2tpcHBlZCI6CiAgICAgICAgICAgICAgICBfRVQuU3ViRWxlbWVudChfY2FzZSwgInNraXBwZWQiLCBtZXNzYWdlPSJza2lwcGVkIikKICAgICAgICBfdjEwX29zLm1ha2VkaXJzKF92MTBfb3MucGF0aC5kaXJuYW1lKF9vdXQpLCBleGlzdF9vaz1UcnVlKQogICAgICAgIF9FVC5FbGVtZW50VHJlZShfc3VpdGUpLndyaXRlKF9vdXQpCiAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgIHBhc3MKX3YxMF9hdGV4aXQucmVnaXN0ZXIoX3YxMF9mbHVzaCkK" | base64 -d > "$GRADE/v10shim/sitecustomize.py"
# 0. Pristine checkout: rerun the bundled clean setup (same as @2).
rm -rf "$TS_BAK"; cp -a /tests "$TS_BAK"
mkdir -p "$M"; cp -r "$TS_BAK/_verifier-setup/." "$M/"
if ! bash "$M/setup.sh" > "$GRADE/setup.log" 2>&1; then
  echo "verifier setup failed (testbed problem, not scored)" >&2; exit 1
fi
rm -rf /tests; cp -a "$TS_BAK" /tests; rm -rf "$TS_BAK"
mkdir -p "$V"; cp "$GRADE/setup.log" "$V/setup.log"
BASE=$(cat "$M/base" 2>/dev/null) || { echo "verifier setup never ran (no $M/base)" >&2; exit 1; }
cd "$CWD" || exit 1
if [ -d "$M/git-hidden" ]; then rm -rf "$CWD/.git"; mv "$M/git-hidden" "$CWD/.git"; fi
test -f /tests/test.patch || { echo "bundled test.patch missing (testbed problem)" >&2; exit 1; }
test -f /tests/test_command.sh || { echo "bundled test_command.sh missing (testbed)" >&2; exit 1; }
# @10 repeat-idempotent pristine: restore the anchored first-run tree
# before capturing, so reruns never capture run-0 leftovers as pristine.
if [ -f "$M/pristine-tree" ]; then
  _V10_ANCHORED=$(cat "$M/pristine-tree")
  rm -rf "$GRADE/junit-phases" "$GRADE/baseline" "$GRADE/build_env" "$GRADE/pycache"
  rm -f "$GRADE/junit.xml" "$GRADE/unittest-junit.xml" "$GRADE/integrity.txt" "$GRADE/integrity-unittest.txt" "$GRADE/hook_installed" "$V/timing.log"
  export GIT_INDEX_FILE=/tmp/pristine.index; rm -f "$GIT_INDEX_FILE"
  git read-tree "$_V10_ANCHORED" || { echo "anchored pristine read failed" >&2; exit 1; }
  git checkout-index -f -a || { echo "anchored pristine restore failed" >&2; exit 1; }
  git clean -fdq || { echo "anchored pristine clean failed" >&2; exit 1; }
  git ls-files --others --ignored --exclude-standard -z > /tmp/post_ignored.bin 2>/dev/null || : > /tmp/post_ignored.bin
  python3 - "$M/pristine-ignored.bin" /tmp/post_ignored.bin <<'PYEOF_V10_CLEAN' 2>/dev/null || true
import os, shutil, sys
pre = set(filter(None, open(sys.argv[1], "rb").read().split(b"\0"))) if os.path.exists(sys.argv[1]) else set()
post = set(filter(None, open(sys.argv[2], "rb").read().split(b"\0"))) if os.path.exists(sys.argv[2]) else set()
for raw in post - pre:
    p = os.fsdecode(raw)
    if os.path.isdir(p) and not os.path.islink(p):
        shutil.rmtree(p, ignore_errors=True)
    elif os.path.lexists(p):
        os.unlink(p)
    d = os.path.dirname(p)
    while d and d != ".":
        try:
            os.rmdir(d)
        except OSError:
            break
        d = os.path.dirname(d)
PYEOF_V10_CLEAN
  unset GIT_INDEX_FILE
fi
# Capture tracked and untracked non-ignored files before importing agent bytes
# (matches render_snapshot_hook_v2's git ls-files -c -o --exclude-standard).
export GIT_INDEX_FILE=/tmp/pristine.index; rm -f "$GIT_INDEX_FILE"
git read-tree "$BASE" || { echo "pristine-tree read failed" >&2; exit 1; }
git add -A . || { echo "pristine-tree capture failed" >&2; exit 1; }
PRISTINE=$(git write-tree) || { echo "pristine-tree write failed" >&2; exit 1; }
git diff --cached --name-only "$BASE" > "$V/pristine-extra-files.log"
unset GIT_INDEX_FILE
if [ ! -f "$M/pristine-tree" ]; then
  git ls-files --others --ignored --exclude-standard -z > "$M/pristine-ignored.bin" 2>/dev/null || : > "$M/pristine-ignored.bin"
  printf '%s\n' "$PRISTINE" > "$M/pristine-tree" || { echo "pristine anchor write failed" >&2; exit 1; }
fi
# @6 baseline: hidden tests on the pristine tree (no agent bytes), for the
# fail-to-pass rule. Afterwards the tree returns to exactly $PRISTINE.
export GIT_INDEX_FILE=/tmp/baseline.index; rm -f "$GIT_INDEX_FILE"
git read-tree "$PRISTINE" || { echo "baseline index failed" >&2; exit 1; }
git ls-files --others --ignored --exclude-standard -z > "$V/pre_ignored.bin" 2>/dev/null || : > "$V/pre_ignored.bin"
BTESTFILES=$(grep '^diff --git' /tests/test.patch | sed 's#.* b/##')
printf '%s\n' "$BTESTFILES" | while IFS= read -r tf; do
  [ -z "$tf" ] && continue
  if git cat-file -e "$PRISTINE:$tf" 2>/dev/null; then
    git checkout -q "$PRISTINE" -- "$tf" 2>/dev/null || true
  else
    git rm -f --cached "$tf" >/dev/null 2>&1 || true
    rm -f "$tf"
  fi
done
if git apply --verbose /tests/test.patch > "$V/baseline_apply.log" 2>&1; then
  RES_B=$(cat /tests/test_command.sh)
  for ref in $(grep -oE '[^ "]*mimo_test_command\.sh' /tests/test_command.sh | sort -u); do
    base=${ref##*/}
    if [ -f "$base" ]; then RES_B="$RES_B
$(cat "$base")"; fi
  done
  if printf '%s' "$RES_B" | grep -q 'build_env/test_command'; then
    if [ -f mimo_build_env.tar.gz.b64 ]; then
      rm -rf "$GRADE/build_env" && mkdir -p "$GRADE/build_env"
      if base64 -d mimo_build_env.tar.gz.b64 2>/dev/null | tar -xzf - -C "$GRADE/build_env" 2>/dev/null; then
        BE_TC=$(find "$GRADE/build_env" -name 'test_command.sh' | head -1)
        if [ -n "$BE_TC" ]; then RES_B="$RES_B
$(cat "$BE_TC")"; fi
      fi
    fi
  fi
  printf '%s' "$RES_B" > "$V/baseline_resolved.txt"
  RUNNER_B=custom
  if printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])go +test( |$)'; then RUNNER_B=go-test
  elif printf '%s' "$RES_B" | grep -qE 'GO_BIN" +test( |$)'; then RUNNER_B=go-test
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])jest([^[:alnum:]_]|$)'; then RUNNER_B=jest
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])vitest([^[:alnum:]_]|$)'; then RUNNER_B=vitest
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])_?mocha([^[:alnum:]_]|$)'; then RUNNER_B=mocha
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])ava([^[:alnum:]_]|$)'; then RUNNER_B=ava
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])tap([^[:alnum:]_]|$)'; then RUNNER_B=tap
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])karma([^[:alnum:]_]|$)'; then RUNNER_B=karma
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])jasmine([^[:alnum:]_]|$)'; then RUNNER_B=jasmine
  elif printf '%s' "$RES_B" | grep -qE 'node +--test([^[:alnum:]_]|$)'; then RUNNER_B=node-test
  elif printf '%s' "$RES_B" | grep -qE 'cargo +test([^[:alnum:]_]|$)'; then RUNNER_B=cargo-test
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])rspec([^[:alnum:]_]|$)'; then RUNNER_B=rspec
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])phpunit([^[:alnum:]_]|$)'; then RUNNER_B=phpunit
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])mvn([^[:alnum:]_]|$)|surefire|failsafe'; then RUNNER_B=mvn
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])gradlew?([^[:alnum:]_]|$)'; then RUNNER_B=gradle
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])pytest([^[:alnum:]_]|$)'; then RUNNER_B=pytest
  elif printf '%s' "$RES_B" | grep -qE '\-m +unittest([^[:alnum:]_]|$)'; then RUNNER_B=unittest
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])forge +test([^[:alnum:]_]|$)'; then RUNNER_B=forge
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])node([^[:alnum:]_]|$)'; then RUNNER_B=node-run
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])(make|ctest|cmake)([^[:alnum:]_]|$)'; then RUNNER_B=make
  elif printf '%s' "$RES_B" | grep -qE '(^|[^[:alnum:]_])bats([^[:alnum:]_]|$)'; then RUNNER_B=bats
  fi
  echo "RUNNER_B=$RUNNER_B" > "$V/baseline_runner.txt"
  : > "$V/baseline.log"
  if [ "$RUNNER_B" = pytest ]; then
    CLEARED_B=0
    printf '%s' "$RES_B" | grep -q 'unset.*PYTEST_ADDOPTS' && CLEARED_B=1
    printf '%s' "$RES_B" | grep -q 'PYTEST_ADDOPTS=' && CLEARED_B=1
    printf '%s' "$RES_B" | grep -qE 'env +([^ ]+ +)*-u([^ ]* +)*PYTEST_ADDOPTS|env +-u +PYTEST_ADDOPTS' && CLEARED_B=1
    if [ "$CLEARED_B" = 1 ]; then
      echo "IyBzZXBhcmF0ZS12ZXJpZmllckAzIGhvb2s6IHN0cnVjdHVyZWQgcmVwb3J0IGZvciBhZGRvcHRzLWNsZWFyZWQgcnVucy4KaW1wb3J0IG9zIGFzIF92M19vcwpfVjNfSlVOSVRfUEFUSCA9IF92M19vcy5lbnZpcm9uLmdldCgiTUlNT19WRVJJRklFUl9KVU5JVCIsICIvdmFyL2xpYi9taW1vLWdyYWRlL2p1bml0LnhtbCIpCl9WM19DT0xMRUNURUQgPSBbXQpkZWYgcHl0ZXN0X3J1bnRlc3RfbG9ncmVwb3J0KHJlcG9ydCk6CiAgICBpZiByZXBvcnQud2hlbiA9PSAiY2FsbCIgb3IgKHJlcG9ydC53aGVuID09ICJzZXR1cCIgYW5kIHJlcG9ydC5za2lwcGVkKToKICAgICAgICBfVjNfQ09MTEVDVEVELmFwcGVuZCgocmVwb3J0Lm5vZGVpZCwgcmVwb3J0Lm91dGNvbWUpKQpkZWYgcHl0ZXN0X3Nlc3Npb25maW5pc2goc2Vzc2lvbiwgZXhpdHN0YXR1cyk6CiAgICB0cnk6CiAgICAgICAgaW1wb3J0IHhtbC5ldHJlZS5FbGVtZW50VHJlZSBhcyBFVAogICAgICAgIHN1aXRlID0gRVQuRWxlbWVudCgidGVzdHN1aXRlIiwgbmFtZT0idmVyaWZpZXIiLCB0ZXN0cz1zdHIobGVuKF9WM19DT0xMRUNURUQpKSkKICAgICAgICBmb3Igbm9kZWlkLCBvdXRjb21lIGluIF9WM19DT0xMRUNURUQ6CiAgICAgICAgICAgIG5hbWUgPSBub2RlaWQuc3BsaXQoIjo6IilbLTFdCiAgICAgICAgICAgIGNhc2UgPSBFVC5TdWJFbGVtZW50KHN1aXRlLCAidGVzdGNhc2UiLCBjbGFzc25hbWU9bm9kZWlkLCBuYW1lPW5hbWUpCiAgICAgICAgICAgIGlmIG91dGNvbWUgPT0gImZhaWxlZCI6CiAgICAgICAgICAgICAgICBFVC5TdWJFbGVtZW50KGNhc2UsICJmYWlsdXJlIiwgbWVzc2FnZT0iZmFpbGVkIikKICAgICAgICAgICAgZWxpZiBvdXRjb21lID09ICJza2lwcGVkIjoKICAgICAgICAgICAgICAgIEVULlN1YkVsZW1lbnQoY2FzZSwgInNraXBwZWQiLCBtZXNzYWdlPSJza2lwcGVkIikKICAgICAgICBFVC5FbGVtZW50VHJlZShzdWl0ZSkud3JpdGUoX1YzX0pVTklUX1BBVEgpCiAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgIHBhc3MK" | base64 -d >> ./conftest.py
      echo "installed verifier conftest hook (addopts cleared)" >> "$V/baseline.log"
    fi
    python3 - "$RES_B" "$CWD" > "$V/baseline-conftest-targets.txt" 2>/dev/null <<'PYEOF_BASELINE' || true
import os, re, sys
resolved, cwd = sys.argv[1], sys.argv[2]
seen = []
for tok in re.findall(r'[A-Za-z0-9_./-]+\.py', resolved):
    rel = tok
    if os.path.isabs(rel):
        try:
            rel = os.path.relpath(rel, cwd)
        except ValueError:
            continue
    if rel.startswith(".."):
        continue
    if os.path.isfile(os.path.join(cwd, rel)):
        d = os.path.dirname(rel) or "."
        if d not in seen:
            seen.append(d)
for d in ["."] + seen:
    print(d)
PYEOF_BASELINE
    while IFS= read -r _v5_d; do
      [ -n "$_v5_d" ] || continue
      _v5_cf="$CWD/$_v5_d/conftest.py"
      mkdir -p "$(dirname "$_v5_cf")"
      if ! grep -q "mimo-junit-archive/1" "$_v5_cf" 2>/dev/null; then
        echo "IyBtaW1vLWp1bml0LWFyY2hpdmUvMTogcGVyLXBoYXNlIGp1bml0IGFyY2hpdmUuCmltcG9ydCBvcyBhcyBfdjVfb3MKX1Y1X0RJUiA9IF92NV9vcy5lbnZpcm9uLmdldCgiTUlNT19WRVJJRklFUl9BUkNISVZFX0RJUiIsICIiKQpfVjVfQ09MTEVDVEVEID0gW10KZGVmIHB5dGVzdF9ydW50ZXN0X2xvZ3JlcG9ydChyZXBvcnQpOgogICAgaWYgcmVwb3J0LndoZW4gPT0gImNhbGwiIG9yIChyZXBvcnQud2hlbiA9PSAic2V0dXAiIGFuZCByZXBvcnQuc2tpcHBlZCk6CiAgICAgICAgX1Y1X0NPTExFQ1RFRC5hcHBlbmQoKHJlcG9ydC5ub2RlaWQsIHJlcG9ydC5vdXRjb21lKSkKZGVmIHB5dGVzdF9zZXNzaW9uZmluaXNoKHNlc3Npb24sIGV4aXRzdGF0dXMpOgogICAgdHJ5OgogICAgICAgIGlmIG5vdCBfVjVfRElSOgogICAgICAgICAgICByZXR1cm4KICAgICAgICBfdjVfb3MubWFrZWRpcnMoX1Y1X0RJUiwgZXhpc3Rfb2s9VHJ1ZSkKICAgICAgICBfdjVfY291bnRfcGF0aCA9IF92NV9vcy5wYXRoLmpvaW4oX1Y1X0RJUiwgImNvdW50IikKICAgICAgICB0cnk6CiAgICAgICAgICAgIHdpdGggb3BlbihfdjVfY291bnRfcGF0aCwgZW5jb2Rpbmc9InV0Zi04IikgYXMgX3Y1X2Y6CiAgICAgICAgICAgICAgICBfdjVfbiA9IGludCgoX3Y1X2YucmVhZCgpIG9yICIwIikuc3RyaXAoKSkKICAgICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgICAgICBfdjVfbiA9IDAKICAgICAgICBpbXBvcnQgeG1sLmV0cmVlLkVsZW1lbnRUcmVlIGFzIF92NV9FVAogICAgICAgIF92NV9zdWl0ZSA9IF92NV9FVC5FbGVtZW50KCJ0ZXN0c3VpdGUiLCBuYW1lPSJ2ZXJpZmllci1hcmNoaXZlIiwgdGVzdHM9c3RyKGxlbihfVjVfQ09MTEVDVEVEKSkpCiAgICAgICAgZm9yIF92NV9ub2RlaWQsIF92NV9vdXRjb21lIGluIF9WNV9DT0xMRUNURUQ6CiAgICAgICAgICAgIF92NV9wYXJ0cyA9IF92NV9ub2RlaWQuc3BsaXQoIjo6IikKICAgICAgICAgICAgX3Y1X2ZpbGUgPSBfdjVfcGFydHNbMF0KICAgICAgICAgICAgX3Y1X3Jlc3QgPSBfdjVfcGFydHNbMTpdCiAgICAgICAgICAgIF92NV9tb2QgPSBfdjVfZmlsZS5yZXBsYWNlKCIvIiwgIi4iKS5yZXBsYWNlKGNocig5MiksICIuIikKICAgICAgICAgICAgaWYgX3Y1X21vZC5lbmRzd2l0aCgiLnB5Iik6CiAgICAgICAgICAgICAgICBfdjVfbW9kID0gX3Y1X21vZFs6LTNdCiAgICAgICAgICAgIGlmIGxlbihfdjVfcmVzdCkgPiAxOgogICAgICAgICAgICAgICAgX3Y1X2NuID0gKF92NV9tb2QgKyAiLiIgKyAiLiIuam9pbihfdjVfcmVzdFs6LTFdKSkgaWYgX3Y1X21vZCBlbHNlICIuIi5qb2luKF92NV9yZXN0WzotMV0pCiAgICAgICAgICAgICAgICBfdjVfbmFtZSA9IF92NV9yZXN0Wy0xXQogICAgICAgICAgICBlbGlmIF92NV9yZXN0OgogICAgICAgICAgICAgICAgX3Y1X2NuID0gX3Y1X21vZAogICAgICAgICAgICAgICAgX3Y1X25hbWUgPSBfdjVfcmVzdFswXQogICAgICAgICAgICBlbHNlOgogICAgICAgICAgICAgICAgX3Y1X2NuID0gX3Y1X21vZAogICAgICAgICAgICAgICAgX3Y1X25hbWUgPSBfdjVfbm9kZWlkCiAgICAgICAgICAgIF92NV9jYXNlID0gX3Y1X0VULlN1YkVsZW1lbnQoX3Y1X3N1aXRlLCAidGVzdGNhc2UiLCBjbGFzc25hbWU9X3Y1X2NuLCBuYW1lPV92NV9uYW1lLCBmaWxlPV92NV9maWxlKQogICAgICAgICAgICBpZiBfdjVfb3V0Y29tZSA9PSAiZmFpbGVkIjoKICAgICAgICAgICAgICAgIF92NV9FVC5TdWJFbGVtZW50KF92NV9jYXNlLCAiZmFpbHVyZSIsIG1lc3NhZ2U9ImZhaWxlZCIpCiAgICAgICAgICAgIGVsaWYgX3Y1X291dGNvbWUgPT0gInNraXBwZWQiOgogICAgICAgICAgICAgICAgX3Y1X0VULlN1YkVsZW1lbnQoX3Y1X2Nhc2UsICJza2lwcGVkIiwgbWVzc2FnZT0ic2tpcHBlZCIpCiAgICAgICAgX3Y1X0VULkVsZW1lbnRUcmVlKF92NV9zdWl0ZSkud3JpdGUoX3Y1X29zLnBhdGguam9pbihfVjVfRElSLCAianVuaXQtaG9vay0lZC54bWwiICUgX3Y1X24pKQogICAgICAgIHdpdGggb3BlbihfdjVfY291bnRfcGF0aCwgInciLCBlbmNvZGluZz0idXRmLTgiKSBhcyBfdjVfZjoKICAgICAgICAgICAgX3Y1X2Yud3JpdGUoc3RyKF92NV9uICsgMSkpCiAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgIHBhc3MK" | base64 -d >> "$_v5_cf"
      fi
    done < "$V/baseline-conftest-targets.txt"
    echo "installed verifier junit archive hook" >> "$V/baseline.log"
    # The baseline runs to completion: -x/--exitfirst/--maxfail (from the
    # command, ini, or env) would truncate it at the first failure and hide
    # later skips/failures from fail-to-pass (measured: 000203 oracle
    # false-0). Neutralize maxfail via a wrapping pytest_configure hook
    # (previous same-file hook still runs); the reset below removes it, so
    # the agent path keeps the original command.
    while IFS= read -r _v6_d; do
      [ -n "$_v6_d" ] || continue
      _v6_cf="$CWD/$_v6_d/conftest.py"
      if ! grep -q "mimo-baseline-noexitfirst/1" "$_v6_cf" 2>/dev/null; then
        cat >> "$_v6_cf" <<'PYEOF_NOEXITFIRST' || true
# mimo-baseline-noexitfirst/1: run the pristine baseline to completion.
_prev_baseline_configure = globals().get("pytest_configure")
def pytest_configure(config):
    try:
        if _prev_baseline_configure is not None:
            _prev_baseline_configure(config)
    except Exception:
        pass
    try:
        if getattr(config.option, "maxfail", 0):
            config.option.maxfail = 1000000
    except Exception:
        pass
PYEOF_NOEXITFIRST
      fi
    done < "$V/baseline-conftest-targets.txt"
    echo "installed baseline noexitfirst hook" >> "$V/baseline.log"
  fi
  if [ "$RUNNER_B" = pytest ] || [ "$RUNNER_B" = unittest ]; then
    JUNIT_B=$GRADE/baseline/junit.xml; mkdir -p "${JUNIT_B%/*}" "$GRADE/baseline/junit-phases"
    START_B=$(date +%s)
    _V7_PHASES=$(grep -oE '(^|[^[:alnum:]_])(python[0-9.]* -m (pytest|unittest)|pytest)([^[:alnum:]_]|$)' "$V/baseline_resolved.txt" | wc -l)
    if [ "$_V7_PHASES" -ge 2 ] && command -v bash >/dev/null 2>&1; then
      cat > "$V/baseline-noerrexit.sh" <<'BASELINE_NOERREXIT_EOF'
# @7 baseline: hold errexit off so every test phase runs on pristine.
set -T 2>/dev/null || true
shopt -s extdebug 2>/dev/null || true
trap 'set +e 2>/dev/null || true' DEBUG 2>/dev/null || true
BASELINE_NOERREXIT_EOF
      BASH_ENV="$V/baseline-noerrexit.sh" PYTHONDONTWRITEBYTECODE=1 PYTHONPYCACHEPREFIX="$GRADE/pycache" PYTHONPATH="$GRADE/v10shim${PYTHONPATH:+:$PYTHONPATH}" MIMO_VERIFIER_UNITTEST_JUNIT="$GRADE/baseline/unittest-junit.xml" MIMO_VERIFIER_INTEGRITY_DIR="$GRADE/baseline" MIMO_VERIFIER_JUNIT="$GRADE/baseline/junit.xml" MIMO_VERIFIER_ARCHIVE_DIR="$GRADE/baseline/junit-phases" PYTHONUNBUFFERED=1 PYTEST_ADDOPTS="--junitxml=$JUNIT_B -p no:cacheprovider" timeout 1800 bash -c "$(cat /tests/test_command.sh)" > "$V/baseline_output.log" 2>&1
    else
      PYTHONDONTWRITEBYTECODE=1 PYTHONPYCACHEPREFIX="$GRADE/pycache" PYTHONPATH="$GRADE/v10shim${PYTHONPATH:+:$PYTHONPATH}" MIMO_VERIFIER_UNITTEST_JUNIT="$GRADE/baseline/unittest-junit.xml" MIMO_VERIFIER_INTEGRITY_DIR="$GRADE/baseline" MIMO_VERIFIER_JUNIT="$GRADE/baseline/junit.xml" MIMO_VERIFIER_ARCHIVE_DIR="$GRADE/baseline/junit-phases" PYTHONUNBUFFERED=1 PYTEST_ADDOPTS="--junitxml=$JUNIT_B -p no:cacheprovider" timeout 1800 sh -c "$(cat /tests/test_command.sh)" > "$V/baseline_output.log" 2>&1
    fi
    echo "$?" > "$V/baseline_rc.txt"
    echo "baseline_sec=$(($(date +%s) - START_B)) runner=$RUNNER_B rc=$(cat "$V/baseline_rc.txt")" > "$V/timing.log"
    cp "$V/baseline_output.log" "$GRADE/baseline/output.log"
  else
    echo "no baseline consumer for runner $RUNNER_B" >> "$V/baseline.log"
  fi
else
  echo "baseline hidden-test apply failed; grading keeps @5 rules" > "$V/baseline.log"
fi
# Reset to pristine bytes exactly (always, even without a baseline run).
git read-tree "$PRISTINE" || { echo "baseline reset failed" >&2; exit 1; }
git checkout-index -f -a || { echo "baseline restore failed" >&2; exit 1; }
git clean -fdq || { echo "baseline clean failed" >&2; exit 1; }
git ls-files --others --ignored --exclude-standard -z > /tmp/post_ignored.bin 2>/dev/null || : > /tmp/post_ignored.bin
if [ -s /tmp/post_ignored.bin ] || [ -s "$V/pre_ignored.bin" ]; then
  comm -z -13 "$V/pre_ignored.bin" /tmp/post_ignored.bin 2>/dev/null | xargs -0 -r rm -rf -- 2>/dev/null || true
fi
unset GIT_INDEX_FILE
# 1. The agent's change, computed by the verifier's own git against the clean
# base (same as @2).
test -f "$SNAP/workspace.tgz" || { echo "snapshot missing: $SNAP/workspace.tgz" >&2; exit 1; }
rm -rf /tmp/agentcopy && mkdir -p /tmp/agentcopy
tar -xzf "$SNAP/workspace.tgz" -C /tmp/agentcopy || { echo "snapshot unreadable" >&2; exit 1; }
rm -rf /tmp/agentcopy/.git
git --git-dir="$CWD/.git" show "$PRISTINE:.gitignore" > /tmp/base.gitignore 2>/dev/null || : > /tmp/base.gitignore
if git --git-dir="$CWD/.git" cat-file -e "$PRISTINE:.gitignore" 2>/dev/null; then
  cp /tmp/base.gitignore /tmp/agentcopy/.gitignore
else rm -f /tmp/agentcopy/.gitignore; fi
export GIT_INDEX_FILE=/tmp/agent.index; rm -f "$GIT_INDEX_FILE"
git --git-dir="$CWD/.git" --work-tree=/tmp/agentcopy read-tree "$PRISTINE" || { echo "clean-tree read failed" >&2; exit 1; }
git --git-dir="$CWD/.git" --work-tree=/tmp/agentcopy add -A
git --git-dir="$CWD/.git" --work-tree=/tmp/agentcopy diff --cached --binary "$PRISTINE" > "$V/agent.full.diff"
CHANGED=$(git --git-dir="$CWD/.git" --work-tree=/tmp/agentcopy diff --cached --name-only "$PRISTINE")
unset GIT_INDEX_FILE
# 2. @3 drops: @2 infra names and hidden-test paths, plus new-file runner
# configs and build outputs; tracked runner-config hunks revert to BASE.
TESTFILES=$(grep '^diff --git' /tests/test.patch | sed 's#.* b/##')
KEEP=/tmp/keep.list; REVERT=/tmp/revert.list; : > "$KEEP"; : > "$REVERT"; : > "$V/dropped.log"
for f in $CHANGED; do
  b=${f##*/}; drop=""; reverted=""
  case "$b" in conftest.py|pytest.ini|tox.ini|sitecustomize.py|usercustomize.py|*.pth|*_test.go) drop="test-infra";; esac
  if [ -z "$drop" ]; then
    case "$f" in */__pycache__/*|__pycache__/*) drop="binary artifact";; esac
    case "$b" in *.pyc|*.pyo|*.so|*.pyd|*.dll|*.dylib|*.o|*.a|*.class) drop="binary artifact";; esac
  fi
  if [ -z "$drop" ]; then
    case "$b" in .mocharc.cjs|.mocharc.js|.mocharc.json|.mocharc.mjs|.mocharc.yaml|.mocharc.yml|.nycrc|.nycrc.json|.rspec|.taprc|ava.config.cjs|ava.config.js|ava.config.mjs|build.rs|jasmine.json|jest.config.cjs|jest.config.js|jest.config.json|jest.config.mjs|jest.config.ts|jest.preset.js|jest.setup.cjs|jest.setup.js|jest.setup.mjs|jest.setup.ts|karma.conf.js|phpunit.dist.xml|phpunit.xml|phpunit.xml.dist|vitest.config.js|vitest.config.mts|vitest.config.ts|vitest.setup.js|vitest.setup.ts|vitest.shared.js|vitest.shared.ts|vitest.workspace.js|vitest.workspace.ts)
      if ! git --git-dir="$CWD/.git" cat-file -e "$PRISTINE:$f" 2>/dev/null; then drop="new runner config"; fi;;
    esac
  fi
  if [ -z "$drop" ]; then
    case "$f" in target/surefire-reports/*|target/failsafe-reports/*|build/test-results/*|.nyc_output/*|coverage/*)
      if ! git --git-dir="$CWD/.git" cat-file -e "$PRISTINE:$f" 2>/dev/null; then drop="new build output"; fi;;
    esac
  fi
  if [ -z "$drop" ] && printf '%s\n' "$TESTFILES" | grep -qxF -- "$f"; then drop="hidden-test path"; fi
  if [ -z "$drop" ]; then
    case "$b" in setup.cfg|pyproject.toml)
      if diff <(git --git-dir="$CWD/.git" show "$PRISTINE:$f" 2>/dev/null) "/tmp/agentcopy/$f" 2>/dev/null | grep -E '^[<>]' | grep -qiE 'pytest|addopts|plugins'; then drop="pytest config"; fi;;
    esac
  fi
  if [ -z "$drop" ]; then
    case "$f" in *.go)
      if grep -qE 'func TestMain[[:space:]]*\(' "/tmp/agentcopy/$f" 2>/dev/null; then drop="go TestMain"; fi;;
    esac
  fi
  if [ -z "$drop" ] && git --git-dir="$CWD/.git" cat-file -e "$PRISTINE:$f" 2>/dev/null; then
    CHLINES=$(diff <(git --git-dir="$CWD/.git" show "$PRISTINE:$f" 2>/dev/null) "/tmp/agentcopy/$f" 2>/dev/null | grep -E '^[<>]' || true)
    rule=""
    case "$b" in package.json)
      if printf '%s\n' "$CHLINES" | grep -qiE '"(jest|mocha|vitest|ava|tap|karma|jasmine|nyc|c8)"[[:space:]]*:'; then rule="package.json runner key"; fi;;
    esac
    case "$b" in pom.xml)
      if printf '%s\n' "$CHLINES" | grep -qiE 'surefire|failsafe|skipTests|<excludes?>'; then rule="pom.xml surefire"; fi;;
    esac
    case "$b" in build.gradle|build.gradle.kts)
      if printf '%s\n' "$CHLINES" | grep -qiE 'exclude|ignoreFailures|useJUnit|test[[:space:]]*\{'; then rule="gradle test block"; fi;;
    esac
    case "$b" in .rspec)
      if printf '%s\n' "$CHLINES" | grep -qE -- '--require|--format|--tag|--exclude-pattern'; then rule="rspec options"; fi;;
    esac
    case "$b" in phpunit.xml|phpunit.xml.dist|phpunit.dist.xml)
      if printf '%s\n' "$CHLINES" | grep -qiE 'bootstrap|suffix=|exclude|executionOrder|printer'; then rule="phpunit config"; fi;;
    esac
    case "$b" in go.mod)
      if printf '%s\n' "$CHLINES" | grep -qiE 'toolchain'; then rule="go toolchain"; fi;;
    esac
    case "$b" in .mocharc.js|.mocharc.cjs|.mocharc.mjs|.mocharc.json|.mocharc.yml|.mocharc.yaml)
      if printf '%s\n' "$CHLINES" | grep -qiE 'spec|require|ignore|exclude|grep|invert|reporter'; then rule="mocha options"; fi;;
    esac
    if [ -n "$rule" ]; then reverted="$rule"; echo "reverted $f ($rule)" >> "$V/dropped.log"; echo "$f" >> "$REVERT"; fi
  fi
  if [ -n "$drop" ]; then echo "dropped $f ($drop)" >> "$V/dropped.log"; elif [ -z "$reverted" ]; then echo "$f" >> "$KEEP"; fi
done
# 3. Copy the kept files over the pristine tree (deletions too), then
# restore reverted configs to BASE.
while IFS= read -r f; do
  [ -z "$f" ] && continue
  if [ -e "/tmp/agentcopy/$f" ] || [ -L "/tmp/agentcopy/$f" ]; then
    mkdir -p "$(dirname "$f")"
    cp -a "/tmp/agentcopy/$f" "$f"
  else rm -f "$f"; fi
done < "$KEEP"
while IFS= read -r f; do
  [ -z "$f" ] && continue
  if git --git-dir="$CWD/.git" cat-file -e "$PRISTINE:$f" 2>/dev/null; then
    git --git-dir="$CWD/.git" show "$PRISTINE:$f" > "$f"
  else rm -f "$f"; fi
done < "$REVERT"
# 3b. Source that reaches into the test runner or forces the exit code is not a fix.
# Per-file gate: universal signatures on any path, exit(0) only on Ruby/PHP.
export GIT_INDEX_FILE=/tmp/kept.index; rm -f "$GIT_INDEX_FILE"
git read-tree "$PRISTINE" && git add -A . && git diff --cached "$PRISTINE" > "$V/agent.kept.diff" || {
  echo "kept-tree diff failed" >&2; exit 1
}
unset GIT_INDEX_FILE
python3 - "$V/agent.kept.diff" <<'PYEOF' > "$V/tamper.log" 2>&1
import sys, re
diff = open(sys.argv[1], encoding="utf-8", errors="replace").read()
universal = ['\\b_pytest\\b', '\\bpytest_(runtest|configure|collection|sessionfinish|sessionstart|report|terminal|unconfigure)', '\\bTestReport\\b', 'junitxml', '\\bos\\._exit\\b', '\\batexit\\b', '\\bos\\.Exit\\s*\\(', '\\bprocess\\.exit\\s*\\(', '\\bprocess\\.exitCode\\s*=', '\\bDeno\\.exit\\s*\\(', '\\bSystem\\.exit\\s*\\(', '\\bRuntime\\.getRuntime\\(\\)\\.halt\\s*\\(', 'process::exit\\s*\\(', '\\bstd::process::exit', '\\bKernel\\.exit\\b', '\\bglobal\\.(it|test|describe|fit)\\s*=']
scoped = [(['.rb'], '\\bexit\\s*\\(\\s*0\\s*\\)|\\bexit!\\s*\\(\\s*0?\\s*\\)'), (['.php'], '\\bexit\\s*\\(\\s*0\\s*\\)|\\bdie\\s*\\(\\s*0\\s*\\)')]
cur = None
added = {}
for line in diff.splitlines():
    if line.startswith("+++ b/"):
        cur = line[6:]
        added.setdefault(cur, [])
    elif cur is not None and line.startswith("+") and not line.startswith("+++"):
        added[cur].append(line[1:])
for path, lines in added.items():
    text = "\n".join(lines)
    for sig in universal:
        if re.search(sig, text):
            print("tamper %s in %s" % (sig, path))
            sys.exit(10)
    leaf = path.rsplit("/", 1)[-1]
    ext = "." + leaf.rsplit(".", 1)[-1].lower() if "." in leaf else ""
    for exts, sig in scoped:
        if ext in exts and re.search(sig, text):
            print("scoped tamper %s in %s" % (sig, path))
            sys.exit(10)
PYEOF
if [ $? -eq 10 ]; then
  echo 0 > "$V/reward.txt"; echo "REWARD=0 tamper signature in agent diff"; exit 0
fi
# 4. Hidden tests, then resolve the real test command. Opaque build-env
# wrappers (mimo_build_env.tar.gz.b64, from the hidden patch) decode here:
# the tarball is trusted verifier-side bundle content, never agent bytes.
printf '%s\n' "$TESTFILES" | while IFS= read -r tf; do
  [ -z "$tf" ] && continue
  if git cat-file -e "$PRISTINE:$tf" 2>/dev/null; then
    git checkout -q "$PRISTINE" -- "$tf" 2>/dev/null || true
  else
    git rm -f --cached "$tf" >/dev/null 2>&1 || true
    rm -f "$tf"
  fi
done
if ! git apply --verbose /tests/test.patch > "$V/apply.log" 2>&1; then
  cat "$V/apply.log" >&2
  echo "the hidden tests could not be applied (testbed problem, not scored)" >&2
  exit 1
fi
RESOLVED=$(cat /tests/test_command.sh)
for ref in $(grep -oE '[^ "]*mimo_test_command\.sh' /tests/test_command.sh | sort -u); do
  base=${ref##*/}
  if [ -f "$base" ]; then RESOLVED="$RESOLVED
$(cat "$base")"; fi
done
if printf '%s' "$RESOLVED" | grep -q 'build_env/test_command'; then
  if [ -f mimo_build_env.tar.gz.b64 ]; then
    rm -rf "$GRADE/build_env" && mkdir -p "$GRADE/build_env"
    if base64 -d mimo_build_env.tar.gz.b64 2>/dev/null | tar -xzf - -C "$GRADE/build_env" 2>/dev/null; then
      BE_TC=$(find "$GRADE/build_env" -name 'test_command.sh' | head -1)
      if [ -n "$BE_TC" ]; then RESOLVED="$RESOLVED
$(cat "$BE_TC")"; fi
    fi
  fi
fi
printf '%s' "$RESOLVED" > "$V/resolved_command.txt"
RUNNER=custom
if printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])go +test( |$)'; then RUNNER=go-test
elif printf '%s' "$RESOLVED" | grep -qE 'GO_BIN" +test( |$)'; then RUNNER=go-test
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])jest([^[:alnum:]_]|$)'; then RUNNER=jest
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])vitest([^[:alnum:]_]|$)'; then RUNNER=vitest
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])_?mocha([^[:alnum:]_]|$)'; then RUNNER=mocha
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])ava([^[:alnum:]_]|$)'; then RUNNER=ava
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])tap([^[:alnum:]_]|$)'; then RUNNER=tap
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])karma([^[:alnum:]_]|$)'; then RUNNER=karma
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])jasmine([^[:alnum:]_]|$)'; then RUNNER=jasmine
elif printf '%s' "$RESOLVED" | grep -qE 'node +--test([^[:alnum:]_]|$)'; then RUNNER=node-test
elif printf '%s' "$RESOLVED" | grep -qE 'cargo +test([^[:alnum:]_]|$)'; then RUNNER=cargo-test
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])rspec([^[:alnum:]_]|$)'; then RUNNER=rspec
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])phpunit([^[:alnum:]_]|$)'; then RUNNER=phpunit
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])mvn([^[:alnum:]_]|$)|surefire|failsafe'; then RUNNER=mvn
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])gradlew?([^[:alnum:]_]|$)'; then RUNNER=gradle
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])pytest([^[:alnum:]_]|$)'; then RUNNER=pytest
elif printf '%s' "$RESOLVED" | grep -qE '\-m +unittest([^[:alnum:]_]|$)'; then RUNNER=unittest
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])forge +test([^[:alnum:]_]|$)'; then RUNNER=forge
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])node([^[:alnum:]_]|$)'; then RUNNER=node-run
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])(make|ctest|cmake)([^[:alnum:]_]|$)'; then RUNNER=make
elif printf '%s' "$RESOLVED" | grep -qE '(^|[^[:alnum:]_])bats([^[:alnum:]_]|$)'; then RUNNER=bats
fi
echo "RUNNER=$RUNNER" > "$V/runner.txt"
# Verifier-owned conftest hook for pytest commands that clear our addopts:
# a root conftest.py is always collected, so the structured report survives
# any env scrubbing. Appended after the hidden-test apply, never clobbering.
if [ "$RUNNER" = pytest ]; then
  CLEARED=0
  printf '%s' "$RESOLVED" | grep -q 'unset.*PYTEST_ADDOPTS' && CLEARED=1
  printf '%s' "$RESOLVED" | grep -q 'PYTEST_ADDOPTS=' && CLEARED=1
  printf '%s' "$RESOLVED" | grep -qE 'env +([^ ]+ +)*-u([^ ]* +)*PYTEST_ADDOPTS|env +-u +PYTEST_ADDOPTS' && CLEARED=1
  if [ "$CLEARED" = 1 ]; then
    echo "IyBzZXBhcmF0ZS12ZXJpZmllckAzIGhvb2s6IHN0cnVjdHVyZWQgcmVwb3J0IGZvciBhZGRvcHRzLWNsZWFyZWQgcnVucy4KaW1wb3J0IG9zIGFzIF92M19vcwpfVjNfSlVOSVRfUEFUSCA9IF92M19vcy5lbnZpcm9uLmdldCgiTUlNT19WRVJJRklFUl9KVU5JVCIsICIvdmFyL2xpYi9taW1vLWdyYWRlL2p1bml0LnhtbCIpCl9WM19DT0xMRUNURUQgPSBbXQpkZWYgcHl0ZXN0X3J1bnRlc3RfbG9ncmVwb3J0KHJlcG9ydCk6CiAgICBpZiByZXBvcnQud2hlbiA9PSAiY2FsbCIgb3IgKHJlcG9ydC53aGVuID09ICJzZXR1cCIgYW5kIHJlcG9ydC5za2lwcGVkKToKICAgICAgICBfVjNfQ09MTEVDVEVELmFwcGVuZCgocmVwb3J0Lm5vZGVpZCwgcmVwb3J0Lm91dGNvbWUpKQpkZWYgcHl0ZXN0X3Nlc3Npb25maW5pc2goc2Vzc2lvbiwgZXhpdHN0YXR1cyk6CiAgICB0cnk6CiAgICAgICAgaW1wb3J0IHhtbC5ldHJlZS5FbGVtZW50VHJlZSBhcyBFVAogICAgICAgIHN1aXRlID0gRVQuRWxlbWVudCgidGVzdHN1aXRlIiwgbmFtZT0idmVyaWZpZXIiLCB0ZXN0cz1zdHIobGVuKF9WM19DT0xMRUNURUQpKSkKICAgICAgICBmb3Igbm9kZWlkLCBvdXRjb21lIGluIF9WM19DT0xMRUNURUQ6CiAgICAgICAgICAgIG5hbWUgPSBub2RlaWQuc3BsaXQoIjo6IilbLTFdCiAgICAgICAgICAgIGNhc2UgPSBFVC5TdWJFbGVtZW50KHN1aXRlLCAidGVzdGNhc2UiLCBjbGFzc25hbWU9bm9kZWlkLCBuYW1lPW5hbWUpCiAgICAgICAgICAgIGlmIG91dGNvbWUgPT0gImZhaWxlZCI6CiAgICAgICAgICAgICAgICBFVC5TdWJFbGVtZW50KGNhc2UsICJmYWlsdXJlIiwgbWVzc2FnZT0iZmFpbGVkIikKICAgICAgICAgICAgZWxpZiBvdXRjb21lID09ICJza2lwcGVkIjoKICAgICAgICAgICAgICAgIEVULlN1YkVsZW1lbnQoY2FzZSwgInNraXBwZWQiLCBtZXNzYWdlPSJza2lwcGVkIikKICAgICAgICBFVC5FbGVtZW50VHJlZShzdWl0ZSkud3JpdGUoX1YzX0pVTklUX1BBVEgpCiAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgIHBhc3MK" | base64 -d >> ./conftest.py
    touch "$GRADE/hook_installed"
    echo "installed verifier conftest hook (addopts cleared)" >> "$V/dropped.log"
  fi
  python3 - "$RESOLVED" "$CWD" > "$V/conftest-targets.txt" 2>/dev/null <<'PYEOF' || true
import os, re, sys
resolved, cwd = sys.argv[1], sys.argv[2]
seen = []
for tok in re.findall(r'[A-Za-z0-9_./-]+\.py', resolved):
    rel = tok
    if os.path.isabs(rel):
        try:
            rel = os.path.relpath(rel, cwd)
        except ValueError:
            continue
    if rel.startswith(".."):
        continue
    if os.path.isfile(os.path.join(cwd, rel)):
        d = os.path.dirname(rel) or "."
        if d not in seen:
            seen.append(d)
for d in ["."] + seen:
    print(d)
PYEOF
  while IFS= read -r _v5_d; do
    [ -n "$_v5_d" ] || continue
    _v5_cf="$CWD/$_v5_d/conftest.py"
    mkdir -p "$(dirname "$_v5_cf")"
    if ! grep -q "mimo-junit-archive/1" "$_v5_cf" 2>/dev/null; then
      echo "IyBtaW1vLWp1bml0LWFyY2hpdmUvMTogcGVyLXBoYXNlIGp1bml0IGFyY2hpdmUuCmltcG9ydCBvcyBhcyBfdjVfb3MKX1Y1X0RJUiA9IF92NV9vcy5lbnZpcm9uLmdldCgiTUlNT19WRVJJRklFUl9BUkNISVZFX0RJUiIsICIiKQpfVjVfQ09MTEVDVEVEID0gW10KZGVmIHB5dGVzdF9ydW50ZXN0X2xvZ3JlcG9ydChyZXBvcnQpOgogICAgaWYgcmVwb3J0LndoZW4gPT0gImNhbGwiIG9yIChyZXBvcnQud2hlbiA9PSAic2V0dXAiIGFuZCByZXBvcnQuc2tpcHBlZCk6CiAgICAgICAgX1Y1X0NPTExFQ1RFRC5hcHBlbmQoKHJlcG9ydC5ub2RlaWQsIHJlcG9ydC5vdXRjb21lKSkKZGVmIHB5dGVzdF9zZXNzaW9uZmluaXNoKHNlc3Npb24sIGV4aXRzdGF0dXMpOgogICAgdHJ5OgogICAgICAgIGlmIG5vdCBfVjVfRElSOgogICAgICAgICAgICByZXR1cm4KICAgICAgICBfdjVfb3MubWFrZWRpcnMoX1Y1X0RJUiwgZXhpc3Rfb2s9VHJ1ZSkKICAgICAgICBfdjVfY291bnRfcGF0aCA9IF92NV9vcy5wYXRoLmpvaW4oX1Y1X0RJUiwgImNvdW50IikKICAgICAgICB0cnk6CiAgICAgICAgICAgIHdpdGggb3BlbihfdjVfY291bnRfcGF0aCwgZW5jb2Rpbmc9InV0Zi04IikgYXMgX3Y1X2Y6CiAgICAgICAgICAgICAgICBfdjVfbiA9IGludCgoX3Y1X2YucmVhZCgpIG9yICIwIikuc3RyaXAoKSkKICAgICAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgICAgICBfdjVfbiA9IDAKICAgICAgICBpbXBvcnQgeG1sLmV0cmVlLkVsZW1lbnRUcmVlIGFzIF92NV9FVAogICAgICAgIF92NV9zdWl0ZSA9IF92NV9FVC5FbGVtZW50KCJ0ZXN0c3VpdGUiLCBuYW1lPSJ2ZXJpZmllci1hcmNoaXZlIiwgdGVzdHM9c3RyKGxlbihfVjVfQ09MTEVDVEVEKSkpCiAgICAgICAgZm9yIF92NV9ub2RlaWQsIF92NV9vdXRjb21lIGluIF9WNV9DT0xMRUNURUQ6CiAgICAgICAgICAgIF92NV9wYXJ0cyA9IF92NV9ub2RlaWQuc3BsaXQoIjo6IikKICAgICAgICAgICAgX3Y1X2ZpbGUgPSBfdjVfcGFydHNbMF0KICAgICAgICAgICAgX3Y1X3Jlc3QgPSBfdjVfcGFydHNbMTpdCiAgICAgICAgICAgIF92NV9tb2QgPSBfdjVfZmlsZS5yZXBsYWNlKCIvIiwgIi4iKS5yZXBsYWNlKGNocig5MiksICIuIikKICAgICAgICAgICAgaWYgX3Y1X21vZC5lbmRzd2l0aCgiLnB5Iik6CiAgICAgICAgICAgICAgICBfdjVfbW9kID0gX3Y1X21vZFs6LTNdCiAgICAgICAgICAgIGlmIGxlbihfdjVfcmVzdCkgPiAxOgogICAgICAgICAgICAgICAgX3Y1X2NuID0gKF92NV9tb2QgKyAiLiIgKyAiLiIuam9pbihfdjVfcmVzdFs6LTFdKSkgaWYgX3Y1X21vZCBlbHNlICIuIi5qb2luKF92NV9yZXN0WzotMV0pCiAgICAgICAgICAgICAgICBfdjVfbmFtZSA9IF92NV9yZXN0Wy0xXQogICAgICAgICAgICBlbGlmIF92NV9yZXN0OgogICAgICAgICAgICAgICAgX3Y1X2NuID0gX3Y1X21vZAogICAgICAgICAgICAgICAgX3Y1X25hbWUgPSBfdjVfcmVzdFswXQogICAgICAgICAgICBlbHNlOgogICAgICAgICAgICAgICAgX3Y1X2NuID0gX3Y1X21vZAogICAgICAgICAgICAgICAgX3Y1X25hbWUgPSBfdjVfbm9kZWlkCiAgICAgICAgICAgIF92NV9jYXNlID0gX3Y1X0VULlN1YkVsZW1lbnQoX3Y1X3N1aXRlLCAidGVzdGNhc2UiLCBjbGFzc25hbWU9X3Y1X2NuLCBuYW1lPV92NV9uYW1lLCBmaWxlPV92NV9maWxlKQogICAgICAgICAgICBpZiBfdjVfb3V0Y29tZSA9PSAiZmFpbGVkIjoKICAgICAgICAgICAgICAgIF92NV9FVC5TdWJFbGVtZW50KF92NV9jYXNlLCAiZmFpbHVyZSIsIG1lc3NhZ2U9ImZhaWxlZCIpCiAgICAgICAgICAgIGVsaWYgX3Y1X291dGNvbWUgPT0gInNraXBwZWQiOgogICAgICAgICAgICAgICAgX3Y1X0VULlN1YkVsZW1lbnQoX3Y1X2Nhc2UsICJza2lwcGVkIiwgbWVzc2FnZT0ic2tpcHBlZCIpCiAgICAgICAgX3Y1X0VULkVsZW1lbnRUcmVlKF92NV9zdWl0ZSkud3JpdGUoX3Y1X29zLnBhdGguam9pbihfVjVfRElSLCAianVuaXQtaG9vay0lZC54bWwiICUgX3Y1X24pKQogICAgICAgIHdpdGggb3BlbihfdjVfY291bnRfcGF0aCwgInciLCBlbmNvZGluZz0idXRmLTgiKSBhcyBfdjVfZjoKICAgICAgICAgICAgX3Y1X2Yud3JpdGUoc3RyKF92NV9uICsgMSkpCiAgICBleGNlcHQgRXhjZXB0aW9uOgogICAgICAgIHBhc3MK" | base64 -d >> "$_v5_cf"
    fi
  done < "$V/conftest-targets.txt"
  echo "installed verifier junit archive hook" >> "$V/dropped.log"
  while IFS= read -r _v10_d; do
    [ -n "$_v10_d" ] || continue
    _v10_cf="$CWD/$_v10_d/conftest.py"
    mkdir -p "$(dirname "$_v10_cf")"
    if ! grep -q "mimo-integrity/1" "$_v10_cf" 2>/dev/null; then
      echo "IyBtaW1vLWludGVncml0eS8xOiBydW5uZXItaW50ZXJuYWwgaW50ZWdyaXR5IGNoZWNrLgppbXBvcnQgb3MgYXMgX3YxMF9vcwpfVjEwX0RJUiA9IF92MTBfb3MuZW52aXJvbi5nZXQoIk1JTU9fVkVSSUZJRVJfSU5URUdSSVRZX0RJUiIsICIiKQpfVjEwX09SSUcgPSB7fQp0cnk6CiAgICBpbXBvcnQgcHl0ZXN0IGFzIF92MTBfcHl0ZXN0CiAgICBfVjEwX09SSUdbInB5dGVzdC5GdW5jdGlvbi5ydW50ZXN0Il0gPSBfdjEwX3B5dGVzdC5GdW5jdGlvbi5ydW50ZXN0CmV4Y2VwdCBFeGNlcHRpb246CiAgICBfdjEwX3B5dGVzdCA9IE5vbmUKdHJ5OgogICAgaW1wb3J0IF9weXRlc3QucHl0aG9uIGFzIF92MTBfcHAKICAgIF9WMTBfT1JJR1siX3B5dGVzdC5weXRob24uRnVuY3Rpb24ucnVudGVzdCJdID0gX3YxMF9wcC5GdW5jdGlvbi5ydW50ZXN0CmV4Y2VwdCBFeGNlcHRpb246CiAgICBfdjEwX3BwID0gTm9uZQp0cnk6CiAgICBpbXBvcnQgdW5pdHRlc3QgYXMgX3YxMF91dAogICAgX1YxMF9PUklHWyJ1bml0dGVzdC5UZXN0Q2FzZS5ydW4iXSA9IF92MTBfdXQuVGVzdENhc2UucnVuCmV4Y2VwdCBFeGNlcHRpb246CiAgICBfdjEwX3V0ID0gTm9uZQpfdjEwX3ByZXZfc2Vzc2lvbmZpbmlzaCA9IGdsb2JhbHMoKS5nZXQoInB5dGVzdF9zZXNzaW9uZmluaXNoIikKZGVmIHB5dGVzdF9zZXNzaW9uZmluaXNoKHNlc3Npb24sIGV4aXRzdGF0dXMpOgogICAgdHJ5OgogICAgICAgIGlmIF92MTBfcHJldl9zZXNzaW9uZmluaXNoIGlzIG5vdCBOb25lOgogICAgICAgICAgICBfdjEwX3ByZXZfc2Vzc2lvbmZpbmlzaChzZXNzaW9uLCBleGl0c3RhdHVzKQogICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICBwYXNzCiAgICB0cnk6CiAgICAgICAgaWYgbm90IF9WMTBfRElSOgogICAgICAgICAgICByZXR1cm4KICAgICAgICBfdjEwX2NoYW5nZWQgPSBbXQogICAgICAgIGlmIF92MTBfcHl0ZXN0IGlzIG5vdCBOb25lIGFuZCBfdjEwX3B5dGVzdC5GdW5jdGlvbi5ydW50ZXN0IGlzIG5vdCBfVjEwX09SSUcuZ2V0KCJweXRlc3QuRnVuY3Rpb24ucnVudGVzdCIpOgogICAgICAgICAgICBfdjEwX2NoYW5nZWQuYXBwZW5kKCJweXRlc3QuRnVuY3Rpb24ucnVudGVzdCIpCiAgICAgICAgaWYgX3YxMF9wcCBpcyBub3QgTm9uZSBhbmQgX3YxMF9wcC5GdW5jdGlvbi5ydW50ZXN0IGlzIG5vdCBfVjEwX09SSUcuZ2V0KCJfcHl0ZXN0LnB5dGhvbi5GdW5jdGlvbi5ydW50ZXN0Iik6CiAgICAgICAgICAgIF92MTBfY2hhbmdlZC5hcHBlbmQoIl9weXRlc3QucHl0aG9uLkZ1bmN0aW9uLnJ1bnRlc3QiKQogICAgICAgIGlmIF92MTBfdXQgaXMgbm90IE5vbmUgYW5kIF92MTBfdXQuVGVzdENhc2UucnVuIGlzIG5vdCBfVjEwX09SSUcuZ2V0KCJ1bml0dGVzdC5UZXN0Q2FzZS5ydW4iKToKICAgICAgICAgICAgX3YxMF9jaGFuZ2VkLmFwcGVuZCgidW5pdHRlc3QuVGVzdENhc2UucnVuIikKICAgICAgICBfdjEwX29zLm1ha2VkaXJzKF9WMTBfRElSLCBleGlzdF9vaz1UcnVlKQogICAgICAgIF92MTBfdGV4dCA9ICgiQ0hBTkdFRCAiICsgIiwiLmpvaW4oX3YxMF9jaGFuZ2VkKSkgaWYgX3YxMF9jaGFuZ2VkIGVsc2UgIk9LIgogICAgICAgIHdpdGggb3BlbihfdjEwX29zLnBhdGguam9pbihfVjEwX0RJUiwgImludGVncml0eS50eHQiKSwgInciLCBlbmNvZGluZz0idXRmLTgiKSBhcyBfdjEwX2Y6CiAgICAgICAgICAgIF92MTBfZi53cml0ZShfdjEwX3RleHQgKyAiXG4iKQogICAgZXhjZXB0IEV4Y2VwdGlvbjoKICAgICAgICBwYXNzCg==" | base64 -d >> "$_v10_cf"
    fi
  done < "$V/conftest-targets.txt"
  echo "installed verifier integrity hook" >> "$V/dropped.log"
fi
export MIMO_VERIFIER_JUNIT="$GRADE/junit.xml"
JUNIT=$GRADE/junit.xml; mkdir -p "${JUNIT%/*}"
# @5 per-phase junit archive: every pytest session appends its outcomes here
# so multi-phase commands grade all phases, not just the last report.
JUNIT_PHASES=$GRADE/junit-phases; mkdir -p "$JUNIT_PHASES"
# @10: no bytecode shadow may survive into grading.
find "$CWD" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
find "$CWD" -name '*.pyc' -delete 2>/dev/null || true
mkdir -p "$GRADE/pycache"

# PYTHONUNBUFFERED so the pytest session header reaches the log even when the
# run is killed import-time (same as @2).
_START_A=$(date +%s)
MIMO_VERIFIER_ARCHIVE_DIR="$JUNIT_PHASES" MIMO_VERIFIER_UNITTEST_JUNIT="$GRADE/unittest-junit.xml" MIMO_VERIFIER_INTEGRITY_DIR="$GRADE" PYTHONDONTWRITEBYTECODE=1 PYTHONPYCACHEPREFIX="$GRADE/pycache" PYTHONPATH="$GRADE/v10shim${PYTHONPATH:+:$PYTHONPATH}" PYTHONUNBUFFERED=1 PYTEST_ADDOPTS="--junitxml=$JUNIT -p no:cacheprovider" timeout 1800 sh -c "$(cat /tests/test_command.sh)" > "$V/test_output.log" 2>&1
RC=$?
echo "agent_sec=$(($(date +%s) - _START_A))" >> "$V/timing.log"
python3 - "$JUNIT" "$RC" /tests/test.patch "$V/test_output.log" /tests/test_command.sh "$CWD" <<'PYEOF' > "$V/reward.txt" 2> "$V/junit-grade.log"
import sys, re, base64, binascii, glob, os, xml.etree.ElementTree as ET
junit_path, rc, patch_path, output_path, cmd_path, cwd = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6]
patch = open(patch_path, encoding="utf-8", errors="replace").read()
ids = set(re.findall(r'(\S+\.py::[^\s"\']+)', patch.split("mimo_test_command.sh")[-1]))
output = open(output_path, encoding="utf-8", errors="replace").read()
output = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b[()][0-9A-B]|\r", "", output)
cmd_text = open(cmd_path, encoding="utf-8", errors="replace").read()
mimo = ""
for ref in re.findall(r'(\S*mimo_test_command\.sh)', cmd_text):
    try:
        mimo += open(ref.split("/")[-1], encoding="utf-8", errors="replace").read() + "\n"
    except OSError:
        pass
if "build_env/test_command" in cmd_text + mimo:
    for root, _dirs, files in os.walk("/var/lib/mimo-grade/build_env"):
        for fn in files:
            if fn == "test_command.sh":
                try:
                    mimo += open(os.path.join(root, fn), encoding="utf-8", errors="replace").read() + "\n"
                except OSError:
                    pass
hay = cmd_text + "\n" + mimo + "\n" + patch.split("mimo_test_command.sh")[-1]
for tok in re.findall(r'[A-Za-z0-9+/]{40,}={0,2}', hay):
    try:
        hay += base64.b64decode(tok, validate=True).decode("utf-8", "replace")
    except (binascii.Error, ValueError):
        pass
order = [
    ("go-test", r"(?<![\w])go\s+test\b|GO_BIN\"\s+test\b|\$GO_BIN\"\s+test"),
    ("jest", r"(?<![\w])jest\b"),
    ("vitest", r"(?<![\w])vitest\b"),
    ("mocha", r"(?<![\w])mocha\b|_mocha\b"),
    ("ava", r"(?<![\w])ava\b"),
    ("tap", r"(?<![\w])tap\b"),
    ("karma", r"(?<![\w])karma\b"),
    ("jasmine", r"(?<![\w])jasmine\b"),
    ("node-test", r"node\s+--test\b"),
    ("cargo-test", r"cargo\s+test\b"),
    ("rspec", r"(?<![\w])rspec\b"),
    ("phpunit", r"(?<![\w])phpunit\b"),
    ("mvn", r"(?<![\w])mvn\b|surefire|failsafe"),
    ("gradle", r"(?<![\w])gradlew?\b"),
    ("pytest", r"(?<![\w])pytest\b"),
    ("unittest", r"-m\s+unittest\b"),
    ("forge", r"(?<![\w])forge\s+test\b"),
    ("node-run", r"(?<![\w])node\b"),
    ("make", r"(?<![\w])(make|ctest|cmake)\b"),
    ("bats", r"(?<![\w])bats\b"),
]
runner = "custom"
for name, rx in order:
    if re.search(rx, hay):
        runner = name
        break
if runner == "tap" and (re.search(r"(^|\s)-R\s+\S*terse\b|reporters?\s*[=:]\s*\S*terse\b", hay) is not None or (re.search(r"Asserts:\s+[^\n]*\d+\s+passed", output) is not None and re.search(r"^(not )?ok\b", output, re.M) is None and re.search(r"\d+\s+passing", output) is None)):
    runner = "terse"
if runner == "tap" and (re.search(r"(^|\s)-R\s+\S*spec\b|reporters?\s*[=:]\s*\S*spec\b", hay) is not None or (re.search(r"\d+\s+passing", output) is not None and re.search(r"^(not )?ok\b", output, re.M) is None)):
    runner = "mocha"
sys.stderr.write("runner=%s rc=%d\n" % (runner, rc))
_v10_integrity = ""
for _v10_name in ("integrity.txt", "integrity-unittest.txt"):
    try:
        with open(os.path.join(os.path.dirname(junit_path), _v10_name), encoding="utf-8", errors="replace") as _v10f:
            _v10_text = _v10f.read().strip()
        if _v10_text.startswith("CHANGED"):
            _v10_integrity = _v10_text
            break
    except Exception:
        pass
if _v10_integrity.startswith("CHANGED"):
    print(0)
    sys.stderr.write("runner integrity changed: %s\n" % _v10_integrity)
    sys.exit()
blank = len(output.strip()) == 0
def fallback():
    print(1 if rc == 0 else 0)
    sys.stderr.write("rc=%d %s: exit-code grading\n" % (rc, runner))
    sys.exit()
if runner == "pytest":
    cleared = re.search(r'unset\s+[^\n]*PYTEST_ADDOPTS|PYTEST_ADDOPTS\s*=|env\s+[^\n]*-u\s+PYTEST_ADDOPTS', hay) is not None
    has_pytest = "pytest" in hay.lower()
    started = has_pytest and ("test session starts" in output or re.search(r'collected \d+ items?', output) is not None)
    flag = os.path.exists("/var/lib/mimo-grade/hook_installed") or ((not cleared) and (started or (len(output.strip()) == 0 and has_pytest)))
    def grade_noreport():
        if flag:
            sys.stderr.write("rc=%d junit missing after pytest start\n" % rc)
            print(0)
        else:
            print(1 if rc == 0 else 0)
            sys.stderr.write("rc=%d no junit: exit-code grading\n" % rc)
        sys.exit()
    arch = []
    for phase in sorted(glob.glob(os.path.join(os.path.dirname(junit_path), "junit-phases", "junit-hook-*.xml"))):
        try:
            praw = open(phase, "rb").read()
        except Exception:
            continue
        if praw:
            arch.append(praw)
    try:
        raw = open(junit_path, "rb").read()
    except OSError:
        raw = b""
    try:
        cases = list(ET.fromstring(raw).iter("testcase")) if raw else []
    except Exception:
        grade_noreport()
    if not raw and not arch:
        grade_noreport()
    for rep in arch:
        try:
            cases.extend(list(ET.fromstring(rep).iter("testcase")))
        except Exception:
            pass
    bad = [c for c in cases if c.find("failure") is not None or c.find("error") is not None]
    skipped = [c for c in cases if c.find("skipped") is not None]
    # Option values (e.g. --deselect=path.py::test_x) are not selected node IDs.
    ids = {i for i in ids if not i.startswith("-")}
    def _comps(p):
        p = p.replace("\\", "/").strip()
        while p.startswith("./"):
            p = p[2:]
        p = p.lstrip("/")
        if p.endswith(".py"):
            p = p[:-3]
        return [c for c in re.split(r"[/.]+", p) if c]
    def _parse_node(n):
        parts = n.split("::")
        return (_comps(parts[0]), parts[1:-1], parts[-1])
    def _test_ok(seen_t, exp_t):
        if "[" in exp_t:
            return seen_t == exp_t
        return seen_t == exp_t or seen_t.startswith(exp_t + "[")
    def _tail(shorter, longer):
        return bool(shorter) and len(shorter) <= len(longer) and shorter == longer[len(longer) - len(shorter):]
    def _aligned(a, b):
        if not a or not b:
            return False
        s, l = (a, b) if len(a) <= len(b) else (b, a)
        return _tail(s, l)
    def _hit(cn, nm, fl, exp):
        em, ec, et = _parse_node(exp)
        if not em or not et:
            return False
        np = (nm or "").split("::")
        st = np[-1]
        extra = np[:-1]
        cp = (cn or "").split(".") if cn else []
        cands = []
        for cut in range(1, len(cp) + 1):
            cands.append((cp[:cut], cp[cut:] + extra, st))
        if fl:
            sm = _comps(fl)
            for cut in range(len(cp) + 1):
                if cut == 0 or _tail(cp[:cut], sm):
                    cands.append((sm, cp[cut:] + extra, st))
        class_level = not et.startswith("test_")
        for mod, cls, seen_t in cands:
            if not _aligned(mod, em):
                continue
            if cls == ec and _test_ok(seen_t, et):
                return True
            if class_level and cls == ec + [et]:
                return True
        return False
    missing = [i for i in ids if not any(_hit(c.get("classname"), c.get("name"), c.get("file"), i) for c in cases)]
    base_union = os.path.join(os.path.dirname(junit_path), "baseline")
    base_cases = []
    try:
        with open(os.path.join(base_union, "junit.xml"), "rb") as _bf:
            _braw = _bf.read()
    except Exception:
        _braw = b""
    if _braw:
        try:
            base_cases.extend(ET.fromstring(_braw).iter("testcase"))
        except Exception:
            base_cases = []
    for _bphase in sorted(glob.glob(os.path.join(base_union, "junit-phases", "junit-hook-*.xml"))):
        try:
            _bpraw = open(_bphase, "rb").read()
        except Exception:
            continue
        if _bpraw:
            try:
                base_cases.extend(ET.fromstring(_bpraw).iter("testcase"))
            except Exception:
                pass
    _v7bout = ""
    try:
        with open(os.path.join(base_union, "output.log"), encoding="utf-8", errors="replace") as _v7bf:
            _v7bout = _v7bf.read()
    except Exception:
        pass
    # @7 G8: an INTERNALERROR pristine baseline proves nothing (measured
    # 000585): skip fail-to-pass and keep the structured @5 rules below.
    _v7unreliable = "INTERNALERROR" in _v7bout
    ftp_bad = False
    if base_cases and not _v7unreliable:
        def _v6st(_c):
            if _c.find("failure") is not None or _c.find("error") is not None:
                return "bad"
            if _c.find("skipped") is not None:
                return "skipped"
            return "passed"
        def _v6key(_c):
            return (_c.get("classname") or "", _c.get("name") or "", _c.get("file") or "")
        _v6rank = {"passed": 0, "skipped": 1, "bad": 2}
        _bm = {}
        for _c in base_cases:
            _k = _v6key(_c)
            _s = _v6st(_c)
            if _k not in _bm or _v6rank[_s] > _v6rank[_bm[_k]]:
                _bm[_k] = _s
        _am = {}
        for _c in cases:
            _k = _v6key(_c)
            _s = _v6st(_c)
            if _k not in _am or _v6rank[_s] > _v6rank[_am[_k]]:
                _am[_k] = _s
        _bs = set(_k for _k, _s in _bm.items() if _s == "skipped")
        _v7errmod = {}
        _v7errfile = {}
        _v7hasfail = set()
        for _c in base_cases:
            _ck = _v6key(_c)
            if _c.find("failure") is not None:
                _v7hasfail.add(_ck)
            if _c.find("error") is None or _c.find("failure") is not None:
                continue
            _nm = _c.get("name") or ""
            if "::" in _nm:
                continue
            for _cand in ((_c.get("classname") or ""), _nm):
                _ct = _cand.strip()
                if _ct.endswith(".py"):
                    _ct = _ct[:-3]
                if re.fullmatch(r"[A-Za-z_][\w.-]*", _ct or ""):
                    _v7errmod.setdefault(_ck, set()).add(_ct)
            _cf = (_c.get("file") or "").strip()
            if _cf:
                _v7errfile.setdefault(_ck, set()).add(_cf)
        def _v7modok(_k):
            for _mc in cases:
                if _mc.find("failure") is not None or _mc.find("error") is not None or _mc.find("skipped") is not None:
                    continue
                _af = (_mc.get("file") or "").strip()
                if _k in _v7errfile and _v7errfile[_k]:
                    for _ef in _v7errfile[_k]:
                        if _af and (_af == _ef or _af.endswith("/" + _ef) or _ef.endswith("/" + _af)):
                            return True
                _acn = (_mc.get("classname") or "").strip()
                _amods = [_acn]
                if _af:
                    _afm = _af.replace("/", ".").replace(chr(92), ".")
                    if _afm.endswith(".py"):
                        _afm = _afm[:-3]
                    _amods.append(_afm)
                for _m in _v7errmod.get(_k, ()):
                    for _am2 in _amods:
                        if _am2 == _m or _am2.startswith(_m + "."):
                            return True
            return False
        _v9satisfied = []
        for _k, _s in _bm.items():
            if _s != "skipped" and _am.get(_k) != "passed":
                if (_k in _v7errmod or _k in _v7errfile) and _k not in _v7hasfail and _v7modok(_k):
                    _v9satisfied.append((_v7errmod.get(_k, set()), _v7errfile.get(_k, set())))
                    continue
                ftp_bad = True
        for _k, _s in _am.items():
            if _s == "skipped" and _k not in _bs:
                _v9exc = False
                for (_smods, _sfiles) in _v9satisfied:
                    _kcn = (_k[0] or "").strip()
                    _kf = (_k[2] or "").strip()
                    if _kf:
                        for _ef in _sfiles:
                            if _kf == _ef or _kf.endswith("/" + _ef) or _ef.endswith("/" + _kf):
                                _v9exc = True
                                break
                    if not _v9exc:
                        _kamods = [_kcn]
                        if _kf:
                            _kafm = _kf.replace("/", ".").replace(chr(92), ".")
                            if _kafm.endswith(".py"):
                                _kafm = _kafm[:-3]
                            _kamods.append(_kafm)
                        for _kam in _kamods:
                            for _sm in _smods:
                                if _kam == _sm or _kam.startswith(_sm + "."):
                                    _v9exc = True
                                    break
                            if _v9exc:
                                break
                    if _v9exc:
                        break
                if not _v9exc:
                    ftp_bad = True
    if _v7unreliable:
        sys.stderr.write("baseline unreliable (INTERNALERROR): fail-to-pass skipped\n")
    if ftp_bad:
        sys.stderr.write("fail-to-pass: pristine outcomes not preserved\n")
    print(1 if rc == 0 and cases and not bad and not missing and not ftp_bad else 0)
    sys.stderr.write("rc=%d cases=%d bad=%d skipped=%d named=%d missing=%s\n" % (rc, len(cases), len(bad), len(skipped), len(ids), missing))
    sys.exit()
if runner in ("go-test", "jest", "vitest", "mocha", "ava", "tap", "node-test", "karma", "jasmine", "cargo-test", "rspec", "phpunit", "unittest", "terse"):
    if blank:
        sys.stderr.write("rc=%d blank %s output: no test evidence\n" % (rc, runner))
        print(0)
        sys.exit()
    if rc != 0:
        print(0)
        sys.stderr.write("rc=%d %s nonzero exit\n" % (rc, runner))
        sys.exit()
    ok = False
    if runner == "go-test":
        _go_ok = [ln for ln in output.splitlines() if re.match(r"^ok\s+\S+", ln) is not None and "no tests to run" not in ln]
        _go_bare = re.search(r"^PASS\s*$", output, re.M) is not None
        ok = (_go_ok or (_go_bare and "no tests to run" not in output)) and re.search(r"^(FAIL|--- FAIL|panic:)", output, re.M) is None
    elif runner == "jest":
        ok = re.search(r"Tests:\s+[^\n]*\d+\s+passed", output) is not None and re.search(r"Tests:\s+.*failed|Test Suites:\s+.*failed", output) is None
    elif runner == "vitest":
        ok = re.search(r"Tests\s+[^\n]*\d+\s+passed", output) is not None and re.search(r"(Test Files|Tests)\s+.*failed", output) is None
    elif runner == "mocha":
        ok = re.search(r"\d+\s+passing", output) is not None and re.search(r"[1-9]\d*\s+failing", output) is None
    elif runner == "terse":
        ok = re.search(r"Asserts:\s+[^\n]*\d+\s+passed", output) is not None and re.search(r"Asserts:\s+[^\n]*failed|Suites:\s+[^\n]*failed", output) is None
    elif runner in ("tap", "ava", "node-test"):
        ok = re.search(r"^ok\b", output, re.M) is not None and re.search(r"^not ok\b", output, re.M) is None
    elif runner == "karma":
        ok = "SUCCESS" in output and "FAILED" not in output
    elif runner == "jasmine":
        ok = re.search(r"[1-9]\d*\s+failures?|failed expectations", output) is None
    elif runner == "cargo-test":
        ok = re.search(r"test result:\s+ok", output) is not None and re.search(r"test result:\s+FAILED|panicked", output) is None
    elif runner == "rspec":
        ok = re.search(r"0\s+failures", output) is not None and re.search(r"[1-9]\d*\s+failures", output) is None
    elif runner == "phpunit":
        ok = re.search(r"^OK\b", output, re.M) is not None and re.search(r"FAILURES!|ERRORS!|No tests executed", output) is None
    elif runner == "unittest":
        def _v10load(_p):
            try:
                with open(_p, "rb") as _f:
                    _raw = _f.read()
            except Exception:
                return []
            try:
                return list(ET.fromstring(_raw).iter("testcase")) if _raw else []
            except Exception:
                return []
        _v10dir = os.path.dirname(junit_path)
        _ucases = _v10load(os.path.join(_v10dir, "unittest-junit.xml"))
        _ubcases = _v10load(os.path.join(_v10dir, "baseline", "unittest-junit.xml"))
        def _v10map(_cases):
            _rank = {"passed": 0, "skipped": 1, "bad": 2}
            _out = {}
            for _c in _cases:
                _s = "bad" if (_c.find("failure") is not None or _c.find("error") is not None) else ("skipped" if _c.find("skipped") is not None else "passed")
                _k = (_c.get("classname") or "", _c.get("name") or "", _c.get("file") or "")
                if _k not in _out or _rank[_s] > _rank[_out[_k]]:
                    _out[_k] = _s
            return _out
        _umap = _v10map(_ucases)
        _ubmap = _v10map(_ubcases)
        ok = bool(_umap) and all(_s != "bad" for _s in _umap.values())
        if ok and _ubmap:
            _ubskip = {_k for _k, _s in _ubmap.items() if _s == "skipped"}
            for _k, _s in _ubmap.items():
                if _s != "skipped" and _umap.get(_k) != "passed":
                    ok = False
            for _k, _s in _umap.items():
                if _s == "skipped" and _k not in _ubskip:
                    ok = False
        sys.stderr.write("unittest junit cases=%d baseline=%d ok=%s\n" % (len(_ucases), len(_ubcases), ok))
    print(1 if ok else 0)
    sys.stderr.write("rc=%d %s markers=%s\n" % (rc, runner, ok))
    sys.exit()
if runner in ("mvn", "gradle"):
    paths = []
    for pat in ("target/surefire-reports/*.xml", "target/failsafe-reports/*.xml", "build/test-results/test/*.xml", "build/test-results/**/*.xml"):
        paths.extend(glob.glob(os.path.join(cwd, pat), recursive=True))
    if not paths:
        if blank:
            sys.stderr.write("rc=%d %s blank with no surefire reports\n" % (rc, runner))
            print(0)
            sys.exit()
        fallback()
    cases = []
    try:
        for p in paths:
            cases.extend(ET.parse(p).getroot().iter("testcase"))
    except Exception:
        print(0)
        sys.stderr.write("rc=%d %s unparsable surefire report\n" % (rc, runner))
        sys.exit()
    bad = [c for c in cases if c.find("failure") is not None or c.find("error") is not None]
    skipped = [c for c in cases if c.find("skipped") is not None]
    print(1 if rc == 0 and cases and not bad else 0)
    sys.stderr.write("rc=%d %s surefire=%d cases=%d bad=%d skipped=%d\n" % (rc, runner, len(paths), len(cases), len(bad), len(skipped)))
    sys.exit()
fallback()
PYEOF
echo "REWARD=$(cat "$V/reward.txt") rc=$RC runner=$(cat "$V/runner.txt")" | tee -a "$V/test_output.log"

"""Inputs for round N+1: only tasks whose grader was repaired and qualified in round N, at the
repaired package (so the seeker sees the repaired tests). Production source context is unchanged."""
from pathlib import Path
import argparse, hashlib, json

from evallab.registry import task_directory_digest

HERE = Path(__file__).resolve().parent


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--round', type=int, required=True, help='round whose repairs feed the next round')
    args = p.parse_args()
    n = args.round
    prev = json.loads((HERE / ('inputs.json' if n == 2 else f'inputs-r{n}.json')).read_text())
    cases = []
    for case in prev['cases']:
        result = HERE / f'findings/r{n}/{case["short"]}/result.json'
        if not result.exists():
            continue
        r = json.loads(result.read_text())
        if not r['qualified']:
            continue
        package = Path(r['variant'])
        cases.append({**case, 'package_path': str(package), 'package_digest': task_directory_digest(package),
                      'parent_round': n, 'parent_package_digest': case['package_digest']})
    out = {'schema': 'hardening.round-inputs/v1', 'round': n + 1, 'source_inputs': str(HERE / f'inputs-r{n}.json'),
           'cases': cases}
    path = HERE / f'inputs-r{n + 1}.json'
    path.write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'round': n + 1, 'tasks': [c['short'] for c in cases],
                      'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()

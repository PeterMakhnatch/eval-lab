"""Publish bridge round files from executed evidence only.

hardening-round-N.json: every attacked task's S2a/S3 outcomes and each wrong-but-passing program
with its independent probe. repairs-round-N.json: each derived repair with its native
qualification. Nothing here runs a model or a container.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json

from evallab.registry import compute_task_digests
from lane import ledger_totals

HERE = Path(__file__).resolve().parent
BRIDGE = Path('/Users/petermakhnatch/Developer/research-context/bridge/2026-10-19-deep')


def sha(path: Path) -> str:
    return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--round', type=int, required=True)
    p.add_argument('--inputs', default=None)
    p.add_argument('--status', default='complete')
    args = p.parse_args()
    n = args.round
    inputs_path = Path(args.inputs) if args.inputs else HERE / ('inputs.json' if n == 2 else f'inputs-r{n}.json')
    cases = json.loads(inputs_path.read_text())['cases']
    tasks, programs, repairs = [], [], []
    for case in cases:
        short = case['short']
        summary_path = HERE / f'round-{n}/{short}/summary.json'
        if not summary_path.exists():
            tasks.append({'task_id': case['task_id'], 'status': 'not_run_yet', 'package_digest': case['package_digest']})
            continue
        s = json.loads(summary_path.read_text())
        tasks.append({'task_id': case['task_id'], 'package_path': case['package_path'], 'package_digest': case['package_digest'],
                      'status': s['status'], 'model_calls': s['model_calls'], 'native_trials': s['native_trials'],
                      'attempts': [{k: a.get(k) for k in ('attempt', 'status', 'reward', 'fresh_replay_reward', 'error', 'model')}
                                   for a in s['attempts']]})
        probe_path = HERE / f'findings/r{n}/{short}/probe.json'
        probe = json.loads(probe_path.read_text()) if probe_path.exists() else None
        disposition_path = HERE / f'findings/r{n}/{short}/disposition.json'
        disposition = json.loads(disposition_path.read_text()) if disposition_path.exists() else None
        for attempt in s['attempts']:
            if attempt.get('reward') != 1.0:
                continue
            adir = HERE / f'round-{n}/{short}/attempt-{attempt["attempt"]}'
            patch = (adir / 'proposal.patch').read_text()
            label = f'r{n}-a{attempt["attempt"]}'
            programs.append({
                'task_id': case['task_id'], 'label': label, 'round': n,
                'package_path': case['package_path'], 'package_digest': case['package_digest'],
                'kind': 'semantic_patch', 'content': patch,
                'sha256': hashlib.sha256(patch.encode()).hexdigest(),
                'mechanism_hypothesis': attempt.get('mechanism_hypothesis'),
                'seeker_counterexample': attempt.get('counterexample'), 'model': attempt.get('model'),
                'native': {'s2a_reward': attempt.get('reward'), 'fresh_s3_reward': attempt.get('fresh_replay_reward'),
                           's2a_trial': str(adir / 's2a/trial'), 's3_trial': str(adir / 's3/trial')},
                'independent_probe': None if probe is None else {
                    'rule': probe['rule'], 'requirement': probe['spec'].get('requirement'),
                    'interpretation_note': probe['spec'].get('interpretation_note'),
                    'test_repo_path': probe['spec']['repo_path'], 'test_code': probe['spec']['code'],
                    'command': probe['spec']['command'], 'arm_exit_codes': probe['arms'],
                    'verified_wrong': probe['independently_verified_wrong'] and label in probe.get('wrong_labels', []),
                    'evidence': str(probe_path)},
                'independent_incorrectness': (disposition['independent_incorrectness'] if disposition else
                                              'verified' if probe and probe['independently_verified_wrong']
                                              and label in probe.get('wrong_labels', []) else
                                              'refuted_by_probe' if probe else 'pending_probe'),
                'parent_disposition': disposition and disposition['reason'],
            })
        result_path = HERE / f'findings/r{n}/{short}/result.json'
        if result_path.exists():
            r = json.loads(result_path.read_text())
            variant = Path(r['variant'])
            digests = compute_task_digests(variant)
            vrec = json.loads((HERE / f'findings/r{n}/{short}/variant.json').read_text())
            spec = json.loads((HERE / f'findings/r{n}/{short}/spec.json').read_text())
            repairs.append({
                'task_id': case['task_id'], 'round': n,
                'parent': {'package_path': case['package_path'], 'package_digest': case['package_digest']},
                'repaired': {'package_path': str(variant), 'package_digest': digests.package,
                             'verifier_digest': digests.verifier,
                             'lineage_record': f"library/task-variants/{vrec['record']['task_name'].replace('/', '__')}/{digests.package.split(':')[-1][:12]}.json"},
                'change': {'kind': 'append-only regression test (original test.patch prefix and original command preserved; original exit status kept)',
                           'test_repo_path': spec['repo_path'], 'test_sha256': hashlib.sha256(spec['code'].encode()).hexdigest(),
                           'command': spec['command'], 'requirement': spec['requirement'],
                           'interpretation_note': spec.get('interpretation_note')},
                'qualification': {'backend': r.get('backend'), 'complete': r['complete'], 'qualified': r['qualified'],
                                  'cells': [{k: row[k] for k in ('label', 'role', 'expected', 'reward', 'ok', 'trial')} for row in r['rows']],
                                  'reference_pass': f"{sum(1 for x in r['rows'] if x['role']=='oracle' and x['reward']==1.0)}/{sum(1 for x in r['rows'] if x['role']=='oracle')}",
                                  'nop_fail': f"{sum(1 for x in r['rows'] if x['role']=='nop' and x['reward']==0.0)}/{sum(1 for x in r['rows'] if x['role']=='nop')}",
                                  'wrong_rejected': f"{sum(1 for x in r['rows'] if x['role'].startswith('wrong') and x['reward']==0.0)}/{sum(1 for x in r['rows'] if x['role'].startswith('wrong'))}",
                                  'correct_accepted': f"{sum(1 for x in r['rows'] if x['role'].startswith('correct') and x['reward']==1.0)}/{sum(1 for x in r['rows'] if x['role'].startswith('correct'))}"},
                'earlier_round_wrongs': r.get('earlier_round_wrongs', []),
                'prior_envcheck_wrongs': [w['label'] for w in r.get('prior_wrong_sources', [])],
                'scoring_allowed': False, 'training_allowed': False,
            })
    now = datetime.now(timezone.utc).isoformat()
    modal = json.loads((HERE / 'modal-ledger.json').read_text()) if (HERE / 'modal-ledger.json').exists() else None
    common = {'created': now, 'author': 'HardeningLoop (Track A, continuing QA Task J-1 / EnvCheck B-1)', 'round': n,
              'status': args.status, 'inputs': str(inputs_path), 'inputs_sha256': sha(inputs_path),
              'evidence_root': str(HERE), 'llm_ledger': ledger_totals(), 'modal_ledger': modal,
              'limits': ['Reward 1 is not proof of wrongness; only probe-verified programs count as wrong.',
                         'Zero findings on a task is a K<=3 budget result, not proof of a strong grader.',
                         'Reservations are not bills.']}
    found = [x for x in programs if x['independent_incorrectness'] == 'verified']
    hardening = {**common, 'schema': 'hardening.round/v1', 'tasks_attacked': len([t for t in tasks if t['status'] != 'not_run_yet']),
                 'tasks_total': len(tasks), 'verified_wrong_programs': len(found),
                 'tasks_with_verified_wrong': sorted({x['task_id'] for x in found}),
                 'programs': programs, 'tasks': tasks}
    rep = {**common, 'schema': 'hardening.repairs-round/v1', 'repairs': repairs,
           'qualified': sum(1 for r in repairs if r['qualification']['qualified'])}
    (BRIDGE / f'hardening-round-{n}.json').write_text(json.dumps(hardening, indent=2, sort_keys=True) + '\n')
    (BRIDGE / f'repairs-round-{n}.json').write_text(json.dumps(rep, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'round': n, 'attacked': hardening['tasks_attacked'], 'verified_wrong': len(found),
                      'passing_candidates': len(programs), 'repairs': len(repairs), 'qualified': rep['qualified']}))


if __name__ == '__main__':
    main()

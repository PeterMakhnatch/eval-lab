"""One-off PB-1 preparation using the existing native repair/variant SDKs."""
from __future__ import annotations

import functools
import hashlib
import json
from pathlib import Path

from evallab.execution_contracts import new_ulid
from evallab.qa.task import workdir_patch_script
from evallab.registry import compute_subpath_digest, compute_task_digests, harbor_task_digest
from evallab.schemas import ExperimentMatrix, MatrixRun
from evallab.task_variants import derive_task, materialize, verify
from evallab.verifier_repair import (
    RepairProposal,
    RepairTest,
    derive_repair_variant,
    read_task_workdir,
    validate_proposal,
)

ROOT = Path('/Users/petermakhnatch/Developer/eval-lab/.worktrees/envcheck-v71-pb1-20261019')
LANE = ROOT / 'runs/envcheck-v71-pb1'
INPUT = LANE / 'inputs-r2.json'
RECORDS = Path('runs/envcheck-v71-pb1/native-records')
STORE = Path('runs/envcheck-v71-pb1/task-store/variants')


def sha(path):
    return 'sha256:' + hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(binding):
    path = Path(binding['path'])
    assert sha(path) == binding['sha256'], path
    return path


def write_new(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def derive_private(parent, **kwargs):
    kwargs['parent_source'] = {'kind': 'local', 'path': str(parent.resolve())}
    return derive_task(parent, **kwargs)


source = json.loads(INPUT.read_bytes())
assert source['cap_usd'] == 2.0
for field in ['released_parent_manifest', 'qa_semantic_confirmation_manifest', 'accepted_atlas', 'overnight_handoff']:
    bound(source[field])
prepared = []
for task, info in source['tasks'].items():
    parent = Path(info['parent_package'])
    parent_digests = compute_task_digests(parent)
    assert parent_digests.package == info['parent_package_digest']
    fixture = bound(info['fixture'])
    wrongs = [row for row in source['wrong_controls'] if row['task'] == task]
    wanted = [row['control_id'] for row in wrongs]
    assert len(set(wanted)) == len(wanted) and wanted
    for row in wrongs:
        for field in ['patch', 'source', 'adjudication', 'independent_probe']:
            if field in row:
                bound(row[field])
    destination = LANE / 'candidates' / task / 'r1'
    proposal = RepairProposal(
        repairable=True,
        rationale=(
            'Preserve equality of structurally identical unmeasured circuits when measurement equality is required.'
            if task == '002915' else
            'Preserve missing-unit composite writes and existing unsupported-conversion errors under the default conversion mode.'
        ),
        tests=[RepairTest(id=f'v71-{task}-contract', repo_path=info['native_repo_path'], code=fixture.read_text())],
        command=f'/usr/local/bin/python -m pytest -q {info["native_repo_path"]}',
        mutant_ids=wanted,
    )
    validate_proposal(proposal, mutant_ids=wanted, package_dir=parent)
    write_new(destination / 'proposal.json', proposal.model_dump(mode='json', by_alias=True))
    record = derive_repair_variant(
        parent, proposal, repo_root=ROOT, created_by='envcheck-pb1-20261019',
        rationale=proposal.rationale,
        derive_fn=functools.partial(derive_private, records_dir=RECORDS, variants_root=STORE),
    )
    package = materialize(record, parent, repo_root=ROOT, records_dir=RECORDS, variants_root=STORE)
    problems = verify(record, parent_dir=parent, repo_root=ROOT, records_dir=RECORDS, variants_root=STORE)
    assert not problems, problems
    digests = compute_task_digests(package)
    assert list(record.components_changed) == ['verifier']
    assert digests.package == record.variant_digest
    assert harbor_task_digest(package) == record.variant_harbor_digest
    for field in ['task_toml', 'instruction', 'environment']:
        assert getattr(digests, field) == getattr(parent_digests, field), field
    assert compute_subpath_digest(package / 'solution') == compute_subpath_digest(parent / 'solution')
    assert (package / 'tests/test.patch').read_bytes().startswith((parent / 'tests/test.patch').read_bytes())
    prefix = f'v71-pb1-{task}-r1'
    runs = [MatrixRun(name=f'{prefix}-ref', agent='oracle', expect_reward=1.0, allow_billable=False),
            MatrixRun(name=f'{prefix}-nop', agent='nop', expect_reward=0.0, allow_billable=False)]
    controls = []
    for index, row in enumerate(wrongs, 1):
        patch = bound(row['patch'])
        stages = ['s2a', 'fresh-s3'] if row['control_id'] == 'qa-released_v7-attempt3' else ['s2a']
        for stage in stages:
            name = f'{prefix}-wrong-{index:02d}-{stage}'
            script = destination / 'scripts' / f'{name}.sh'
            script.parent.mkdir(parents=True, exist_ok=True)
            with script.open('x', encoding='utf-8') as stream:
                stream.write(workdir_patch_script(patch.read_bytes(), read_task_workdir(parent)))
            runs.append(MatrixRun(name=name, agent='oracle', expect_reward=0.0, allow_billable=False,
                                  solution=script.relative_to(ROOT).as_posix()))
            controls.append({'run':name, 'finding_id':row['control_id'], 'validation_stage':stage,
                             'patch':str(patch), 'patch_sha256':sha(patch),
                             'script':str(script), 'script_sha256':sha(script),
                             'source_input':row['source']['path'], 'source_input_sha256':row['source']['sha256']})
    matrix = ExperimentMatrix(
        matrix_id=new_ulid(), name=prefix,
        hypothesis='Append-only semantic repair retains original assertions, reference repeat3 and nop repeat3; rejects all old/new wrongs, with fresh native replay of both new released-v7 programs.',
        benchmark_family='mimo-clean-v7.1', task_id=f'format-code-task-{task}', task=str(package),
        task_package_digest=digests.package, verifier_digest=digests.verifier,
        environment='modal', jobs_dir='runs', concurrency=1, timeout_seconds=600, runs=runs,
    )
    matrix_path = destination / 'matrix.json'
    write_new(matrix_path, matrix.model_dump(mode='json'))
    record_path = ROOT / RECORDS / record.task_slug / f'{record.digest12}.json'
    candidate = {
        'schema':'envcheck.v7.candidate/v1', 'task_id':info['task_id'], 'revision':'v7.1-pb1-r1',
        'status':'prepared', 'qualified':False, 'training_allowed':False,
        'source_manifest':str(INPUT), 'source_sha256':sha(INPUT),
        'package_path':str(package), 'package_digest':digests.package,
        'verifier_digest':digests.verifier, 'harbor_digest':record.variant_harbor_digest,
        'parent_package':str(parent), 'parent_digest':parent_digests.package,
        'native_record':str(record_path), 'native_record_sha256':sha(record_path),
        'components_changed':list(record.components_changed),
        'matrix':str(matrix_path), 'matrix_sha256':sha(matrix_path),
        'known_wrong_reproducers':controls, 'adjudicated_correct_controls':[],
        'source_correct_control_limit':source['proof_limit'],
        'proposal':str(destination/'proposal.json'), 'proposal_sha256':sha(destination/'proposal.json'),
        'no_original_assertion_weakened':True, 'task_control_bindings_unchanged':True,
    }
    write_new(destination / 'candidate.json', candidate)
    prepared.append({'task':task,'candidate':str(destination/'candidate.json'),'matrix':str(matrix_path),
                     'package_digest':digests.package,'native_requests':len(runs)})
write_new(LANE / 'prepared.json', prepared)
print(json.dumps({'prepared':prepared, 'native_requests':sum(row['native_requests'] for row in prepared), 'paid_executions':0}, indent=2))

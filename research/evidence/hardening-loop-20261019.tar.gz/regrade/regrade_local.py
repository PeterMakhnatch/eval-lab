"""Replay canonical70 passes on this lane's repaired graders, natively on local Docker (one container).

Same replay as DataCurve's regrade_round.py (`heldout-v7/native.py` replay_and_collect, copied from
origin/main unchanged), backend="docker", serialized by this lane's docker.lock.
usage: regrade_local.py ROUND [TASK ...]
"""
import fcntl, json, runpy, sys, traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
LANE = HERE.parent
WT = LANE.parents[1]
NATIVE = runpy.run_path(str(HERE / 'native_datacurve_copy.py'))
from evallab.qa import counterfactual as cf  # noqa: E402

N = int(sys.argv[1])
ONLY = set(sys.argv[2:])
DEEP = Path('/Users/petermakhnatch/Developer/research-context/bridge/2026-10-19-deep')
INV = Path('/Users/petermakhnatch/Developer/eval-lab/.worktrees/mimo-hardening-data-curve-20261019/runs/mimo-m1-data-curve-20261019/round-inventory-bound.json')
LABELS = Path('/Users/petermakhnatch/Developer/research-context/bridge/2026-10-17-v7/regrade-v7.json')
OUT = HERE / f'round-{N}'
OUT.mkdir(exist_ok=True)
repaired = {r['task_id']: r['repaired'] for r in json.loads((DEEP / f'repairs-round-{N}.json').read_text())['repairs']}
labels = {tuple(l['source_uid']): l['label'] for l in json.loads(LABELS.read_text())['labels']}
rows = [r for r in json.loads(INV.read_text())['rows'] if r['cohort'] == 'canonical70']
for row in rows:
    src = row['source']
    task = src['task_id'].split('/')[-1]
    if task not in repaired or (ONLY and task.rsplit('-', 1)[-1] not in ONLY):
        continue
    target = repaired[task]
    cell = OUT / f"{row['cell_id']}--{target['package_digest'][7:19]}"
    if (cell / 'obs.json').exists():
        continue
    cell.mkdir(exist_ok=True)
    grader = cf.Grader(task_name=src['task_id'], transform=f'hardening-round-{N}',
                       variant_digest=target['package_digest'], package=Path(target['package_path']),
                       record=target.get('lineage_record', ''))
    with (LANE / 'docker.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        try:
            obs = NATIVE['replay_and_collect'](src, grader, repo_root=WT, work=cell / 'native', spend_gate=None,
                                               backend='docker', require_case_execution=True)
        except Exception as exc:
            obs = {'v7_outcome': None, 'v7_error': f'{type(exc).__name__}: {exc}', 'tb': traceback.format_exc()}
    rec = {'round': N, 'cell_id': row['cell_id'], 'task_id': task, 'source_uid': src['source_uid'],
           'label_v7': labels.get(tuple(src['source_uid'])), 'v7_outcome': row['baseline']['outcome'],
           'grader_package_digest': target['package_digest'], 'grader_verifier_digest': target.get('verifier_digest'),
           'outcome': obs.get('v7_outcome'), 'reward': None if obs.get('v7_outcome') is None else float(obs['v7_outcome']),
           'error': obs.get('v7_error'), 'backend': 'docker'}
    (cell / 'obs.json').write_text(json.dumps(obs | {'summary': rec}, indent=2, default=str))
    print(json.dumps(rec, default=str), flush=True)

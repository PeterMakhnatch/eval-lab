"""Breaker round: verifier-aware S2a ordinary-program seeker (K<=3) + fresh S3 replay.

Per task: a fresh seeker sees the instruction, the grader's unit-test coverage (current round's
package, so repaired tests are visible) and pristine production source; proposes exact source
edits; the compiled source-only patch is graded natively on local Docker; a reward-1 candidate is
replayed in a separate fresh container (S3). Prior attempts' outcomes feed the next attempt.
Wrongness is NOT decided here: S2a=S3=1 candidates go to independent probe review.
"""
from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import argparse, hashlib, json, re, shlex, threading, time, traceback

from evallab.qa.task import (MIMO_SEMANTIC_PROMPT, HarborBackend, QuotaStop, bundle_verifier_aware,
                             mimo_semantic_edit_patch)
from evallab.registry import task_directory_digest
from hbackend import Backend
from lane import Lane, ledger_totals
import export_contexts

HERE = Path(__file__).resolve().parent
DOCKER = threading.Lock()  # one container at a time from this process
TESTY = re.compile(r'(^|/)(tests?|testing)(/|$)|(^|/)test_[^/]*$|_test\.py$|conftest\.py$')


def now():
    return datetime.now(timezone.utc).isoformat()


def save(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, default=str) + '\n')


def extra_context(backend, package, digest, paths):
    with DOCKER, backend.slot('hardening/source-extra'):
        image, _ = backend._ensure_images(package, digest)
        cmd = 'python3 -c ' + shlex.quote(export_contexts.READER) + ' ' + shlex.quote(HarborBackend.patch_workdir(package)) + ' ' + shlex.quote(json.dumps(paths))
        result = backend._run_probe(package, image, cmd, timeout=400)
    if result.returncode:
        return {}
    return json.loads(result.stdout.strip().splitlines()[-1])['files']


def attack(case, args, lane, backend):
    short = case['short']
    package = Path(case['package_path'])
    digest = case['package_digest']
    if task_directory_digest(package) != digest:
        raise RuntimeError('package digest changed ' + short)
    out = args.out / short
    summary = {'task_id': case['task_id'], 'short': short, 'package_path': str(package), 'package_digest': digest,
               'round': args.round, 'attempts': [], 'model_calls': 0, 'native_trials': 0}
    ctx_path = HERE / 'source-context' / short / 'source-context.json'
    if not ctx_path.exists():
        if case.get('wave2_context'):
            ctx = json.loads(Path(case['wave2_context']).read_text())
        else:
            files = extra_context(backend, package, digest, case['allowed_production_paths'])
            ctx = {'created': now(), 'task_id': case['task_id'], 'allowed_production_paths': case['allowed_production_paths'],
                   'source_package': {'package_path': str(package), 'package_digest': digest},
                   'reader_sha256': hashlib.sha256(export_contexts.READER.encode()).hexdigest(),
                   'files': files, 'status': 'source_context_measured' if files else 'no_allowed_production_source_found'}
        save(ctx_path, ctx)
    else:
        ctx = json.loads(ctx_path.read_text())
    source = dict(ctx.get('files') or {})
    if not source:
        summary['status'] = 'unmeasured_no_source_context'
        save(out / 'summary.json', summary)
        return summary
    bundle = bundle_verifier_aware(package, semantic_only=True)
    bundle['workdir'] = HarborBackend.patch_workdir(package)
    feedback = []
    for attempt in range(1, args.k + 1):
        bundle['base_source'] = source
        prompt = (MIMO_SEMANTIC_PROMPT + '\nRead-only task data:\n' + json.dumps(bundle)
                  + '\nPrior semantic attempts (no hidden runtime data):\n' + json.dumps(feedback))
        adir = out / f'attempt-{attempt}'
        if (adir / 'attempt.json').exists():  # resume: completed attempt is evidence, never re-run
            row = json.loads((adir / 'attempt.json').read_text())
            if row.get('context_added'):
                source.update(extra_context(backend, package, digest, row['context_added']))
            summary['attempts'].append(row)
            summary['model_calls'] += 1 if (adir / 'response.txt').exists() else 0
            summary['native_trials'] += sum(1 for k in ('s2a', 's3') if row.get(k))
            feedback.append({k: row.get(k) for k in ('attempt', 'status', 'reward', 'mechanism_hypothesis', 'error', 'counterexample')})
            if row.get('reward') == 1.0:
                break
            continue
        reused = None
        if adir.exists():
            if (adir / 'response.txt').exists() and (adir / 'prompt.txt').read_text() == prompt:
                reused = (adir / 'response.txt').read_text()  # graded now, no second model call
            else:
                adir.rename(adir.with_name(f'{adir.name}.aborted-{datetime.now(timezone.utc).strftime("%H%M%S")}'))
                summary.setdefault('aborted_in_flight_calls', 0)
                summary['aborted_in_flight_calls'] += 1
        adir.mkdir(parents=True, exist_ok=True)
        (adir / 'prompt.txt').write_text(prompt)
        row = {'attempt': attempt, 'status': 'model_error', 'reward': None, 'created': now(),
               'prompt_sha256': hashlib.sha256(prompt.encode()).hexdigest()}
        if reused is not None:
            reply = type('Reply', (), {'text': reused, 'model': args.model, 'tokens': None})
            row['resumed_from_saved_response'] = True
            for stage in ('s2a', 's3'):
                if (adir / stage).exists():  # an interrupted trial is retained, not counted
                    (adir / stage).rename(adir / f'{stage}.interrupted')
        else:
            reply = None
            for retry in range(4):  # upstream HTTP 429 is availability, not a seeker outcome; every request is in the ledger
                try:
                    reply = lane.complete(prompt, label=f'{args.label}-{short}-a{attempt}')
                    break
                except QuotaStop as exc:
                    if '429' in str(exc) and retry < 3:
                        summary['http429_requests'] = summary.get('http429_requests', 0) + 1
                        time.sleep(45 * (retry + 1))
                        continue
                    row.update(status='quota_stop', error=str(exc))
                    break
            if reply is None:
                summary['attempts'].append(row)
                save(adir / 'attempt.json', row)
                break
            (adir / 'response.txt').write_text(reply.text)
        summary['model_calls'] += 1
        row.update(model=reply.model, tokens=reply.tokens)
        try:
            payload = json.loads(reply.text)
        except json.JSONDecodeError:
            payload = None
        if not isinstance(payload, dict) or payload.get('status') not in {'candidate', 'no_candidate', 'needs_source_context'}:
            row.update(status='invalid_response', error='response is not one JSON object with a valid status')
        else:
            wit = payload.get('counterexample')
            if isinstance(wit, dict) and any(isinstance(v, (dict, list)) for v in wit.values()):
                # A structured (non-string) counterexample field is serialized, never dropped.
                wit = {k: (json.dumps(v, sort_keys=True) if isinstance(v, (dict, list)) else v) for k, v in wit.items()}
                row['counterexample_coerced'] = True
            row.update(status=payload['status'], mechanism_hypothesis=payload.get('mechanism_hypothesis'),
                       counterexample=wit, source_paths=payload.get('source_paths'))
            if payload['status'] == 'needs_source_context':
                wanted = [p for p in (payload.get('source_paths') or []) if isinstance(p, str) and p.endswith('.py')
                          and not TESTY.search(p) and '..' not in p and not p.startswith('/') and p not in source][:4]
                got = extra_context(backend, package, digest, wanted) if wanted else {}
                if sum(map(len, {**source, **got}.values())) <= 160_000:
                    source.update(got)
                row['context_added'] = sorted(got)
            elif payload['status'] == 'candidate':
                sub = payload.get('submission')
                if (not isinstance(sub, dict) or sub.get('kind') != 'source_edits' or not isinstance(sub.get('edits'), list)
                        or not isinstance(wit, dict)
                        or not all(isinstance(wit.get(k), str) and wit[k].strip() for k in ('requirement', 'input', 'expected', 'actual'))):
                    row.update(status='invalid_response',
                               error='candidate needs submission.kind=source_edits with edits and string counterexample requirement/input/expected/actual')
                else:
                    try:
                        patch = mimo_semantic_edit_patch(package, source, sub['edits'])
                    except Exception as exc:
                        row.update(status='rejected_without_execution', error=f'{type(exc).__name__}: {exc}')
                    else:
                        row['candidate_sha256'] = hashlib.sha256(patch.encode()).hexdigest()
                        (adir / 'proposal.patch').write_text(patch)
                        try:
                            with DOCKER:
                                obs, rep = backend.grade_shortcut(package, {'kind': 'semantic_patch', 'content': patch},
                                                                  digest=digest, run_dir=adir / 's2a', timeout_seconds=args.timeout)
                            summary['native_trials'] += 1
                            row['s2a'] = {'status': obs.status, 'reason': obs.reason,
                                          'reward': obs.facts.get('reward'), 'exception': obs.facts.get('exception')}
                            row['reward'] = obs.facts.get('reward') if obs.status == 'executed' and not obs.facts.get('exception') else None
                            row['error'] = obs.reason
                            if row['reward'] == 1.0 and rep is not None:
                                with DOCKER:
                                    replay = backend.replay_reproducer(package, rep, digest=digest, run_dir=adir / 's3',
                                                                       timeout_seconds=args.timeout)
                                summary['native_trials'] += 1
                                row['s3'] = {'status': replay.status, 'reason': replay.reason,
                                             'reward': replay.facts.get('reward'), 'exception': replay.facts.get('exception')}
                                row['fresh_replay_reward'] = replay.facts.get('reward') if replay.status == 'executed' else None
                        except Exception as exc:
                            row.update(status='unmeasured_native_exception', error=f'{type(exc).__name__}: {exc}',
                                       trace=traceback.format_exc()[-2000:])
        save(adir / 'attempt.json', row)
        summary['attempts'].append(row)
        print(json.dumps({'task': short, 'attempt': attempt, 'status': row['status'], 'reward': row.get('reward'),
                          's3': row.get('fresh_replay_reward'), 'err': (row.get('error') or '')[:200]}), flush=True)
        feedback.append({k: row.get(k) for k in ('attempt', 'status', 'reward', 'mechanism_hypothesis', 'error', 'counterexample')})
        if row.get('reward') == 1.0:
            break
    rewards = [r.get('reward') for r in summary['attempts']]
    summary['candidate_passes'] = [r['attempt'] for r in summary['attempts'] if r.get('reward') == 1.0 and r.get('fresh_replay_reward') == 1.0]
    summary['status'] = ('s2a_s3_pass_awaiting_independent_probe' if summary['candidate_passes'] else
                         'no_passing_candidate' if any(x is not None for x in rewards) or summary['attempts'] else 'unmeasured')
    save(out / 'summary.json', summary)
    return summary


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--round', type=int, required=True)
    p.add_argument('--inputs', type=Path, default=HERE / 'inputs.json')
    p.add_argument('--task', action='append')
    p.add_argument('--k', type=int, default=3)
    p.add_argument('--timeout', type=int, default=1500)
    p.add_argument('--model', default='openrouter-metered/openai/gpt-oss-120b')
    p.add_argument('--workers', type=int, default=6)
    p.add_argument('--name', default=None, help='output arm directory (default round-N)')
    args = p.parse_args()
    if not 1 <= args.k <= 3:
        raise SystemExit('K<=3')
    args.out = HERE / (args.name or f'round-{args.round}')
    args.label = args.name or f'r{args.round}'
    cases = [c for c in json.loads(args.inputs.read_text())['cases'] if not args.task or c['short'] in args.task]
    cases = [c for c in cases if not (args.out / c['short'] / 'summary.json').exists()]
    lane, backend = Lane(args.model), Backend(repo_root=HERE.parents[1])
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(attack, c, args, lane, backend) for c in cases]
        for f in futures:
            try:
                f.result()
            except Exception as exc:
                print(json.dumps({'error': f'{type(exc).__name__}: {exc}'}), flush=True)
    print(json.dumps({'round': args.round, 'ledger': ledger_totals()}), flush=True)


if __name__ == '__main__':
    main()

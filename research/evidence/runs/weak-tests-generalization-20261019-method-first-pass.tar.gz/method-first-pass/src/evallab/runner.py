from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import re
import secrets
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import time
import tomllib
import urllib.parse
from collections.abc import Iterator
from contextlib import contextmanager, suppress
from dataclasses import asdict, dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import ValidationError

from evallab.execution_contracts import (
    _BEARER_HEADER,
    _SUBSCRIPTION_ENVIRONMENT_KEYS,
    BOUNDED_DAYTONA_ENVIRONMENT_IMPORT_PATH,
    BREAKER_SELFHOSTED_NATIVE_MODELS,
    BREAKER_SELFHOSTED_PROXY_CAPABILITY_ENV,
    BREAKER_SELFHOSTED_PROXY_PROVIDER,
    BREAKER_SELFHOSTED_SECRET_FILE_ENV,
    BREAKER_SELFHOSTED_UPSTREAM_ENV,
    CAPTURE_DIR_ENV,
    CAPTURE_ENABLED_ENV,
    CAPTURE_ROUTE_TOKEN_ENV,
    CLAUDE_GATEWAY_ATTEMPT_ENV,
    CLAUDE_GATEWAY_BRIDGE_SCRIPT,
    CLAUDE_GATEWAY_CAPABILITY_ENV,
    CLAUDE_GATEWAY_ISOLATION_PORT_ENV,
    CLAUDE_GATEWAY_SANDBOX_HOST,
    CLAUDE_GATEWAY_USAGE_FILE_ENV,
    CLAUDE_GATEWAY_USAGE_FILENAME,
    CONTROL_AGENTS,
    DEEPSEEK_ALLOWED_MODEL,
    DEEPSEEK_ALLOWED_MODEL_ENV,
    DEEPSEEK_CREDENTIAL_ENVIRONMENT_KEYS,
    DEEPSEEK_MODEL_SELECTOR,
    DEEPSEEK_PROXY_ATTEMPT_ID_ENV,
    DEEPSEEK_PROXY_CAPABILITY_ENV,
    DEEPSEEK_PROXY_GID_ENV,
    DEEPSEEK_PROXY_HOST,
    DEEPSEEK_PROXY_SCRIPT,
    DEEPSEEK_PROXY_SCRIPT_ENV,
    DEEPSEEK_PROXY_UID_ENV,
    DEEPSEEK_PROXY_USAGE_DIR_ENV,
    DEEPSEEK_PROXY_USAGE_FILE_ENV,
    DEEPSEEK_SECRET_FILE_ENV,
    DEFAULT_HEARTBEAT_INTERVAL_SECONDS,
    DEFAULT_TRIAL_TIMEOUT_SECONDS,
    HARBOR_AGENT_IMPORT_PATHS,
    HARBOR_STATE_JOURNAL_PLUGIN,
    HOST_ISOLATED_DOCKER_ENVIRONMENT_IMPORT_PATH,
    LOCAL_TO_HARBOR_MODEL,
    LOCKED_DOCKER_ENVIRONMENT_IMPORT_PATH,
    MAX_TRIAL_TIMEOUT_SECONDS,
    MIMO_AGENT,
    MIMO_AGENT_IMPORT_PATH,
    MIMO_SAMPLING_PROFILE_ENV,
    MIMO_SELFHOSTED_CAPABILITY_EXPIRES_AT_ENV,
    MIMO_SELFHOSTED_CONTEXT_TOKENS,
    MIMO_SELFHOSTED_MODEL_PRICES_MICROS,
    MIMO_SELFHOSTED_NATIVE_MODELS,
    MIMO_SELFHOSTED_PROXY_ATTEMPT_ID_ENV,
    MIMO_SELFHOSTED_PROXY_CAPABILITY_ENV,
    MIMO_SELFHOSTED_PROXY_PROVIDER,
    MIMO_SELFHOSTED_PROXY_USAGE_FILE_ENV,
    MIMO_SELFHOSTED_SECRET_FILE_ENV,
    MIMO_SELFHOSTED_SECRET_PATH_ENV,
    MIMO_SELFHOSTED_UPSTREAM_ENV,
    OPENROUTER_CAPABILITY_EXPIRES_AT_ENV,
    OPENROUTER_EXPECTED_MODEL_ENV,
    OPENROUTER_PROXY_ATTEMPT_ID_ENV,
    OPENROUTER_PROXY_CAPABILITY_ENV,
    OPENROUTER_PROXY_PROVIDER,
    OPENROUTER_PROXY_USAGE_FILE_ENV,
    OPENROUTER_SECRET_FILE_ENV,
    OPENROUTER_SECRET_PATH_ENV,
    OPENROUTER_UPSTREAM_ENV,
    PROXY_LIVE_DIR_ENV,
    PROXY_LIVE_DIR_NAME,
    PROXY_UPSTREAM_503_WAIT_ENV,
    REDACTED_SECRET_VALUE,
    RLM_AGENT,
    SUPPORT_COMMAND_TIMEOUT_SECONDS,
    TERMINUS_AGENT,
    TERMINUS_AGENT_IMPORT_PATH,
    TERMINUS_LOCAL_ENDPOINT_ENV,
    TERMINUS_LOCAL_MODEL_SELECTOR,
    TERMINUS_PROXY_URL_ENV,
    TINKER_CAPABILITY_EXPIRES_AT_ENV,
    TINKER_PROXY_ATTEMPT_ID_ENV,
    TINKER_PROXY_CAPABILITY_ENV,
    TINKER_PROXY_USAGE_FILE_ENV,
    TINKER_SECRET_FILE_ENV,
    TINKER_SECRET_PATH_ENV,
    TINKER_UPSTREAM_ENV,
    WATCHDOG_POLL_SECONDS,
    ZAI_CAPABILITY_EXPIRES_AT_ENV,
    ZAI_INPUT_COST_MICROS_PER_MILLION,
    ZAI_MINISWE_AGENT_IMPORT_PATH,
    ZAI_OPENAPI_ALLOWED_MODEL,
    ZAI_OPENAPI_ALLOWED_MODEL_ENV,
    ZAI_OPENAPI_CAPABILITY_EXPIRES_AT_ENV,
    ZAI_OPENAPI_INPUT_COST_MICROS_PER_MILLION,
    ZAI_OPENAPI_MODEL_SELECTOR,
    ZAI_OPENAPI_OUTPUT_COST_MICROS_PER_MILLION,
    ZAI_OPENAPI_PROXY_ATTEMPT_ID_ENV,
    ZAI_OPENAPI_PROXY_CAPABILITY_ENV,
    ZAI_OPENAPI_PROXY_GID_ENV,
    ZAI_OPENAPI_PROXY_HOST,
    ZAI_OPENAPI_PROXY_SCRIPT,
    ZAI_OPENAPI_PROXY_SCRIPT_ENV,
    ZAI_OPENAPI_PROXY_UID_ENV,
    ZAI_OPENAPI_PROXY_USAGE_DIR_ENV,
    ZAI_OPENAPI_PROXY_USAGE_FILE_ENV,
    ZAI_OPENAPI_SECRET_FILE_ENV,
    ZAI_OPENAPI_SECRET_PATH_ENV,
    ZAI_OPENAPI_UPSTREAM_ENV,
    ZAI_OPENCODE_AGENT,
    ZAI_OUTPUT_COST_MICROS_PER_MILLION,
    ZAI_PROXY_ATTEMPT_ID_ENV,
    ZAI_PROXY_CAPABILITY_ENV,
    ZAI_PROXY_GID_ENV,
    ZAI_PROXY_HOST,
    ZAI_PROXY_SCRIPT,
    ZAI_PROXY_SCRIPT_ENV,
    ZAI_PROXY_UID_ENV,
    ZAI_PROXY_USAGE_DIR_ENV,
    ZAI_PROXY_USAGE_FILE_ENV,
    ZAI_SECRET_FILE_ENV,
    ExecutionFailure,
    HarborProcessResult,
    OpenRouterRoute,
    ProxyTrialLimits,
    RedactingBinaryWriter,
    RunRequest,
    TinkerModelSpec,
    TransientHarnessFailure,
    TrialTimeoutFailure,
    build_command,
    collected_secret_values,
    is_breaker_selfhosted_model,
    is_claude_gateway_model,
    is_lease_generation,
    is_mimo_selfhosted_model,
    is_openrouter_model,
    is_tinker_terminus_model,
    materialize_breaker_selfhosted_secret_file,
    materialize_deepseek_secret_file,
    materialize_mimo_selfhosted_secret_file,
    materialize_openrouter_secret_file,
    materialize_tinker_secret_file,
    materialize_zai_openapi_secret_file,
    materialize_zai_secret_file,
    openrouter_route,
    parse_breaker_selfhosted_model,
    parse_mimo_selfhosted_model,
    parse_tinker_model,
    persist_private_bytes,
    proxy_runtime_identity,
    read_owner_secret_file,
    redact_environment,
    resolve_egress_lock,
    resolve_harbor_agent,
    resolve_harbor_model,
    subscription_command,
    subscription_environment,
    terminus_agent_kwargs,
    transient_provider_exception,
    transient_provider_reason,
    uses_provider_proxy,
    validate_request,
    zai_openapi_price_for,
)
from evallab.harbor_network import (
    NetworkAdaptation,
    adapt_task_toml_for_host,
    with_agent_network_allowlist,
)
from evallab.ledger import build_cost_block, split_calls
from evallab.results import JobRecord, load_job
from evallab.schemas import ExperimentMatrix, MatrixRun
from evallab.terminus_local import local_ollama_endpoint, resolve_ollama_binding

__all__ = [
    "_SUBSCRIPTION_ENVIRONMENT_KEYS",
    "CONTROL_AGENTS",
    "DEEPSEEK_CREDENTIAL_ENVIRONMENT_KEYS",
    "DEEPSEEK_MODEL_SELECTOR",
    "DEFAULT_HEARTBEAT_INTERVAL_SECONDS",
    "DEFAULT_TRIAL_TIMEOUT_SECONDS",
    "HARBOR_AGENT_IMPORT_PATHS",
    "HARBOR_STATE_JOURNAL_PLUGIN",
    "LOCAL_TO_HARBOR_MODEL",
    "MAX_TRIAL_TIMEOUT_SECONDS",
    "REDACTED_SECRET_VALUE",
    "SUPPORT_COMMAND_TIMEOUT_SECONDS",
    "WATCHDOG_POLL_SECONDS",
    "HarborProcessResult",
    "RunRequest",
    "TransientHarnessFailure",
    "TrialTimeoutFailure",
    "build_command",
    "capture_dir_from_environment",
    "cleanup_new_harbor_containers",
    "database_url_from_environment",
    "expected_primary_reward",
    "executor_state_path",
    "git_state",
    "harbor_container_ids",
    "load_matrix",
    "maybe_link_capture",
    "preflight_request",
    "profile_for_request",
    "redact_environment",
    "request_from_matrix",
    "staged_matrix_request",
    "matrix_run_outcome",
    "resolve_harbor_agent",
    "resolve_harbor_model",
    "run_experiment",
    "run_harbor_process",
    "subscription_command",
    "subscription_environment",
    "tool_version",
    "transient_provider_exception",
    "transient_provider_reason",
    "validate_request",
    "TRIAL_NATIVE_TRAJECTORY_PATH",
    "TRIAL_ATIF_TRAJECTORY_PATH",
    "TRIAL_RESULT_PATH",
    "TRIAL_VERIFIER_DIR",
    "JOB_METADATA_PATH",
    "JOB_RESULT_PATH",
]
HARBOR_COMPOSE_CONFIG_LABEL = "com.docker.compose.project.config_files"
HARBOR_COMPOSE_PROJECT_LABEL = "com.docker.compose.project"
HARBOR_COMPOSE_WORKDIR_LABEL = "com.docker.compose.project.working_dir"
#: Environment selectors (spec value or Harbor ``--env`` import path) whose
#: sandboxes run remotely. Their trials create no local Docker containers, so
#: the local Harbor-container scan and orphan cleanup are skipped for them.
_DAYTONA_ENVIRONMENT_SELECTORS = frozenset(
    {
        "daytona",
        "evallab.harbor_daytona:SecretSafeDaytonaEnvironment",
        BOUNDED_DAYTONA_ENVIRONMENT_IMPORT_PATH,
    }
)
# Code and supporting assets belong to the imported release, not its data workspace.
_RUNTIME_ROOT = Path(__file__).resolve().parents[2]


# =============================================================================
# HARNESS CAPTURE CONTRACT
# =============================================================================
# Immutable source paths and layout consumed by the lab reader:
#
# Job directory layout:
#   <job_dir>/
#     result.json                       - Harbor job-level completion summary
#     config.json                       - Harbor job configuration
#     lock.json                         - Harbor job environment and package lock
#     lab-metadata.json                 - Lab executor run metadata (provenance,
#                                         provider_usage, model_identity, host, tools)
#     <trial_dir>/                      - Per-trial directories (<task>__<id>)
#       result.json                     - Trial outcome, agent_result, verifier_result
#       config.json                     - Trial configuration
#       lock.json                       - Trial lock
#       agent/
#         trajectory.json               - Native / standard agent trajectory
#       trajectory.json                 - ATIF trajectory (root fallback)
#       verifier/
#         reward.txt / reward.json      - Verifier reward output
#         ctrf.json / test-stdout.txt   - Verifier test reports and stdout
#
# Executor state & secret proxy usage:
#   <jobs_dir>/.executor/<name>.state.json           - Executor state machine
#   <jobs_dir>/.executor/<name>.log                  - Redacted runner progress log
#   <usage_dir>/*-proxy-usage.json                   - Ephemeral private proxy accounting
# =============================================================================

TRIAL_NATIVE_TRAJECTORY_PATH = Path("agent/trajectory.json")
TRIAL_ATIF_TRAJECTORY_PATH = Path("trajectory.json")
TRIAL_RESULT_PATH = Path("result.json")
TRIAL_VERIFIER_DIR = Path("verifier")
JOB_METADATA_PATH = Path("lab-metadata.json")
JOB_RESULT_PATH = Path("result.json")


def _run_text_command(
    command: list[str],
    **kwargs: Any,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, **kwargs)


def _is_under(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
    except ValueError:
        return False
    return True


def _is_harbor_container(
    labels: dict[str, str],
    task_root: Path,
    project_prefixes: frozenset[str] | None,
) -> bool:
    config_files = labels.get(HARBOR_COMPOSE_CONFIG_LABEL, "")
    working_dir = labels.get(HARBOR_COMPOSE_WORKDIR_LABEL, "")
    project = labels.get(HARBOR_COMPOSE_PROJECT_LABEL, "")
    project_matches = project_prefixes is None or any(
        project == prefix or project.startswith(prefix + "__") for prefix in project_prefixes
    )
    return bool(
        project
        and project_matches
        and "/harbor/environments/docker/" in config_files.replace("\\", "/")
        and working_dir
        and _is_under(Path(working_dir), task_root)
    )


def harbor_container_ids(
    task_root: Path,
    *,
    project_prefixes: frozenset[str] | None = None,
    command_runner: Any = None,
) -> frozenset[str]:
    """Return only containers proven by labels to belong to Harbor for this task."""
    runner = command_runner or _run_text_command
    environment = subscription_environment()
    try:
        listed = runner(
            [
                "docker",
                "ps",
                "-aq",
                "--filter",
                f"label={HARBOR_COMPOSE_PROJECT_LABEL}",
                "--filter",
                f"label={HARBOR_COMPOSE_CONFIG_LABEL}",
            ],
            check=False,
            capture_output=True,
            text=True,
            timeout=SUPPORT_COMMAND_TIMEOUT_SECONDS,
            env=environment,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError("cannot inspect Docker for Harbor-labeled containers") from exc
    if listed.returncode != 0:
        raise RuntimeError("cannot inspect Docker for Harbor-labeled containers")
    matches: set[str] = set()
    for container_id in listed.stdout.split():
        try:
            inspected = runner(
                ["docker", "inspect", "--format", "{{json .Config.Labels}}", container_id],
                check=False,
                capture_output=True,
                text=True,
                timeout=SUPPORT_COMMAND_TIMEOUT_SECONDS,
                env=environment,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise RuntimeError("cannot inspect Docker for Harbor-labeled containers") from exc
        if inspected.returncode != 0:
            continue
        try:
            labels = json.loads(inspected.stdout)
        except json.JSONDecodeError:
            continue
        if isinstance(labels, dict) and _is_harbor_container(
            labels,
            task_root,
            project_prefixes,
        ):
            matches.add(container_id)
    return frozenset(matches)


def cleanup_new_harbor_containers(
    task_root: Path,
    containers_before: frozenset[str],
    *,
    project_prefixes: frozenset[str],
    command_runner: Any = None,
) -> tuple[str, ...]:
    """Force-remove new Harbor-labeled task containers; never prune globally."""
    if not project_prefixes:
        return ()
    current = harbor_container_ids(
        task_root,
        project_prefixes=project_prefixes,
        command_runner=command_runner,
    )
    orphaned = tuple(sorted(current - containers_before))
    if not orphaned:
        return ()
    runner = command_runner or _run_text_command
    try:
        completed = runner(
            ["docker", "rm", "-f", "--", *orphaned],
            check=False,
            capture_output=True,
            text=True,
            timeout=SUPPORT_COMMAND_TIMEOUT_SECONDS,
            env=subscription_environment(),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError("failed to remove Harbor-labeled orphan containers") from exc
    if completed.returncode != 0:
        raise RuntimeError("failed to remove Harbor-labeled orphan containers")
    return orphaned


def tool_version(command: str) -> str | None:
    executable = shutil.which(command)
    if not executable:
        return None
    try:
        completed = subprocess.run(
            [executable, "--version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=SUPPORT_COMMAND_TIMEOUT_SECONDS,
            env=subscription_environment(),
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    output = (completed.stdout or completed.stderr).strip()
    return output.splitlines()[0] if output else None


def git_state(root: Path) -> dict[str, Any]:
    from evallab.results_home import capture_repository

    captured = capture_repository(root)
    captured.pop("_diff", None)
    return {
        "remote": captured["remote"],
        "worktree": captured["worktree"],
        "branch": captured["branch"],
        "commit": captured["commit"],
        "dirty": captured["dirty"],
        "untracked": captured["untracked"],
        "uncommitted_diff_sha256": captured["uncommitted_diff_sha256"],
    }


def _terminate_process_group(process: subprocess.Popen[Any]) -> None:
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            return
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            return


def _trial_is_terminal(trial_dir: Path) -> bool:
    try:
        payload = json.loads((trial_dir / "result.json").read_text())
    except (OSError, json.JSONDecodeError):
        return False
    return bool(isinstance(payload, dict) and payload.get("finished_at"))


def _active_trial_directories(job_dir: Path) -> tuple[Path, ...]:
    if not job_dir.is_dir():
        return ()
    return tuple(
        candidate
        for candidate in job_dir.iterdir()
        if candidate.is_dir() and "__" in candidate.name and not _trial_is_terminal(candidate)
    )


def _unlink_secret_dir(directory: Path | None, secret_file: Path | None) -> None:
    if secret_file is not None:
        with suppress(OSError):
            secret_file.unlink()
    if directory is not None:
        with suppress(OSError):
            shutil.rmtree(directory)


def assert_no_secret_material(
    paths: tuple[Path, ...],
    *,
    secrets: frozenset[str],
) -> None:
    """Fail closed if provider credential bytes reached a persistent artifact."""
    encoded = tuple(secret.encode() for secret in secrets if secret)
    if not encoded:
        return
    leaks: list[Path] = []
    for root in paths:
        candidates = (root,) if root.is_file() or root.is_symlink() else tuple(root.rglob("*"))
        for path in candidates:
            if path.is_symlink():
                raise ExecutionFailure(
                    "unsafe_artifact_symlink",
                    f"persistent artifact contains a symlink: {path}",
                )
            if not path.is_file():
                continue
            try:
                content = path.read_bytes()
            except OSError as exc:
                raise ExecutionFailure(
                    "artifact_scan_failed",
                    f"persistent artifact cannot be scanned: {path}",
                ) from exc
            if any(secret in content for secret in encoded):
                leaks.append(path)
    if leaks:
        labels = ", ".join(str(path) for path in leaks)
        removal_failures: list[str] = []
        for path in leaks:
            try:
                path.unlink()
            except OSError:
                removal_failures.append(str(path))
        disposition = (
            "removal failed for: " + ", ".join(removal_failures)
            if removal_failures
            else "contaminated files were removed"
        )
        raise ExecutionFailure(
            "credential_material_detected",
            f"credential material reached persistent artifacts ({disposition}): {labels}",
        )


def _read_generation(path: Path) -> str | None:
    try:
        descriptor = os.open(
            path,
            os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
        )
    except OSError:
        return None
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            return None
        with os.fdopen(descriptor, "rb", closefd=False) as source:
            payload = json.load(source)
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        return None
    finally:
        os.close(descriptor)
    if not isinstance(payload, dict):
        return None
    generation = payload.get("lease_generation")
    if not is_lease_generation(generation):
        return None
    return generation


def _lease_owned(lease_path: Path | None, lease_generation: str | None) -> bool:
    if lease_path is None:
        return True
    return lease_generation is not None and _read_generation(lease_path) == lease_generation


def _cancel_requested(
    lease_path: Path | None,
    lease_generation: str | None,
) -> bool:
    if lease_path is None or lease_generation is None:
        return False
    marker = lease_path.with_name(f"{lease_path.name}.cancel.{lease_generation}")
    return _read_generation(marker) == lease_generation


def _heartbeat_lease(lease_path: Path, lease_generation: str) -> bool:
    try:
        descriptor = os.open(
            lease_path,
            os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC,
        )
    except OSError:
        return False
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            return False
        with os.fdopen(descriptor, "rb", closefd=False) as source:
            payload = json.load(source)
        if not isinstance(payload, dict) or payload.get("lease_generation") != lease_generation:
            return False
        os.utime(descriptor)
        return True
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        return False
    finally:
        os.close(descriptor)


def _lease_cancelled_or_lost(
    lease_path: Path | None,
    lease_generation: str | None,
) -> bool:
    return _cancel_requested(lease_path, lease_generation) or not _lease_owned(
        lease_path,
        lease_generation,
    )


def _read_proxy_usage(
    path: Path,
    *,
    capability_id: str,
    attempt_id: str,
    limits: ProxyTrialLimits,
    provider_label: str = "DeepSeek",
    expected_pricing: dict[str, int | None] | None = None,
) -> dict[str, Any]:
    try:
        payload = json.loads(read_owner_secret_file(path))
    except (OSError, json.JSONDecodeError) as exc:
        raise ExecutionFailure(
            "proxy_usage_invalid",
            f"{provider_label} proxy usage report is unreadable",
        ) from exc
    if not isinstance(payload, dict):
        raise ExecutionFailure(
            "proxy_usage_invalid",
            f"{provider_label} proxy usage report is invalid",
        )

    def integer(value: object, label: str) -> int:
        if not isinstance(value, int) or isinstance(value, bool) or value < 0 or value > 2**63 - 1:
            raise ExecutionFailure(
                "proxy_usage_invalid",
                f"{provider_label} proxy usage field {label} is invalid",
            )
        return value

    calls = payload.get("calls")
    totals = payload.get("totals")
    if not isinstance(calls, list) or not isinstance(totals, dict):
        raise ExecutionFailure(
            "proxy_usage_invalid",
            f"{provider_label} proxy usage report is invalid",
        )

    # Pricing freezes at the first reservation. A zero-call ledger keeps
    # ``pricing: null``: no rate may be invented without a physical call.
    # The proxy always freezes a three-key card (cached rate may be None);
    # lanes that pin only input/output omit that key. A missing cached
    # rate means no cached rate on either side — otherwise every
    # self-hosted trial with calls fails binding after grading.
    def _with_cached_rate(pricing: object) -> object:
        if isinstance(pricing, dict) and "cached_input_cost_micros_per_million" not in pricing:
            return {**pricing, "cached_input_cost_micros_per_million": None}
        return pricing

    pricing_invalid = expected_pricing is not None and (
        _with_cached_rate(payload.get("pricing")) != _with_cached_rate(expected_pricing)
        and not (not calls and payload.get("pricing") is None)
    )
    version = payload.get("schema_version")
    binding_invalid = (
        version not in (1, 2)
        or payload.get("capability_id") != capability_id
        or payload.get("attempt_id") != attempt_id
        or payload.get("limits") != asdict(limits)
        or pricing_invalid
    )
    if binding_invalid:
        raise ExecutionFailure(
            "proxy_usage_invalid",
            f"{provider_label} proxy usage binding does not match this trial",
        )
    if version == 2:
        # Schema v2: ``totals`` is actual usage only (reconciled + exceeded
        # actuals); reservations of still-reserved/unresolved calls sit in
        # ``attempted``. Both blocks must recompute exactly from the calls.
        try:
            recomputed = split_calls([dict(call) for call in calls])
        except ValueError as exc:
            raise ExecutionFailure(
                "proxy_usage_invalid",
                f"{provider_label} proxy call sequence is invalid",
            ) from exc
        attempted = payload.get("attempted")
        if not isinstance(attempted, dict):
            raise ExecutionFailure(
                "proxy_usage_invalid",
                f"{provider_label} proxy usage report is invalid",
            )
        expected_totals = {
            **recomputed["used"],
            "total_tokens": recomputed["used"]["input_tokens"]
            + recomputed["used"]["output_tokens"],
        }
        expected_attempted = {
            name: recomputed["attempted"][name]
            for name in ("requests", "input_tokens", "output_tokens", "cost_micros")
        }
        if (
            {name: integer(totals.get(name), name) for name in expected_totals} != expected_totals
            or {name: integer(attempted.get(name), name) for name in expected_attempted}
            != expected_attempted
            or integer(payload.get("unresolved_requests"), "unresolved_requests")
            != recomputed["unresolved_requests"]
            or integer(payload.get("sequence"), "sequence") != recomputed["sequence"]
        ):
            raise ExecutionFailure(
                "proxy_usage_invalid",
                f"{provider_label} proxy totals do not reconcile with provider calls",
            )
        return payload
    # Schema v1 (historic): totals include reservations of calls that never
    # reconciled. Validate the legacy invariant exactly as written; readers
    # derive used vs attempted from the calls list (evallab.ledger) and the
    # file itself is never rewritten.
    computed = {
        "requests": len(calls),
        "input_tokens": 0,
        "output_tokens": 0,
        "cost_micros": 0,
    }
    unresolved = 0
    expected_sequence = 0
    for index, raw_call in enumerate(calls, start=1):
        if not isinstance(raw_call, dict) or integer(raw_call.get("call_id"), "call_id") != index:
            raise ExecutionFailure(
                "proxy_usage_invalid",
                f"{provider_label} proxy call sequence is invalid",
            )
        state = raw_call.get("state")
        if state == "reconciled":
            source_fields = ("input_tokens", "output_tokens", "cost_micros")
            expected_sequence += 2
        elif state in {"reserved", "unresolved"}:
            source_fields = (
                "reserved_input_tokens",
                "reserved_output_tokens",
                "reserved_cost_micros",
            )
            unresolved += 1
            expected_sequence += 1 if state == "reserved" else 2
        elif state == "exceeded":
            source_fields = ("input_tokens", "output_tokens", "cost_micros")
            unresolved += 1
            expected_sequence += 2
        else:
            raise ExecutionFailure(
                "proxy_usage_invalid",
                f"{provider_label} proxy call state is invalid",
            )
        computed["input_tokens"] += integer(raw_call.get(source_fields[0]), source_fields[0])
        computed["output_tokens"] += integer(raw_call.get(source_fields[1]), source_fields[1])
        computed["cost_micros"] += integer(raw_call.get(source_fields[2]), source_fields[2])
    expected_totals = {
        **computed,
        "total_tokens": computed["input_tokens"] + computed["output_tokens"],
    }
    if (
        {name: integer(totals.get(name), name) for name in expected_totals} != expected_totals
        or integer(payload.get("unresolved_requests"), "unresolved_requests") != unresolved
        or integer(payload.get("sequence"), "sequence") != expected_sequence
    ):
        raise ExecutionFailure(
            "proxy_usage_invalid",
            f"{provider_label} proxy totals do not reconcile with provider calls",
        )
    return payload


# ---------------------------------------------------------------------------
# Terminus2 host-loopback proxy supervision.
#
# Upstream Terminus2 runs its model client host-side inside the Harbor
# controller process, so the metered proxy cannot be a task-container compose
# sidecar. The runner starts one per-trial loopback instance of the existing
# proxy (127.0.0.1, ephemeral port, private ready file), hands the Harbor
# child only the loopback URL plus the trial capability, and quiesces the
# proxy before the final ledger read on every exit path. Ledger accounting
# and reconciliation reuse the standard proxy usage rules (same as mini-SWE).
# ---------------------------------------------------------------------------

_TERMINUS_PROXY_HOST = "127.0.0.1"
_TERMINUS_PROXY_READY_TIMEOUT_SECONDS = 20.0
# The proxy drains in-flight provider calls for up to SHUTDOWN_DRAIN_SECONDS
# (120 s, containers/zai_openapi_secret_proxy.py) on SIGTERM, so a call the
# agent abandoned at its timeout still settles with real usage. Wait past it.
_TERMINUS_PROXY_STOP_TIMEOUT_SECONDS = 130.0
_TERMINUS_PROXY_STDERR_TAIL_BYTES = 4096


def _capture_route_token(upstream: str | None, attempt_id: str) -> dict[str, str]:
    """Route token for the independent capture hop, or nothing.

    Only when the operator opted in (``EVALLAB_MODEL_CAPTURE=1``) *and* the
    provider upstream points at a loopback address (the recording proxy):
    hand the secret proxy the job attempt id as ``/t/<token>/`` prefix so
    ``capture link`` can attribute calls per job deterministically. Every
    other shape — direct-to-vendor rounds, unset upstreams, a stray flag
    against an https upstream — carries no token and the path stays pinned
    exactly.
    """
    if os.environ.get(CAPTURE_ENABLED_ENV) != "1":
        return {}
    if not upstream:
        return {}
    try:
        host = (urllib.parse.urlsplit(upstream).hostname or "").casefold()
    except ValueError:
        return {}
    if host not in {"127.0.0.1", "localhost"}:
        return {}
    token = attempt_id.strip()
    if not token:
        return {}
    return {CAPTURE_ROUTE_TOKEN_ENV: token}


def capture_dir_from_environment() -> Path | None:
    """This job's capture directory, or ``None`` when capture is off.

    The round launcher sets ``EVALLAB_MODEL_CAPTURE_DIR`` alongside
    ``EVALLAB_MODEL_CAPTURE=1`` and the loopback upstream (the bound
    endpoint published in ``<capture_dir>/capture.json``). Each concurrent
    segment uses its own directory, so each job auto-links to its correct
    file via :func:`maybe_link_capture`.
    """
    if os.environ.get(CAPTURE_ENABLED_ENV) != "1":
        return None
    raw = (os.environ.get(CAPTURE_DIR_ENV) or "").strip()
    if not raw:
        return None
    return Path(raw)


def _capture_binding_for_metadata(request: RunRequest) -> dict[str, Any] | None:
    """Durable per-job capture identity for ``lab-metadata.json``.

    Records the capture directory, the loopback endpoint in play (when any
    known upstream env points at one), the route token stamped for this job,
    and the bound manifest identity read from ``capture.json`` — which exists
    only after the server bound successfully, so a failed bind leaves no
    misleading identity behind.
    """
    capture_dir = capture_dir_from_environment()
    if capture_dir is None:
        return None
    binding: dict[str, Any] = {"capture_dir": str(capture_dir)}
    for env_name in (
        MIMO_SELFHOSTED_UPSTREAM_ENV,
        TINKER_UPSTREAM_ENV,
        OPENROUTER_UPSTREAM_ENV,
        ZAI_OPENAPI_UPSTREAM_ENV,
        TERMINUS_LOCAL_ENDPOINT_ENV,
    ):
        upstream = os.environ.get(env_name)
        if not upstream:
            continue
        try:
            host = (urllib.parse.urlsplit(upstream).hostname or "").casefold()
        except ValueError:
            continue
        if host in {"127.0.0.1", "localhost"}:
            binding["capture_endpoint"] = upstream
            binding["capture_endpoint_env"] = env_name
            break
    attempt = _proxy_attempt_id(request)
    if attempt:
        binding["route_token"] = attempt
    try:
        manifest = json.loads((capture_dir / "capture.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return binding
    if isinstance(manifest, dict):
        binding["manifest"] = {
            key: manifest.get(key)
            for key in (
                "schema",
                "proxy_version",
                "upstream",
                "bind",
                "port",
                "endpoint",
                "started_at",
                "pid",
            )
        }
    return binding


def maybe_link_capture(
    job_dir: str | Path, *, capture_dir: str | Path | None = None
) -> dict[str, Any] | None:
    """Link a job to its own capture file; never raises.

    Uses the independent-capture ``link_capture`` (route token, then session,
    then conversation chaining) against the job's own capture directory —
    ``capture_dir`` when given, else ``EVALLAB_MODEL_CAPTURE_DIR``. Returns
    the link receipt, or ``None`` when capture is off, the file is absent,
    or the link failed. A failure is recorded beside the job and never fails
    the run.
    """
    try:
        directory = Path(capture_dir) if capture_dir is not None else capture_dir_from_environment()
        if directory is None:
            return None
        if not (directory / "calls.jsonl").is_file():
            return None
        job_path = Path(job_dir)
        if not job_path.is_dir():
            return None
        from evallab.model_capture import link_capture

        return link_capture(directory, job_path)
    except Exception:
        return None


def _record_capture_link(job_dir: str | Path, receipt: dict[str, Any]) -> None:
    """Merge a capture-link summary into ``lab-metadata.json``; best-effort."""
    job_path = Path(job_dir)
    metadata_path = job_path / "lab-metadata.json"
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    if not isinstance(metadata, dict):
        return
    binding = metadata.get("model_capture")
    if not isinstance(binding, dict):
        binding = {}
        metadata["model_capture"] = binding
    binding["link"] = {
        "parquet_dir": receipt.get("parquet_dir"),
        "capture_digest": receipt.get("capture_digest"),
        "calls_total": receipt.get("calls_total"),
        "calls_assigned": receipt.get("calls_assigned"),
        "linked_at": receipt.get("linked_at"),
    }
    with suppress(Exception):
        persist_private_bytes(
            metadata_path,
            (json.dumps(metadata, indent=2, sort_keys=True) + "\n").encode(),
            secrets=tuple(value.encode() for value in collected_secret_values()),
        )


def _proxy_503_wait_passthrough(env: dict[str, str]) -> dict[str, str]:
    """Pass the operator's upstream-503 wait bound into the proxy subprocess.

    The proxy subprocess starts with a minimal environment (ambient parent
    state is not inherited), so the knob only takes effect when forwarded
    here. Unset stays unset: the proxy falls back to its default. Malformed
    values are clamped proxy-side, never here.
    """
    raw = os.environ.get(PROXY_UPSTREAM_503_WAIT_ENV)
    if raw is not None:
        env[PROXY_UPSTREAM_503_WAIT_ENV] = raw
    return env


def _terminus_proxy_env(
    *,
    provider: str,
    secret_path: Path,
    capability: str,
    attempt_id: str,
    usage_path: Path,
    limits: ProxyTrialLimits,
    timeout_seconds: float,
    tinker_spec: TinkerModelSpec | None = None,
    mimo_native: str | None = None,
    openrouter_spec: OpenRouterRoute | None = None,
    breaker_native: str | None = None,
    mimo_sampling_profile: str = "generation-config",
    live_dir: Path | None = None,
) -> dict[str, str]:
    """Build the minimal environment for the host-supervised proxy instance.
    env value: the proxy reads it from the owner-only secret file. Ambient
    parent-process proxy state is not inherited.
    """
    env: dict[str, str] = {}
    for name in ("PATH", "TMPDIR"):
        value = os.environ.get(name)
        if value:
            env[name] = value
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    env["EVALLAB_PROXY_PROVIDER"] = provider
    if live_dir is not None:
        env[PROXY_LIVE_DIR_ENV] = str(live_dir)
    if provider == BREAKER_SELFHOSTED_PROXY_PROVIDER:
        if breaker_native not in BREAKER_SELFHOSTED_NATIVE_MODELS:
            raise ValueError("breaker proxy env requires an exact parsed native model")
        prefix = "EVALLAB_BREAKER_SELFHOSTED"
        env[f"{prefix}_SECRET_PATH"] = str(secret_path)
        env[f"{prefix}_EXPECTED_MODEL"] = breaker_native
        upstream = os.environ.get(BREAKER_SELFHOSTED_UPSTREAM_ENV)
        if upstream:
            env[BREAKER_SELFHOSTED_UPSTREAM_ENV] = upstream
        env.update(_capture_route_token(upstream, attempt_id))
        env[BREAKER_SELFHOSTED_PROXY_CAPABILITY_ENV] = capability
        env[f"{prefix}_ATTEMPT_ID"] = attempt_id
        env[f"{prefix}_USAGE_FILE"] = str(usage_path)
        for suffix, value in (
            ("MAX_REQUESTS", limits.max_requests),
            ("MAX_INPUT_TOKENS", limits.max_input_tokens),
            ("MAX_OUTPUT_TOKENS", limits.max_output_tokens),
            ("MAX_TOTAL_TOKENS", limits.max_total_tokens),
            ("MAX_COST_MICROS", limits.max_cost_micros),
        ):
            env[f"{prefix}_{suffix}"] = str(value)
        env[f"{prefix}_CAPABILITY_EXPIRES_AT"] = str(time.time() + float(timeout_seconds) + 60.0)
        return _proxy_503_wait_passthrough(env)
    if provider == MIMO_SELFHOSTED_PROXY_PROVIDER:
        if mimo_native not in MIMO_SELFHOSTED_NATIVE_MODELS:
            raise ValueError("mimo_selfhosted proxy env requires the parsed native model")
        if mimo_sampling_profile not in {"generation-config", "xiaomi-rl"}:
            raise ValueError("unknown MiMo sampling profile")
        env[MIMO_SAMPLING_PROFILE_ENV] = mimo_sampling_profile
        env[MIMO_SELFHOSTED_SECRET_PATH_ENV] = str(secret_path)
        env["EVALLAB_MIMO_SELFHOSTED_CONTEXT_TOKENS"] = str(MIMO_SELFHOSTED_CONTEXT_TOKENS)
        upstream = os.environ.get(MIMO_SELFHOSTED_UPSTREAM_ENV)
        if upstream:
            env[MIMO_SELFHOSTED_UPSTREAM_ENV] = upstream
        env.update(_capture_route_token(upstream, attempt_id))
        env[MIMO_SELFHOSTED_PROXY_CAPABILITY_ENV] = capability
        env[MIMO_SELFHOSTED_PROXY_ATTEMPT_ID_ENV] = attempt_id
        env[MIMO_SELFHOSTED_PROXY_USAGE_FILE_ENV] = str(usage_path)
        env["EVALLAB_MIMO_SELFHOSTED_MAX_REQUESTS"] = str(limits.max_requests)
        env["EVALLAB_MIMO_SELFHOSTED_MAX_INPUT_TOKENS"] = str(limits.max_input_tokens)
        env["EVALLAB_MIMO_SELFHOSTED_MAX_OUTPUT_TOKENS"] = str(limits.max_output_tokens)
        env["EVALLAB_MIMO_SELFHOSTED_MAX_TOTAL_TOKENS"] = str(limits.max_total_tokens)
        env["EVALLAB_MIMO_SELFHOSTED_MAX_COST_MICROS"] = str(limits.max_cost_micros)
        env[MIMO_SELFHOSTED_CAPABILITY_EXPIRES_AT_ENV] = str(
            time.time() + float(timeout_seconds) + 60.0
        )
        return _proxy_503_wait_passthrough(env)
    if provider == "tinker":
        if tinker_spec is None:
            raise ValueError("tinker proxy env requires the parsed model spec")
        env[TINKER_SECRET_PATH_ENV] = str(secret_path)
        upstream = os.environ.get(TINKER_UPSTREAM_ENV)
        if upstream:
            env[TINKER_UPSTREAM_ENV] = upstream
        env.update(_capture_route_token(upstream, attempt_id))
        env[TINKER_PROXY_CAPABILITY_ENV] = capability
        env[TINKER_PROXY_ATTEMPT_ID_ENV] = attempt_id
        env[TINKER_PROXY_USAGE_FILE_ENV] = str(usage_path)
        env["EVALLAB_TINKER_EXPECTED_BASE"] = tinker_spec.base_model
        env["EVALLAB_TINKER_MAX_REQUESTS"] = str(limits.max_requests)
        env["EVALLAB_TINKER_MAX_INPUT_TOKENS"] = str(limits.max_input_tokens)
        env["EVALLAB_TINKER_MAX_OUTPUT_TOKENS"] = str(limits.max_output_tokens)
        env["EVALLAB_TINKER_MAX_TOTAL_TOKENS"] = str(limits.max_total_tokens)
        env["EVALLAB_TINKER_MAX_COST_MICROS"] = str(limits.max_cost_micros)
        env[TINKER_CAPABILITY_EXPIRES_AT_ENV] = str(time.time() + float(timeout_seconds) + 60.0)
        return _proxy_503_wait_passthrough(env)
    if provider == OPENROUTER_PROXY_PROVIDER:
        if openrouter_spec is None:
            raise ValueError("openrouter proxy env requires the resolved route")
        env[OPENROUTER_SECRET_PATH_ENV] = str(secret_path)
        env[OPENROUTER_EXPECTED_MODEL_ENV] = openrouter_spec.native_model
        upstream = os.environ.get(OPENROUTER_UPSTREAM_ENV)
        if upstream:
            env[OPENROUTER_UPSTREAM_ENV] = upstream
        env.update(_capture_route_token(upstream, attempt_id))
        env[OPENROUTER_PROXY_CAPABILITY_ENV] = capability
        env[OPENROUTER_PROXY_ATTEMPT_ID_ENV] = attempt_id
        env[OPENROUTER_PROXY_USAGE_FILE_ENV] = str(usage_path)
        env["EVALLAB_OPENROUTER_MAX_REQUESTS"] = str(limits.max_requests)
        env["EVALLAB_OPENROUTER_MAX_INPUT_TOKENS"] = str(limits.max_input_tokens)
        env["EVALLAB_OPENROUTER_MAX_OUTPUT_TOKENS"] = str(limits.max_output_tokens)
        env["EVALLAB_OPENROUTER_MAX_TOTAL_TOKENS"] = str(limits.max_total_tokens)
        env["EVALLAB_OPENROUTER_MAX_COST_MICROS"] = str(limits.max_cost_micros)
        env[OPENROUTER_CAPABILITY_EXPIRES_AT_ENV] = str(time.time() + float(timeout_seconds) + 60.0)
        return _proxy_503_wait_passthrough(env)
    env[ZAI_OPENAPI_SECRET_PATH_ENV] = str(secret_path)
    upstream = os.environ.get(ZAI_OPENAPI_UPSTREAM_ENV)
    if upstream:
        env[ZAI_OPENAPI_UPSTREAM_ENV] = upstream
    env.update(_capture_route_token(upstream, attempt_id))
    env[ZAI_OPENAPI_PROXY_CAPABILITY_ENV] = capability
    env[ZAI_OPENAPI_PROXY_ATTEMPT_ID_ENV] = attempt_id
    env[ZAI_OPENAPI_PROXY_USAGE_FILE_ENV] = str(usage_path)
    env[ZAI_OPENAPI_ALLOWED_MODEL_ENV] = os.environ.get(
        ZAI_OPENAPI_ALLOWED_MODEL_ENV, ZAI_OPENAPI_ALLOWED_MODEL
    )
    env["EVALLAB_ZAI_OPENAPI_MAX_REQUESTS"] = str(limits.max_requests)
    env["EVALLAB_ZAI_OPENAPI_MAX_INPUT_TOKENS"] = str(limits.max_input_tokens)
    env["EVALLAB_ZAI_OPENAPI_MAX_OUTPUT_TOKENS"] = str(limits.max_output_tokens)
    env["EVALLAB_ZAI_OPENAPI_MAX_TOTAL_TOKENS"] = str(limits.max_total_tokens)
    env["EVALLAB_ZAI_OPENAPI_MAX_COST_MICROS"] = str(limits.max_cost_micros)
    env["EVALLAB_ZAI_OPENAPI_INPUT_COST_MICROS_PER_MILLION"] = os.environ.get(
        "EVALLAB_ZAI_OPENAPI_INPUT_COST_MICROS_PER_MILLION",
        str(ZAI_OPENAPI_INPUT_COST_MICROS_PER_MILLION),
    )
    env["EVALLAB_ZAI_OPENAPI_OUTPUT_COST_MICROS_PER_MILLION"] = os.environ.get(
        "EVALLAB_ZAI_OPENAPI_OUTPUT_COST_MICROS_PER_MILLION",
        str(ZAI_OPENAPI_OUTPUT_COST_MICROS_PER_MILLION),
    )
    env[ZAI_OPENAPI_CAPABILITY_EXPIRES_AT_ENV] = str(time.time() + float(timeout_seconds) + 60.0)
    return _proxy_503_wait_passthrough(env)


def _terminus_proxy_stderr_tail(stderr_path: Path) -> str:
    try:
        data = stderr_path.read_bytes()[-_TERMINUS_PROXY_STDERR_TAIL_BYTES:]
    except OSError:
        return ""
    return data.decode("utf-8", errors="replace").strip()


def _start_terminus_proxy(
    *,
    provider: str,
    secret_path: Path,
    capability: str,
    attempt_id: str,
    usage_path: Path,
    limits: ProxyTrialLimits,
    timeout_seconds: float,
    work_dir: Path,
    tinker_spec: TinkerModelSpec | None = None,
    mimo_native: str | None = None,
    openrouter_spec: OpenRouterRoute | None = None,
    breaker_native: str | None = None,
    mimo_sampling_profile: str = "generation-config",
    live_dir: Path | None = None,
) -> tuple[subprocess.Popen[bytes], str]:
    """Start the per-trial loopback proxy; return (process, proxy URL).

    Fails closed before Harbor launches when the proxy cannot bind, exits
    early, or withholds its ready file. The caller owns termination via
    :func:`_stop_terminus_proxy` on every exit path.
    """
    script = (_RUNTIME_ROOT / ZAI_OPENAPI_PROXY_SCRIPT).resolve()
    if not script.is_file():
        raise RuntimeError(f"metered provider secret proxy is missing: {script}")
    ready_path = work_dir / "terminus-proxy-ready.json"
    stderr_path = work_dir / "terminus-proxy-stderr.log"
    with suppress(FileNotFoundError):
        ready_path.unlink()
    env = _terminus_proxy_env(
        provider=provider,
        secret_path=secret_path,
        capability=capability,
        attempt_id=attempt_id,
        usage_path=usage_path,
        limits=limits,
        timeout_seconds=timeout_seconds,
        tinker_spec=tinker_spec,
        mimo_native=mimo_native,
        openrouter_spec=openrouter_spec,
        breaker_native=breaker_native,
        mimo_sampling_profile=mimo_sampling_profile,
        live_dir=live_dir,
    )
    cmd = [
        sys.executable,
        str(script),
        "--provider",
        provider,
        "--host",
        _TERMINUS_PROXY_HOST,
        "--port",
        "0",
        "--ready-file",
        str(ready_path),
    ]
    if live_dir is not None:
        cmd.extend(["--live-dir", str(live_dir)])
    with open(stderr_path, "wb") as stderr_handle:
        os.chmod(stderr_path, 0o600)
        process = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=stderr_handle,
            env=env,
            start_new_session=True,
        )
    try:
        deadline = time.monotonic() + _TERMINUS_PROXY_READY_TIMEOUT_SECONDS
        while True:
            if process.poll() is not None:
                raise RuntimeError(
                    "terminus loopback proxy exited before becoming ready; "
                    f"inspect {stderr_path}"
                    + (
                        f": {_terminus_proxy_stderr_tail(stderr_path)}"
                        if _terminus_proxy_stderr_tail(stderr_path)
                        else ""
                    )
                )
            if ready_path.is_file():
                try:
                    ready = json.loads(ready_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError, UnicodeDecodeError) as exc:
                    raise RuntimeError(
                        f"terminus loopback proxy ready file is invalid: {ready_path}"
                    ) from exc
                host = ready.get("host") if isinstance(ready, dict) else None
                port = ready.get("port") if isinstance(ready, dict) else None
                if (
                    host != _TERMINUS_PROXY_HOST
                    or isinstance(port, bool)
                    or not isinstance(port, int)
                    or not 1 <= port <= 65535
                ):
                    raise RuntimeError(
                        "terminus loopback proxy reported an unexpected endpoint; "
                        f"inspect {stderr_path}"
                    )
                return process, f"http://{_TERMINUS_PROXY_HOST}:{port}"
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    "terminus loopback proxy did not become ready; "
                    f"inspect {stderr_path}"
                    + (
                        f": {_terminus_proxy_stderr_tail(stderr_path)}"
                        if _terminus_proxy_stderr_tail(stderr_path)
                        else ""
                    )
                )
            time.sleep(0.05)
    except BaseException:
        _stop_terminus_proxy(process)
        raise


def _stop_terminus_proxy(process: subprocess.Popen[bytes] | None) -> None:
    """Terminate a supervised loopback proxy; safe to call repeatedly."""
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=_TERMINUS_PROXY_STOP_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        process.kill()
        with suppress(subprocess.TimeoutExpired):
            process.wait(timeout=5)


#: Host the bridge binds; the sandbox reaches the same port as
#: ``CLAUDE_GATEWAY_SANDBOX_HOST`` (Docker Desktop host name).
_CLAUDE_GATEWAY_PROXY_HOST = "127.0.0.1"
_CLAUDE_GATEWAY_READY_TIMEOUT_SECONDS = 20.0
_CLAUDE_GATEWAY_STOP_TIMEOUT_SECONDS = 130.0
_CLAUDE_GATEWAY_STDERR_TAIL_BYTES = 4096


def _claude_gateway_stderr_tail(stderr_path: Path) -> str:
    """Last bytes of the bridge log for a launch refusal, shape-only."""
    try:
        data = stderr_path.read_bytes()[-_CLAUDE_GATEWAY_STDERR_TAIL_BYTES:]
    except OSError:
        return ""
    return data.decode(errors="replace").strip()


def _start_claude_gateway_bridge(
    *,
    capability: str,
    attempt_id: str,
    usage_path: Path,
    allowed_model: str,
    work_dir: Path,
    stdio_command: str | None = None,
) -> tuple[subprocess.Popen[bytes], int]:
    """Start the per-job gateway bridge; return (process, host port).

    Fails closed before Harbor launches when the bridge script is missing,
    the stdio child withholds its ready line, or the bridge exits early.
    The caller owns termination via :func:`_stop_claude_gateway_bridge` on
    every exit path. ``stdio_command`` is a tests-only override for the
    gateway child argv; production callers omit it.
    """
    script = (_RUNTIME_ROOT / CLAUDE_GATEWAY_BRIDGE_SCRIPT).resolve()
    if not script.is_file():
        raise RuntimeError(f"Claude gateway bridge is missing: {script}")
    ready_path = work_dir / "claude-gateway-ready.json"
    stderr_path = work_dir / "claude-gateway-stderr.log"
    with suppress(FileNotFoundError):
        ready_path.unlink()
    env = {
        CLAUDE_GATEWAY_CAPABILITY_ENV: capability,
        CLAUDE_GATEWAY_ATTEMPT_ENV: attempt_id,
        CLAUDE_GATEWAY_USAGE_FILE_ENV: str(usage_path),
        "PATH": os.environ.get("PATH", ""),
        "HOME": os.environ.get("HOME", ""),
        "USER": os.environ.get("USER", ""),
        "TMPDIR": os.environ.get("TMPDIR", ""),
    }
    cmd = [
        sys.executable,
        str(script),
        "--host",
        _CLAUDE_GATEWAY_PROXY_HOST,
        "--port",
        "0",
        "--ready-file",
        str(ready_path),
        "--attempt-id",
        attempt_id,
        "--usage-file",
        str(usage_path),
        "--allowed-model",
        allowed_model,
    ]
    if stdio_command is not None:
        # Tests only: point the bridge at a stub stdio child. Production
        # callers omit this and the bridge spawns the real gateway.
        cmd.extend(["--stdio-command", stdio_command])
    with open(stderr_path, "wb") as stderr_handle:
        os.chmod(stderr_path, 0o600)
        process = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=stderr_handle,
            env=env,
            start_new_session=True,
        )
    try:
        deadline = time.monotonic() + _CLAUDE_GATEWAY_READY_TIMEOUT_SECONDS
        while True:
            if process.poll() is not None:
                raise RuntimeError(
                    "Claude gateway bridge exited before becoming ready; "
                    f"inspect {stderr_path}"
                    + (
                        f": {_claude_gateway_stderr_tail(stderr_path)}"
                        if _claude_gateway_stderr_tail(stderr_path)
                        else ""
                    )
                )
            if ready_path.is_file():
                try:
                    ready = json.loads(ready_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError, UnicodeDecodeError) as exc:
                    raise RuntimeError(
                        f"Claude gateway bridge ready file is invalid: {ready_path}"
                    ) from exc
                host = ready.get("host") if isinstance(ready, dict) else None
                port = ready.get("port") if isinstance(ready, dict) else None
                if (
                    host != _CLAUDE_GATEWAY_PROXY_HOST
                    or isinstance(port, bool)
                    or not isinstance(port, int)
                    or not 1 <= port <= 65535
                ):
                    raise RuntimeError(
                        "Claude gateway bridge reported an unexpected endpoint; "
                        f"inspect {stderr_path}"
                    )
                return process, port
            if time.monotonic() >= deadline:
                raise RuntimeError(
                    "Claude gateway bridge did not become ready; "
                    f"inspect {stderr_path}"
                    + (
                        f": {_claude_gateway_stderr_tail(stderr_path)}"
                        if _claude_gateway_stderr_tail(stderr_path)
                        else ""
                    )
                )
            time.sleep(0.05)
    except BaseException:
        _stop_claude_gateway_bridge(process)
        raise


def _stop_claude_gateway_bridge(process: subprocess.Popen[bytes] | None) -> None:
    """Terminate a supervised gateway bridge; safe to call repeatedly."""
    if process is None or process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=_CLAUDE_GATEWAY_STOP_TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        process.kill()
        with suppress(subprocess.TimeoutExpired):
            process.wait(timeout=5)


def _claude_gateway_runtime_env(*, port: int, capability: str) -> dict[str, str]:
    """Harbor-child environment for the gateway lane.

    The sandbox reaches the host-loopback bridge as ``host.docker.internal``
    and presents the per-trial capability as ``ANTHROPIC_AUTH_TOKEN``
    (custom-base-URL auth). ``CLAUDE_FORCE_OAUTH`` must stay off: with it on
    and no OAuth token, Harbor refuses before any sandbox starts.
    """
    return {
        "ANTHROPIC_BASE_URL": f"http://{CLAUDE_GATEWAY_SANDBOX_HOST}:{port}",
        "ANTHROPIC_AUTH_TOKEN": capability,
        "CLAUDE_FORCE_OAUTH": "0",
        CLAUDE_GATEWAY_ISOLATION_PORT_ENV: str(port),
    }


def run_harbor_process(
    command: list[str],
    *,
    cwd: Path,
    timeout_seconds: float,
    log_path: Path,
    job_dir: Path | None = None,
    trial_timeout_seconds: float | None = None,
    lease_path: Path | None = None,
    lease_generation: str | None = None,
    proxy_attempt_id: str | None = None,
    proxy_limits: ProxyTrialLimits | None = None,
    laminar_metadata: dict[str, Any] | None = None,
    heartbeat_interval_seconds: float = DEFAULT_HEARTBEAT_INTERVAL_SECONDS,
    claude_gateway_model: str | None = None,
    docker_platform: str | None = None,
    include_modal_credentials: bool = False,
) -> HarborProcessResult:
    """Run Harbor while redacting provider credentials before log persistence."""
    if lease_path is not None and lease_generation is None:
        raise ValueError("lease_generation is required when lease_path is set")
    if _lease_cancelled_or_lost(lease_path, lease_generation):
        raise ExecutionFailure(
            "execution_cancelled",
            "campaign owner cancelled the active queue lease before Harbor launch",
        )
    repo_imports = (
        HOST_ISOLATED_DOCKER_ENVIRONMENT_IMPORT_PATH,
        LOCKED_DOCKER_ENVIRONMENT_IMPORT_PATH,
        *HARBOR_AGENT_IMPORT_PATHS.values(),
        ZAI_MINISWE_AGENT_IMPORT_PATH,
        TERMINUS_AGENT_IMPORT_PATH,
        HARBOR_STATE_JOURNAL_PLUGIN,
    )
    deepseek_adapter = HARBOR_AGENT_IMPORT_PATHS["mini-swe-agent"]
    deepseek_lane = deepseek_adapter in command
    zai_adapter = HARBOR_AGENT_IMPORT_PATHS[ZAI_OPENCODE_AGENT]
    zai_lane = zai_adapter in command
    zai_miniswe_adapter = ZAI_MINISWE_AGENT_IMPORT_PATH
    # Native Xiaomi and Terminus model clients live on the controller host.
    # Both use this supervised loopback proxy, never a sandbox-side transport.
    terminus_client = TERMINUS_AGENT_IMPORT_PATH in command or MIMO_AGENT_IMPORT_PATH in command
    local_terminus = terminus_client and TERMINUS_LOCAL_MODEL_SELECTOR in command
    terminus_lane = terminus_client and not local_terminus
    zai_openapi_lane = (
        (
            zai_miniswe_adapter in command
            or any(
                arg.startswith("zai/") for arg in command if not arg.startswith("zai-coding-plan/")
            )
        )
        and not zai_lane
        and not terminus_client
    )
    rlm_adapter = HARBOR_AGENT_IMPORT_PATHS[RLM_AGENT]
    rlm_lane = rlm_adapter in command
    environment_selector = command[command.index("--env") + 1] if "--env" in command else None
    runtime_environment = subscription_environment(
        include_deepseek_credentials=deepseek_lane,
        include_zai_credentials=zai_lane,
        include_zai_openapi_credentials=zai_openapi_lane,
        include_laminar_credentials=MIMO_AGENT_IMPORT_PATH in command,
        include_daytona_credentials=environment_selector in _DAYTONA_ENVIRONMENT_SELECTORS,
        include_modal_credentials=include_modal_credentials,
        docker_platform=docker_platform,
    )
    if MIMO_AGENT_IMPORT_PATH in command and laminar_metadata is not None:
        runtime_environment["EVALLAB_LAMINAR_METADATA"] = json.dumps(laminar_metadata)
    if local_terminus:
        runtime_environment[TERMINUS_LOCAL_ENDPOINT_ENV] = local_ollama_endpoint()
    secret_values = collected_secret_values()
    owned_secret_dir: Path | None = None
    owned_secret_path: Path | None = None
    owned_usage_dir: Path | None = None
    owned_usage_path: Path | None = None
    capability_id: str | None = None
    proxy_pricing: dict[str, int | None] | None = None
    terminus_proxy: subprocess.Popen[bytes] | None = None
    claude_gateway_bridge: subprocess.Popen[bytes] | None = None
    claude_gateway_usage_dir: Path | None = None
    claude_gateway_usage_path: Path | None = None
    try:
        if job_dir is not None:
            runtime_environment[PROXY_LIVE_DIR_ENV] = str(job_dir / PROXY_LIVE_DIR_NAME)
        if deepseek_lane:
            if proxy_attempt_id is None or proxy_limits is None:
                raise ValueError("DeepSeek execution requires a bound trial capability")
            capability = secrets.token_urlsafe(32)
            capability_id = "sha256:" + hashlib.sha256(capability.encode()).hexdigest()
            owned_usage_dir = Path(
                tempfile.mkdtemp(
                    prefix="evallab-deepseek-usage.",
                    dir=os.environ.get("TMPDIR") or None,
                )
            )
            os.chmod(owned_usage_dir, 0o700)
            owned_usage_path = owned_usage_dir / "deepseek-proxy-usage.json"
            runtime_environment[DEEPSEEK_PROXY_CAPABILITY_ENV] = capability
            runtime_environment[DEEPSEEK_PROXY_ATTEMPT_ID_ENV] = proxy_attempt_id
            runtime_environment[DEEPSEEK_PROXY_USAGE_DIR_ENV] = str(owned_usage_dir)
            runtime_environment[DEEPSEEK_PROXY_USAGE_FILE_ENV] = str(owned_usage_path)
            runtime_environment["DEEPSEEK_API_KEY"] = capability
            runtime_environment["MSWEA_API_KEY"] = capability
            runtime_environment[DEEPSEEK_ALLOWED_MODEL_ENV] = os.environ.get(
                DEEPSEEK_ALLOWED_MODEL_ENV, DEEPSEEK_ALLOWED_MODEL
            )
            runtime_environment["EVALLAB_DEEPSEEK_MAX_REQUESTS"] = str(proxy_limits.max_requests)
            runtime_environment["EVALLAB_DEEPSEEK_MAX_INPUT_TOKENS"] = str(
                proxy_limits.max_input_tokens
            )
            runtime_environment["EVALLAB_DEEPSEEK_MAX_OUTPUT_TOKENS"] = str(
                proxy_limits.max_output_tokens
            )
            runtime_environment["EVALLAB_DEEPSEEK_MAX_TOTAL_TOKENS"] = str(
                proxy_limits.max_total_tokens
            )
            runtime_environment["EVALLAB_DEEPSEEK_MAX_COST_MICROS"] = str(
                proxy_limits.max_cost_micros
            )
            runtime_environment["EVALLAB_DEEPSEEK_INPUT_COST_MICROS_PER_MILLION"] = os.environ.get(
                "EVALLAB_DEEPSEEK_INPUT_COST_MICROS_PER_MILLION",
                "280000",
            )
            runtime_environment["EVALLAB_DEEPSEEK_OUTPUT_COST_MICROS_PER_MILLION"] = os.environ.get(
                "EVALLAB_DEEPSEEK_OUTPUT_COST_MICROS_PER_MILLION",
                "420000",
            )
            runtime_environment["EVALLAB_DEEPSEEK_CAPABILITY_EXPIRES_AT"] = str(
                time.time() + float(timeout_seconds) + 60.0
            )
            existing_secret = runtime_environment.get(DEEPSEEK_SECRET_FILE_ENV) or os.environ.get(
                DEEPSEEK_SECRET_FILE_ENV
            )
            log_root = log_path.resolve()
            if existing_secret:
                try:
                    read_owner_secret_file(Path(existing_secret))
                    existing_path = Path(existing_secret).resolve()
                except OSError:
                    existing_secret = None
                else:
                    if log_root.parent in existing_path.parents or (
                        job_dir is not None and job_dir.resolve() in existing_path.parents
                    ):
                        existing_secret = None
            if existing_secret:
                runtime_environment[DEEPSEEK_SECRET_FILE_ENV] = existing_secret
            else:
                owned_secret_dir = Path(
                    tempfile.mkdtemp(
                        prefix="evallab-deepseek-secret.",
                        dir=os.environ.get("TMPDIR") or None,
                    )
                )
                os.chmod(owned_secret_dir, 0o700)
                owned_secret_path = owned_secret_dir / "key"
                materialize_deepseek_secret_file(owned_secret_path)
                runtime_environment[DEEPSEEK_SECRET_FILE_ENV] = str(owned_secret_path)
            runtime_environment[DEEPSEEK_PROXY_SCRIPT_ENV] = str(
                (_RUNTIME_ROOT / DEEPSEEK_PROXY_SCRIPT).resolve()
            )
            proxy_uid, proxy_gid = proxy_runtime_identity(
                Path(runtime_environment[DEEPSEEK_SECRET_FILE_ENV])
            )
            runtime_environment[DEEPSEEK_PROXY_UID_ENV] = str(proxy_uid)
            runtime_environment[DEEPSEEK_PROXY_GID_ENV] = str(proxy_gid)
            secret_values = collected_secret_values({**os.environ, **runtime_environment})
        if zai_lane:
            if proxy_attempt_id is None or proxy_limits is None:
                raise ValueError("Z.ai execution requires a bound trial capability")
            capability = secrets.token_urlsafe(32)
            capability_id = "sha256:" + hashlib.sha256(capability.encode()).hexdigest()
            owned_usage_dir = Path(
                tempfile.mkdtemp(
                    prefix="evallab-zai-usage.",
                    dir=os.environ.get("TMPDIR") or None,
                )
            )
            os.chmod(owned_usage_dir, 0o700)
            owned_usage_path = owned_usage_dir / "zai-proxy-usage.json"
            runtime_environment[ZAI_PROXY_ATTEMPT_ID_ENV] = proxy_attempt_id
            runtime_environment[ZAI_PROXY_USAGE_DIR_ENV] = str(owned_usage_dir)
            runtime_environment[ZAI_PROXY_USAGE_FILE_ENV] = str(owned_usage_path)
            runtime_environment["EVALLAB_ZAI_MAX_REQUESTS"] = str(proxy_limits.max_requests)
            runtime_environment["EVALLAB_ZAI_MAX_INPUT_TOKENS"] = str(proxy_limits.max_input_tokens)
            runtime_environment["EVALLAB_ZAI_MAX_OUTPUT_TOKENS"] = str(
                proxy_limits.max_output_tokens
            )
            runtime_environment["EVALLAB_ZAI_MAX_TOTAL_TOKENS"] = str(proxy_limits.max_total_tokens)
            runtime_environment["EVALLAB_ZAI_MAX_COST_MICROS"] = str(proxy_limits.max_cost_micros)
            proxy_pricing = {
                "input_cost_micros_per_million": ZAI_INPUT_COST_MICROS_PER_MILLION,
                "output_cost_micros_per_million": ZAI_OUTPUT_COST_MICROS_PER_MILLION,
            }
            runtime_environment["EVALLAB_ZAI_INPUT_COST_MICROS_PER_MILLION"] = str(
                ZAI_INPUT_COST_MICROS_PER_MILLION
            )
            runtime_environment["EVALLAB_ZAI_OUTPUT_COST_MICROS_PER_MILLION"] = str(
                ZAI_OUTPUT_COST_MICROS_PER_MILLION
            )
            owned_secret_dir = Path(
                tempfile.mkdtemp(
                    prefix="evallab-zai-secret.",
                    dir=os.environ.get("TMPDIR") or None,
                )
            )
            os.chmod(owned_secret_dir, 0o700)
            owned_secret_path = owned_secret_dir / "key"
            materialize_zai_secret_file(owned_secret_path)
            runtime_environment[ZAI_SECRET_FILE_ENV] = str(owned_secret_path)
            runtime_environment[ZAI_PROXY_SCRIPT_ENV] = str(
                (_RUNTIME_ROOT / ZAI_PROXY_SCRIPT).resolve()
            )
            proxy_uid, proxy_gid = proxy_runtime_identity(owned_secret_path)
            runtime_environment[ZAI_PROXY_UID_ENV] = str(proxy_uid)
            runtime_environment[ZAI_PROXY_GID_ENV] = str(proxy_gid)
            runtime_environment[ZAI_PROXY_CAPABILITY_ENV] = capability
            runtime_environment[ZAI_CAPABILITY_EXPIRES_AT_ENV] = str(
                time.time() + float(timeout_seconds) + 60.0
            )
            runtime_environment["ZAI_CODING_PLAN_API_KEY"] = capability
            runtime_environment["ZAI_API_KEY"] = capability
            secret_values = collected_secret_values({**os.environ, **runtime_environment})
        if zai_openapi_lane:
            if proxy_attempt_id is None or proxy_limits is None:
                raise ValueError("Z.ai OpenAPI execution requires a bound trial capability")
            capability = secrets.token_urlsafe(32)
            capability_id = "sha256:" + hashlib.sha256(capability.encode()).hexdigest()
            owned_usage_dir = Path(
                tempfile.mkdtemp(
                    prefix="evallab-zai-openapi-usage.",
                    dir=os.environ.get("TMPDIR") or None,
                )
            )
            os.chmod(owned_usage_dir, 0o700)
            owned_usage_path = owned_usage_dir / "zai-openapi-proxy-usage.json"
            runtime_environment[ZAI_OPENAPI_PROXY_CAPABILITY_ENV] = capability
            runtime_environment[ZAI_OPENAPI_PROXY_ATTEMPT_ID_ENV] = proxy_attempt_id
            runtime_environment[ZAI_OPENAPI_PROXY_USAGE_DIR_ENV] = str(owned_usage_dir)
            runtime_environment[ZAI_OPENAPI_PROXY_USAGE_FILE_ENV] = str(owned_usage_path)
            runtime_environment["ZAI_OPENAPI_API_KEY"] = capability
            runtime_environment["MSWEA_API_KEY"] = capability
            runtime_environment[ZAI_OPENAPI_ALLOWED_MODEL_ENV] = os.environ.get(
                ZAI_OPENAPI_ALLOWED_MODEL_ENV, ZAI_OPENAPI_ALLOWED_MODEL
            )
            runtime_environment["EVALLAB_ZAI_OPENAPI_MAX_REQUESTS"] = str(proxy_limits.max_requests)
            runtime_environment["EVALLAB_ZAI_OPENAPI_MAX_INPUT_TOKENS"] = str(
                proxy_limits.max_input_tokens
            )
            runtime_environment["EVALLAB_ZAI_OPENAPI_MAX_OUTPUT_TOKENS"] = str(
                proxy_limits.max_output_tokens
            )
            runtime_environment["EVALLAB_ZAI_OPENAPI_MAX_TOTAL_TOKENS"] = str(
                proxy_limits.max_total_tokens
            )
            runtime_environment["EVALLAB_ZAI_OPENAPI_MAX_COST_MICROS"] = str(
                proxy_limits.max_cost_micros
            )
            proxy_pricing = {
                "input_cost_micros_per_million": int(
                    os.environ.get(
                        "EVALLAB_ZAI_OPENAPI_INPUT_COST_MICROS_PER_MILLION",
                        str(ZAI_OPENAPI_INPUT_COST_MICROS_PER_MILLION),
                    )
                ),
                "output_cost_micros_per_million": int(
                    os.environ.get(
                        "EVALLAB_ZAI_OPENAPI_OUTPUT_COST_MICROS_PER_MILLION",
                        str(ZAI_OPENAPI_OUTPUT_COST_MICROS_PER_MILLION),
                    )
                ),
            }
            runtime_environment["EVALLAB_ZAI_OPENAPI_INPUT_COST_MICROS_PER_MILLION"] = str(
                proxy_pricing["input_cost_micros_per_million"]
            )
            runtime_environment["EVALLAB_ZAI_OPENAPI_OUTPUT_COST_MICROS_PER_MILLION"] = str(
                proxy_pricing["output_cost_micros_per_million"]
            )
            runtime_environment[ZAI_OPENAPI_CAPABILITY_EXPIRES_AT_ENV] = str(
                time.time() + float(timeout_seconds) + 60.0
            )
            existing_secret = runtime_environment.get(
                ZAI_OPENAPI_SECRET_FILE_ENV
            ) or os.environ.get(ZAI_OPENAPI_SECRET_FILE_ENV)
            log_root = log_path.resolve()
            if existing_secret:
                try:
                    read_owner_secret_file(Path(existing_secret))
                    existing_path = Path(existing_secret).resolve()
                except OSError:
                    existing_secret = None
                else:
                    if log_root.parent in existing_path.parents or (
                        job_dir is not None and job_dir.resolve() in existing_path.parents
                    ):
                        existing_secret = None
            if existing_secret:
                runtime_environment[ZAI_OPENAPI_SECRET_FILE_ENV] = existing_secret
            else:
                owned_secret_dir = Path(
                    tempfile.mkdtemp(
                        prefix="evallab-zai-openapi-secret.",
                        dir=os.environ.get("TMPDIR") or None,
                    )
                )
                os.chmod(owned_secret_dir, 0o700)
                owned_secret_path = owned_secret_dir / "key"
                materialize_zai_openapi_secret_file(owned_secret_path)
                runtime_environment[ZAI_OPENAPI_SECRET_FILE_ENV] = str(owned_secret_path)
            runtime_environment[ZAI_OPENAPI_PROXY_SCRIPT_ENV] = str(
                (_RUNTIME_ROOT / ZAI_OPENAPI_PROXY_SCRIPT).resolve()
            )
            proxy_uid, proxy_gid = proxy_runtime_identity(
                Path(runtime_environment[ZAI_OPENAPI_SECRET_FILE_ENV])
            )
            runtime_environment[ZAI_OPENAPI_PROXY_UID_ENV] = str(proxy_uid)
            runtime_environment[ZAI_OPENAPI_PROXY_GID_ENV] = str(proxy_gid)
            secret_values = collected_secret_values({**os.environ, **runtime_environment})
        if terminus_lane:
            if proxy_attempt_id is None or proxy_limits is None:
                raise ValueError("Terminus execution requires a bound trial capability")
            # The command's --model value selects the provider profile: a
            # ``selfhosted/`` selector routes to the self-hosted MiMo profile,
            # a ``tinker/`` selector to the Tinker profile, an
            # ``openrouter-metered/`` selector to the OpenRouter profile,
            # every other metered Terminus model to Z.ai OpenAPI.
            mimo_client = any(
                isinstance(arg, str) and arg.startswith("selfhosted/") for arg in command
            )
            tinker_client = any(
                isinstance(arg, str) and arg.startswith("tinker/") for arg in command
            )
            openrouter_client = any(
                isinstance(arg, str) and arg.startswith("openrouter-metered/") for arg in command
            )
            model_args = [
                command[index + 1]
                for index, arg in enumerate(command)
                if arg == "--model" and index + 1 < len(command)
            ]
            model_value = model_args[-1] if model_args else None
            breaker_client = is_breaker_selfhosted_model(model_value)
            breaker_native = parse_breaker_selfhosted_model(model_value) if breaker_client else None
            mimo_native = parse_mimo_selfhosted_model(model_value) if mimo_client else None
            tinker_spec = parse_tinker_model(model_value) if tinker_client else None
            openrouter_spec = openrouter_route(model_value) if openrouter_client else None
            provider = (
                MIMO_SELFHOSTED_PROXY_PROVIDER
                if mimo_client
                else (
                    OPENROUTER_PROXY_PROVIDER
                    if openrouter_client
                    else ("tinker" if tinker_client else "zai_openapi")
                )
            )
            if breaker_client:
                provider = BREAKER_SELFHOSTED_PROXY_PROVIDER
            capability = secrets.token_urlsafe(32)
            capability_id = "sha256:" + hashlib.sha256(capability.encode()).hexdigest()
            owned_usage_dir = Path(
                tempfile.mkdtemp(
                    prefix="evallab-terminus-usage.",
                    dir=os.environ.get("TMPDIR") or None,
                )
            )
            os.chmod(owned_usage_dir, 0o700)
            owned_usage_path = owned_usage_dir / "terminus-proxy-usage.json"
            if breaker_native is not None:
                proxy_pricing = {
                    "input_cost_micros_per_million": 0,
                    "output_cost_micros_per_million": 0,
                }
            elif mimo_native is not None:
                # Self-hosted tokens have no per-token price; spend is
                # governed by the time-based server estimate, not this ledger.
                input_rate, output_rate = MIMO_SELFHOSTED_MODEL_PRICES_MICROS[mimo_native]
                proxy_pricing = {
                    "input_cost_micros_per_million": input_rate,
                    "output_cost_micros_per_million": output_rate,
                }
            elif tinker_spec is not None:
                proxy_pricing = {
                    "input_cost_micros_per_million": tinker_spec.input_cost_micros_per_million,
                    "output_cost_micros_per_million": tinker_spec.output_cost_micros_per_million,
                }
            elif openrouter_spec is not None:
                # The pinned OpenRouter list price is exact for the pinned
                # endpoint. The cached rate rides along so the binding matches
                # the ledger's full rate card; reservations still use the
                # uncached input rate.
                proxy_pricing = {
                    "input_cost_micros_per_million": (
                        openrouter_spec.input_cost_micros_per_million
                    ),
                    "output_cost_micros_per_million": (
                        openrouter_spec.output_cost_micros_per_million
                    ),
                    "cached_input_cost_micros_per_million": (
                        openrouter_spec.cached_input_cost_micros_per_million
                    ),
                }
            else:
                input_rate, output_rate = zai_openapi_price_for(
                    str(model_value or ZAI_OPENAPI_MODEL_SELECTOR)
                )
                proxy_pricing = {
                    "input_cost_micros_per_million": int(
                        os.environ.get(
                            "EVALLAB_ZAI_OPENAPI_INPUT_COST_MICROS_PER_MILLION",
                            str(input_rate),
                        )
                    ),
                    "output_cost_micros_per_million": int(
                        os.environ.get(
                            "EVALLAB_ZAI_OPENAPI_OUTPUT_COST_MICROS_PER_MILLION",
                            str(output_rate),
                        )
                    ),
                }
            secret_file_env = (
                MIMO_SELFHOSTED_SECRET_FILE_ENV
                if mimo_client
                else (
                    OPENROUTER_SECRET_FILE_ENV
                    if openrouter_client
                    else (TINKER_SECRET_FILE_ENV if tinker_client else ZAI_OPENAPI_SECRET_FILE_ENV)
                )
            )
            if breaker_client:
                secret_file_env = BREAKER_SELFHOSTED_SECRET_FILE_ENV
            existing_secret = runtime_environment.get(secret_file_env) or os.environ.get(
                secret_file_env
            )
            log_root = log_path.resolve()
            if existing_secret:
                try:
                    read_owner_secret_file(Path(existing_secret))
                    existing_path = Path(existing_secret).resolve()
                except OSError:
                    existing_secret = None
                else:
                    if log_root.parent in existing_path.parents or (
                        job_dir is not None and job_dir.resolve() in existing_path.parents
                    ):
                        existing_secret = None
            if existing_secret:
                secret_path = Path(existing_secret)
            else:
                owned_secret_dir = Path(
                    tempfile.mkdtemp(
                        prefix="evallab-terminus-secret.",
                        dir=os.environ.get("TMPDIR") or None,
                    )
                )
                os.chmod(owned_secret_dir, 0o700)
                owned_secret_path = owned_secret_dir / "key"
                if breaker_client:
                    materialize_breaker_selfhosted_secret_file(owned_secret_path)
                elif mimo_client:
                    materialize_mimo_selfhosted_secret_file(owned_secret_path)
                elif openrouter_client:
                    materialize_openrouter_secret_file(owned_secret_path)
                elif tinker_client:
                    materialize_tinker_secret_file(owned_secret_path)
                else:
                    materialize_zai_openapi_secret_file(owned_secret_path)
                secret_path = owned_secret_path
            # Host-side model route: the proxy runs as a loopback supervisor
            # child, not a task-container compose sidecar. The Harbor child
            # receives only the loopback URL plus the trial capability; the
            # real provider key stays in the owner-only secret file.
            terminus_proxy, terminus_proxy_url = _start_terminus_proxy(
                provider=provider,
                secret_path=secret_path,
                capability=capability,
                attempt_id=proxy_attempt_id,
                usage_path=owned_usage_path,
                limits=proxy_limits,
                timeout_seconds=timeout_seconds,
                work_dir=owned_usage_dir,
                tinker_spec=tinker_spec,
                mimo_native=mimo_native,
                openrouter_spec=openrouter_spec,
                breaker_native=breaker_native,
                mimo_sampling_profile=(
                    "xiaomi-rl" if MIMO_AGENT_IMPORT_PATH in command else "generation-config"
                ),
                live_dir=(job_dir / PROXY_LIVE_DIR_NAME) if job_dir is not None else None,
            )
            if breaker_client:
                runtime_environment["OPENAI_API_KEY"] = capability
                runtime_environment[BREAKER_SELFHOSTED_PROXY_CAPABILITY_ENV] = capability
            elif mimo_client:
                # litellm's openai-compatible lookup reads this in the
                # controller process; the adapter overwrites it with the
                # capability before any call. Never a task-container value.
                runtime_environment["OPENAI_API_KEY"] = capability
                runtime_environment[MIMO_SELFHOSTED_PROXY_CAPABILITY_ENV] = capability
            elif openrouter_client:
                runtime_environment[OPENROUTER_PROXY_CAPABILITY_ENV] = capability
                # litellm's openai-compatible lookup reads this in the
                # controller process; the adapter overwrites it with the
                # capability before any call. Never a task-container value.
                runtime_environment["OPENAI_API_KEY"] = capability
            elif tinker_client:
                runtime_environment[TINKER_PROXY_CAPABILITY_ENV] = capability
                # litellm's openai-compatible lookup reads this in the
                # controller process; the adapter overwrites it with the
                # capability before any call. Never a task-container value.
                runtime_environment["OPENAI_API_KEY"] = capability
            else:
                runtime_environment[ZAI_OPENAPI_PROXY_CAPABILITY_ENV] = capability
                runtime_environment["ZAI_OPENAPI_API_KEY"] = capability
                runtime_environment["MSWEA_API_KEY"] = capability
            runtime_environment[TERMINUS_PROXY_URL_ENV] = terminus_proxy_url
            secret_values = collected_secret_values({**os.environ, **runtime_environment})

        if rlm_lane:
            # Host-secret-file transport: the lab-owned RLM agent reads the
            # provider key from this owner-only file. No proxy URLs,
            # capability tokens, or OPENAI_BASE_URL overrides are set.
            owned_secret_dir = Path(
                tempfile.mkdtemp(
                    prefix="evallab-rlm-secret.",
                    dir=os.environ.get("TMPDIR") or None,
                )
            )
            os.chmod(owned_secret_dir, 0o700)
            owned_secret_path = owned_secret_dir / "key"
            materialize_zai_secret_file(owned_secret_path)
            runtime_environment[ZAI_SECRET_FILE_ENV] = str(owned_secret_path)
            secret_values = collected_secret_values({**os.environ, **runtime_environment})

        if claude_gateway_model is not None:
            # Subscription lane via OMP's auth-gateway: the lab-owned
            # loopback bridge fronts one stdio child for this job. The
            # sandbox reaches it as host.docker.internal and presents the
            # per-trial capability as ANTHROPIC_AUTH_TOKEN (custom-base-URL
            # auth); CLAUDE_FORCE_OAUTH must stay off or Harbor refuses
            # before any sandbox starts.
            allowed_model = resolve_harbor_model("claude-code", claude_gateway_model)
            if not allowed_model:
                raise ValueError(f"Claude gateway lane cannot resolve {claude_gateway_model!r}")
            claude_gateway_usage_dir = Path(
                tempfile.mkdtemp(
                    prefix="evallab-claude-gateway-usage.",
                    dir=os.environ.get("TMPDIR") or None,
                )
            )
            os.chmod(claude_gateway_usage_dir, 0o700)
            claude_gateway_usage_path = claude_gateway_usage_dir / "claude-gateway-usage.jsonl"
            gateway_capability = secrets.token_urlsafe(32)
            gateway_attempt = proxy_attempt_id or (
                job_dir.name if job_dir is not None else f"claude-gateway-{secrets.token_hex(8)}"
            )
            claude_gateway_bridge, gateway_port = _start_claude_gateway_bridge(
                capability=gateway_capability,
                attempt_id=gateway_attempt,
                usage_path=claude_gateway_usage_path,
                allowed_model=allowed_model,
                work_dir=claude_gateway_usage_dir,
            )
            runtime_environment.update(
                _claude_gateway_runtime_env(port=gateway_port, capability=gateway_capability)
            )
            secret_values = collected_secret_values({**os.environ, **runtime_environment})

        if any(import_path in command for import_path in repo_imports):
            source_root = _RUNTIME_ROOT / "src"
            if source_root.is_dir():
                inherited_pythonpath = os.environ.get("PYTHONPATH")
                runtime_environment["PYTHONPATH"] = os.pathsep.join(
                    str(path) for path in (source_root, inherited_pythonpath) if path
                )
        secret_bytes = tuple(value.encode() for value in secret_values)

        def _persist_claude_gateway_usage() -> None:
            """Copy the bridge usage ledger beside the job as durable evidence.

            Records hold token counts and model identities only -- the bridge
            never writes the capability -- so the file is safe to keep. A
            missing or empty ledger means no gateway call settled; that is
            recorded by absence, never by a zero.
            """
            if job_dir is None or claude_gateway_usage_path is None:
                return
            try:
                data = claude_gateway_usage_path.read_bytes()
            except OSError:
                return
            if not data.strip():
                return
            persist_private_bytes(
                job_dir / CLAUDE_GATEWAY_USAGE_FILENAME,
                data,
                secrets=tuple(value.encode() for value in secret_values),
            )

        def _result(
            *,
            returncode: int,
            timed_out: bool,
            timed_out_trial: str | None = None,
        ) -> HarborProcessResult:
            # Quiesce the loopback proxy before the final ledger read so no
            # in-flight handler can tear the report this function reconciles.
            _stop_terminus_proxy(terminus_proxy)
            _stop_claude_gateway_bridge(claude_gateway_bridge)
            _persist_claude_gateway_usage()
            proxy_usage = None
            if (
                (deepseek_lane or zai_lane or zai_openapi_lane or terminus_lane)
                and owned_usage_path is not None
                and owned_usage_path.is_file()
                and capability_id is not None
                and proxy_attempt_id is not None
                and proxy_limits is not None
            ):
                proxy_usage = _read_proxy_usage(
                    owned_usage_path,
                    capability_id=capability_id,
                    attempt_id=proxy_attempt_id,
                    limits=proxy_limits,
                    provider_label="Mimo self-hosted"
                    if any(
                        isinstance(arg, str) and arg.startswith("selfhosted/") for arg in command
                    )
                    else (
                        "Tinker"
                        if any(
                            isinstance(arg, str) and arg.startswith("tinker/") for arg in command
                        )
                        else (
                            "Z.ai OpenAPI"
                            if (zai_openapi_lane or terminus_lane)
                            else ("Z.ai" if zai_lane else "DeepSeek")
                        )
                    ),
                    expected_pricing=proxy_pricing,
                )
            return HarborProcessResult(
                returncode=returncode,
                timed_out=timed_out,
                log_path=log_path,
                timed_out_trial=timed_out_trial,
                proxy_usage=proxy_usage,
            )

        read_fd, write_fd = os.pipe()
        writer = RedactingBinaryWriter(log_path, secret_bytes)

        def _pump_redacted_output() -> None:
            try:
                with os.fdopen(read_fd, "rb", closefd=True) as source:
                    while True:
                        chunk = source.read(8192)
                        if not chunk:
                            break
                        writer.write(chunk)
            finally:
                writer.close()

        pump = threading.Thread(target=_pump_redacted_output, name="harbor-log-redact", daemon=True)
        try:
            process = subprocess.Popen(
                command,
                cwd=cwd,
                stdin=subprocess.DEVNULL,
                stdout=write_fd,
                stderr=subprocess.STDOUT,
                env=runtime_environment,
                start_new_session=True,
            )
        except BaseException:
            _stop_terminus_proxy(terminus_proxy)
            os.close(write_fd)
            os.close(read_fd)
            writer.close()
            raise
        os.close(write_fd)
        pump.start()
        try:
            started = time.monotonic()
            if (
                lease_path is not None
                and lease_generation is not None
                and not _heartbeat_lease(lease_path, lease_generation)
            ):
                _terminate_process_group(process)
                pump.join(timeout=5)
                return _result(returncode=-1, timed_out=False)
            last_heartbeat = started
            first_seen: dict[Path, float] = {}
            while True:
                if _lease_cancelled_or_lost(lease_path, lease_generation):
                    _terminate_process_group(process)
                    pump.join(timeout=5)
                    return _result(
                        returncode=(process.returncode if process.returncode is not None else -1),
                        timed_out=False,
                    )
                returncode = process.poll()
                if returncode is not None:
                    break
                now = time.monotonic()
                if (
                    lease_path is not None
                    and lease_generation is not None
                    and now - last_heartbeat >= heartbeat_interval_seconds
                ):
                    if not _heartbeat_lease(lease_path, lease_generation):
                        _terminate_process_group(process)
                        pump.join(timeout=5)
                        return _result(
                            returncode=(
                                process.returncode if process.returncode is not None else -1
                            ),
                            timed_out=False,
                        )
                    last_heartbeat = now
                timed_out_trial: str | None = None
                if job_dir is not None and trial_timeout_seconds is not None:
                    active = set(_active_trial_directories(job_dir))
                    first_seen = {
                        path: observed for path, observed in first_seen.items() if path in active
                    }
                    for path in active:
                        first_seen.setdefault(path, now)
                        if now - first_seen[path] >= trial_timeout_seconds:
                            timed_out_trial = path.name
                            break
                if timed_out_trial is not None or now - started >= timeout_seconds:
                    _terminate_process_group(process)
                    pump.join(timeout=5)
                    return _result(
                        returncode=(process.returncode if process.returncode is not None else -1),
                        timed_out=True,
                        timed_out_trial=timed_out_trial,
                    )
                try:
                    process.wait(timeout=WATCHDOG_POLL_SECONDS)
                except subprocess.TimeoutExpired:
                    continue
            pump.join(timeout=5)
            return _result(
                returncode=returncode,
                timed_out=False,
            )

        finally:
            _stop_terminus_proxy(terminus_proxy)
            _stop_claude_gateway_bridge(claude_gateway_bridge)
            _unlink_secret_dir(owned_secret_dir, owned_secret_path)
            _unlink_secret_dir(owned_usage_dir, owned_usage_path)
            _unlink_secret_dir(claude_gateway_usage_dir, claude_gateway_usage_path)
    finally:
        _stop_terminus_proxy(terminus_proxy)
        _stop_claude_gateway_bridge(claude_gateway_bridge)
        _unlink_secret_dir(owned_secret_dir, owned_secret_path)
        _unlink_secret_dir(owned_usage_dir, owned_usage_path)
        _unlink_secret_dir(claude_gateway_usage_dir, claude_gateway_usage_path)


def _executor_log_path(request: RunRequest) -> Path:
    root = request.jobs_dir / ".executor"
    initial = root / f"{request.name}.log"
    if not initial.exists():
        return initial
    attempt = 2
    while True:
        candidate = root / f"{request.name}.attempt-{attempt}.log"
        if not candidate.exists():
            return candidate
        attempt += 1


def executor_state_path(request: RunRequest) -> Path:
    return request.jobs_dir / ".executor" / f"{request.name}.state.json"


def _write_executor_state(
    request: RunRequest,
    *,
    started_at: datetime,
    status: str,
    log_path: Path,
    finished_at: datetime | None = None,
    process: HarborProcessResult | None = None,
) -> None:
    path = executor_state_path(request)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload: dict[str, Any] = {
        "schema_version": 1,
        "status": status,
        "started_at": started_at.isoformat(),
        "finished_at": finished_at.isoformat() if finished_at is not None else None,
        "trial_timeout_seconds": request.trial_watchdog_seconds,
        "job_timeout_seconds": request.job_timeout_seconds,
        "log_path": str(log_path.relative_to(request.jobs_dir)),
    }
    if process is not None:
        payload.update(
            {
                "exit_code": process.returncode,
                "timed_out": process.timed_out,
                "timed_out_trial": process.timed_out_trial,
            }
        )
    persist_private_bytes(
        path,
        (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode(),
        secrets=tuple(value.encode() for value in collected_secret_values()),
    )


def _harbor_project_prefixes(job_dir: Path) -> frozenset[str]:
    if not job_dir.is_dir():
        return frozenset()
    return frozenset(
        re.sub(r"[^a-z0-9_-]", "-", child.name.lower())
        for child in job_dir.iterdir()
        if child.is_dir() and not child.name.startswith(".")
    )


def _transient_reason_from_job(job_dir: Path) -> str | None:
    if job_dir.is_dir():
        for path in sorted(job_dir.rglob("result.json")):
            try:
                payload = json.loads(path.read_text())
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(payload, dict):
                reason = transient_provider_exception(payload)
                if reason is not None:
                    return reason
    return None


def _cleanup_failure(
    request: RunRequest,
    containers_before: frozenset[str],
    job_dir: Path,
) -> str | None:
    if request.environment in _DAYTONA_ENVIRONMENT_SELECTORS:
        return None
    try:
        cleanup_new_harbor_containers(
            request.task,
            containers_before,
            project_prefixes=_harbor_project_prefixes(job_dir),
        )
    except Exception as exc:
        return f"cleanup_failed:{type(exc).__name__}"
    return None


def _task_staging_provenance(
    source: Path, staged: Path, adaptation: NetworkAdaptation | None
) -> dict[str, Any]:
    """Deterministic source-to-stage binding for one executed job.

    Registry evidence discovery recomputes the source digests from the current
    package bytes and matches them against this block, so a staged trial can
    only be accepted when its lock carries exactly the staged name and digest
    proven here for exactly this source package.
    """
    from evallab.registry import compute_task_digests, harbor_task_digest

    resolved = source.resolve()
    task_toml = tomllib.loads((resolved / "task.toml").read_text(encoding="utf-8"))
    task_table = task_toml.get("task")
    declared = task_table.get("name") if isinstance(task_table, dict) else None
    version = task_table.get("version") if isinstance(task_table, dict) else None
    return {
        "schema_version": 1,
        "source_task_basename": resolved.name,
        "declared_task_name": declared,
        "task_version": str(version) if version is not None else None,
        "source_package_digest": compute_task_digests(resolved).package,
        "source_harbor_digest": harbor_task_digest(resolved),
        "staged_task_name": staged.name,
        "staged_harbor_digest": harbor_task_digest(staged),
        "network_adaptation": asdict(adaptation) if adaptation is not None else None,
    }


def _accepted_returned_models(model: str) -> frozenset[str]:
    """Model ids a provider may legitimately echo back for the requested selector."""
    if is_breaker_selfhosted_model(model):
        return frozenset({parse_breaker_selfhosted_model(model)})
    accepted = {model, model.rsplit("/", 1)[-1]}
    if is_mimo_selfhosted_model(model):
        # SGLang echoes its --served-model-name: the selector minus ``selfhosted/``.
        accepted.add(parse_mimo_selfhosted_model(model))
    if is_tinker_terminus_model(model):
        # Tinker echoes the native id it sampled: the selector minus ``tinker/``
        # (observed 2026-10-09 for ``Qwen/Qwen3.6-35B-A3B``). A checkpoint replay
        # accepts only its own checkpoint path, never the base id.
        accepted.add(parse_tinker_model(model).native_model)
    if is_openrouter_model(model):
        # OpenRouter echoes the canonical slug of the endpoint that served
        # the call; the route lists the echoes of its pinned endpoint.
        accepted |= openrouter_route(model).returned_models
    return frozenset(accepted)


def _write_run_metadata(
    request: RunRequest,
    *,
    repo_root: Path,
    command: list[str],
    started: datetime,
    finished: datetime,
    process: HarborProcessResult,
    network_adaptation: NetworkAdaptation | None = None,
    task_staging: dict[str, Any] | None = None,
    toolbox: dict[str, Any] | None = None,
    harness_tree: dict[str, Any] | None = None,
    local_ollama: dict[str, Any] | None = None,
) -> None:
    job_dir = request.jobs_dir / request.name
    if not job_dir.exists():
        return
    metadata: dict[str, Any] = {
        "schema_version": 1,
        "command": command,
        "started_at": started.isoformat(),
        "finished_at": finished.isoformat(),
        "exit_code": process.returncode,
        "timed_out": process.timed_out,
        "timed_out_trial": process.timed_out_trial,
        "trial_timeout_seconds": request.trial_watchdog_seconds,
        "job_timeout_seconds": request.job_timeout_seconds,
        "executor_log": process.log_path.relative_to(request.jobs_dir).as_posix(),
        "host": {
            "platform": platform.platform(),
            "python": sys.version.split()[0],
        },
        "tools": {
            "harbor": tool_version("harbor"),
            "docker": tool_version("docker"),
            "uv": tool_version("uv"),
        },
    }
    if request.subscription_quota is not None:
        metadata["subscription_quota"] = request.subscription_quota
    admission_path = request.jobs_dir / ".executor" / f"{request.name}.daytona-usage.json"
    if request.environment == "daytona" and admission_path.is_file():
        metadata["daytona_admission"] = json.loads(admission_path.read_text(encoding="utf-8"))
    if request.provenance is not None:
        metadata["experiment"] = request.provenance.model_dump(mode="json")
    if request.experiment_spec is not None:
        spec_path = job_dir / "experiment-spec.json"
        persist_private_bytes(
            spec_path,
            (request.experiment_spec.model_dump_json(indent=2) + "\n").encode(),
            secrets=tuple(value.encode() for value in collected_secret_values()),
        )
        metadata["experiment_spec"] = {
            "path": "experiment-spec.json",
            "sha256": "sha256:" + hashlib.sha256(spec_path.read_bytes()).hexdigest(),
        }
    if process.proxy_usage is not None:
        calls = process.proxy_usage.get("calls")
        totals = process.proxy_usage.get("totals", {})
        if isinstance(calls, list) and len(calls) == 0:
            metadata["provider_usage"] = {
                **process.proxy_usage,
                "totals": {
                    **totals,
                    "cost_usd": None,
                    "cost_micros": None,
                    "input_tokens": None,
                    "output_tokens": None,
                    "total_tokens": None,
                },
                "usage_status": "zero_calls",
            }
        else:
            metadata["provider_usage"] = process.proxy_usage
    else:
        metadata["provider_usage"] = {
            "requests": None,
            "input_tokens": None,
            "output_tokens": None,
            "total_tokens": None,
            "cost_usd": None,
            "cost_micros": None,
            "usage_status": "missing",
        }
    # Authoritative per-run spend: ledger usage times the ledger's pinned
    # pricing (evallab.ledger). This wins over Harbor/litellm's own
    # agent_result estimate for proxy-metered trials at catalog ingest; the
    # gate spends used + attempted as a conservative ceiling.
    metadata["cost"] = build_cost_block(process.proxy_usage)
    calls = process.proxy_usage.get("calls") if isinstance(process.proxy_usage, dict) else None
    if isinstance(calls, list) and calls and request.model:
        returned_models: list[str] = [
            str(call["returned_model"])
            for call in calls
            if isinstance(call, dict) and call.get("returned_model")
        ]
        if returned_models:
            accepted = _accepted_returned_models(request.model)
            mismatch = any(m not in accepted for m in returned_models)
            metadata["model_identity"] = {
                "requested": request.model,
                "returned": returned_models[0]
                if len(set(returned_models)) == 1
                else returned_models,
                "matched": not mismatch,
                "mismatch": mismatch,
            }
            if mismatch:
                metadata["model_identity_mismatch"] = True
    if network_adaptation is not None:
        metadata["network_adaptation"] = asdict(network_adaptation)
    if task_staging is not None:
        metadata["task_staging"] = task_staging
    if toolbox is not None:
        metadata["toolbox"] = toolbox
    if harness_tree is not None:
        metadata["harness_tree"] = harness_tree
    from evallab.results_home import capture_repository, write_run_provenance

    repository = capture_repository(repo_root)
    metadata["repository"] = {
        key: value for key, value in repository.items() if not key.startswith("_")
    }
    write_run_provenance(job_dir, repository)
    if local_ollama is not None:
        metadata["local_ollama"] = local_ollama
    capture_binding = _capture_binding_for_metadata(request)
    if capture_binding is not None:
        metadata["model_capture"] = capture_binding
    persist_private_bytes(
        job_dir / "lab-metadata.json",
        (json.dumps(metadata, indent=2, sort_keys=True) + "\n").encode(),
        secrets=tuple(value.encode() for value in collected_secret_values()),
    )


def _network_adaptation_path(request: RunRequest) -> Path:
    return request.jobs_dir / ".executor" / f"{request.name}.network-adaptation.json"


def _write_network_adaptation(
    request: RunRequest,
    adaptation: NetworkAdaptation | None,
) -> None:
    """Persist compact network adaptation metadata outside the staging copy.

    This is written as soon as staging is created so that early build/runtime
    failures still retain the requested and effective modes, adapter version,
    adapter digest, and isolation reason even if the temporary staging copy is
    later deleted.
    """
    if adaptation is None:
        return
    path = _network_adaptation_path(request)
    path.parent.mkdir(parents=True, exist_ok=True)
    manifest = {
        "schema_version": "1.0",
        "network_adaptation": asdict(adaptation),
    }
    temporary = path.with_name(f".{path.name}.tmp")
    try:
        temporary.write_text(
            json.dumps(manifest, indent=2, sort_keys=True, default=str) + "\n",
            encoding="utf-8",
        )
    except Exception:
        with suppress(OSError):
            temporary.unlink()
        raise
    temporary.replace(path)


def _cleanup_stage(staging_dir: Path | None) -> None:
    """Remove the temporary execution copy, including any copied task secrets.

    The compact adaptation metadata has already been persisted to
    ``.executor/<name>.network-adaptation.json`` and, when the run reached the
    metadata step, ``<job-dir>/lab-metadata.json``.
    """
    if staging_dir is not None and staging_dir.is_dir():
        shutil.rmtree(staging_dir)


def _make_snapshot_writable(staging_dir: Path) -> None:
    # Pinned task stores (e.g. `evallab tasks pull-hf` snapshots) are 555/444.
    # copytree preserves those modes. Only the private copy becomes writable;
    # package digests cover bytes, not modes. Never chmod through a symlink.
    for path in (staging_dir, *staging_dir.rglob("*")):
        if not path.is_symlink():
            owner_bits = stat.S_IWUSR | (stat.S_IXUSR if path.is_dir() else 0)
            path.chmod(path.stat().st_mode | owner_bits)


def _stage_task_for_host(
    source: Path,
    staging_dir: Path,
    *,
    agent_allowed_hosts: tuple[str, ...] = (),
    preserve_declared_network: bool = False,
    expected_package_digest: str | None = None,
) -> tuple[Path, NetworkAdaptation | None]:
    """Create and verify a private immutable-input snapshot before adaptation."""
    from evallab.registry import compute_task_digests

    task_toml_path = source / "task.toml"
    if not task_toml_path.is_file():
        raise ValueError(f"task.toml missing in {source}")
    if any(path.is_symlink() for path in source.rglob("*")):
        raise ValueError("task package snapshots reject symlinks")
    source_digest_before = compute_task_digests(source).package
    if expected_package_digest is not None and source_digest_before != expected_package_digest:
        raise ValueError("task package differs from its frozen digest before staging")

    if staging_dir.exists():
        shutil.rmtree(staging_dir)
    staging_dir.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, staging_dir, symlinks=True)
    _make_snapshot_writable(staging_dir)
    if any(path.is_symlink() for path in staging_dir.rglob("*")):
        raise ValueError("staged task snapshot contains a symlink")
    staged_digest = compute_task_digests(staging_dir).package
    source_digest_after = compute_task_digests(source).package
    if staged_digest != source_digest_before or source_digest_after != source_digest_before:
        raise ValueError("task package changed while its execution snapshot was created")

    original_text = (staging_dir / "task.toml").read_text(encoding="utf-8")
    if preserve_declared_network:
        # Host-side model route (Terminus2): the task container never needs
        # model API access, so the declared network/phase policy ships
        # untouched. No controller-OS downgrade is applied and no
        # model-host allowlist is injected; Harbor enforces or refuses the
        # declared policy honestly, including on remote backends where the
        # controller host cannot know the enforcement capability.
        staged_text = original_text
        adaptation = None
    else:
        adapted_text, adaptation = adapt_task_toml_for_host(original_text)
        staged_text = with_agent_network_allowlist(adapted_text, agent_allowed_hosts)
    (staging_dir / "task.toml").write_text(staged_text, encoding="utf-8")
    manifest: dict[str, Any] = {
        "schema_version": "1.0",
        "source_package_digest": source_digest_before,
        "agent_allowed_hosts": list(agent_allowed_hosts),
    }
    if adaptation is not None:
        manifest["network_adaptation"] = asdict(adaptation)
    (staging_dir / "run_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True, default=str) + "\n",
        encoding="utf-8",
    )
    return staging_dir, adaptation


def _sanitize_persisted_job_tree(root: Path, secrets: tuple[bytes, ...]) -> None:
    """Redact then chmod lab-owned persisted streams under a Harbor job directory."""
    if not root.is_dir() or not secrets:
        return
    suffixes = {".log", ".json", ".jsonl", ".txt", ".yaml", ".yml"}
    for path in root.rglob("*"):
        if not path.is_file() or path.is_symlink() or path.suffix.lower() not in suffixes:
            continue
        try:
            data = path.read_bytes()
        except OSError:
            continue
        persist_private_bytes(path, data, secrets=secrets)


def _proxy_trial_limits(request: RunRequest) -> ProxyTrialLimits | None:
    if not uses_provider_proxy(request.agent, request.model):
        return None
    if (
        request.max_requests is None
        or request.max_input_tokens is None
        or request.max_output_tokens is None
        or request.max_total_tokens is None
        or request.cost_limit_usd is None
    ):
        raise ValueError(f"{request.agent} execution requires explicit provider ceilings")
    return ProxyTrialLimits(
        max_requests=request.max_requests,
        max_input_tokens=request.max_input_tokens,
        max_output_tokens=request.max_output_tokens,
        max_total_tokens=request.max_total_tokens,
        max_cost_micros=math.ceil(request.cost_limit_usd * 1_000_000),
    )


def _proxy_attempt_id(request: RunRequest) -> str | None:
    if not uses_provider_proxy(request.agent, request.model):
        return None
    if request.provenance is not None:
        return request.provenance.campaign_attempt_id or request.provenance.spec_id or request.name
    return request.name


def _harness_execution_settings(
    request: RunRequest, local_ollama: dict[str, Any] | None
) -> dict[str, Any]:
    """Keep every non-treatment spec setting comparable across fresh runs."""
    if request.experiment_spec is not None:
        settings = request.experiment_spec.model_dump(
            mode="json",
            exclude={
                "spec_id",
                "name",
                "hypothesis",
                "question_ref",
                "submitted_at",
                "submitted_by",
                "policy_rule",
                "harness_tree_path",
                "harness_tree_sha256",
                "campaign_ledger",
                "campaign_cell_id",
                "campaign_attempt_id",
                "campaign_attempt_index",
                "campaign_manifest_digest",
                "campaign_spec_digest",
                "campaign_evidence_store",
            },
        )
    else:
        fields = (
            "agent",
            "model",
            "environment",
            "attempts",
            "concurrency",
            "timeout_seconds",
            "max_requests",
            "max_input_tokens",
            "max_output_tokens",
            "max_total_tokens",
            "cost_limit_usd",
            "harness_policy",
            "verifier_repeat_n",
            "override_storage_mb",
        )
        settings = {name: getattr(request, name) for name in fields}
    settings["inference_settings"] = (
        request.inference_settings.model_dump(mode="json") if request.inference_settings else None
    )
    settings["extra_instruction_sha256"] = (
        "sha256:" + hashlib.sha256(request.extra_instruction_path.read_bytes()).hexdigest()
        if request.extra_instruction_path is not None
        else None
    )
    settings["toolbox_sha256"] = request.toolbox_sha256
    settings["base_skills"] = list(request.resolved_skills)
    settings["load_trajectory"] = str(request.load_trajectory) if request.load_trajectory else None
    settings["export_traces"] = request.export_traces
    settings["local_ollama"] = local_ollama
    return settings


def _check_daytona_admission(request: RunRequest) -> dict[str, Any] | None:
    if request.environment != "daytona":
        return None
    from evallab.daytona_guard import AdmissionRefused, DaytonaGuard, GuardUnavailable

    try:
        guard = DaytonaGuard()
        with (request.task / "task.toml").open("rb") as handle:
            environment = tomllib.load(handle).get("environment", {})
        observed = guard.observe()
        caps = observed["per_sandbox_limits"]
        cpu = environment.get("cpus")
        memory_mb = environment.get("memory_mb")
        storage_mb = request.override_storage_mb
        if storage_mb is None:
            storage_mb = environment.get("storage_mb")
        resources = {
            "cpu": cpu if cpu is not None else caps["cpu"],
            "memory_gib": (memory_mb + 1023) // 1024
            if memory_mb is not None
            else caps["memory_gib"],
            "disk_gib": (storage_mb + 1023) // 1024 if storage_mb is not None else caps["disk_gib"],
            "gpu": environment.get("gpus") or 0,
        }
        snapshot = guard.check(resources, count=min(request.attempts, request.concurrency))
        snapshot["allocation_basis"] = (
            "declared task resources; omitted dimensions reserve verified per-sandbox maximum"
        )
        return snapshot
    except AdmissionRefused as error:
        raise ExecutionFailure("daytona_usage_limit", str(error)) from error
    except (GuardUnavailable, OSError, ValueError, TypeError, KeyError) as error:
        detail = str(error) if isinstance(error, GuardUnavailable) else type(error).__name__
        raise ExecutionFailure(
            "daytona_usage_unavailable", f"Daytona admission refused: {detail}"
        ) from error


def stage_request_task(
    request: RunRequest, staging_dir: Path
) -> tuple[Path, NetworkAdaptation | None]:
    """Prepare task bytes identically for execution and read-only diff planning."""
    is_zai_openapi = request.agent == "mini-swe-agent" and (
        request.model == ZAI_OPENAPI_MODEL_SELECTOR
        or (request.model is not None and request.model.startswith("zai/"))
    )
    is_host_model = request.agent in {TERMINUS_AGENT, MIMO_AGENT}
    return _stage_task_for_host(
        request.task,
        staging_dir,
        agent_allowed_hosts=(
            ()
            if is_host_model
            else (
                (ZAI_OPENAPI_PROXY_HOST,)
                if is_zai_openapi
                else (
                    (DEEPSEEK_PROXY_HOST,)
                    if request.agent == "mini-swe-agent"
                    else ((ZAI_PROXY_HOST,) if request.agent == ZAI_OPENCODE_AGENT else ())
                )
            )
        ),
        preserve_declared_network=is_host_model or resolve_egress_lock(request),
        expected_package_digest=(
            request.provenance.package_digest if request.provenance is not None else None
        ),
    )


def run_experiment(request: RunRequest, *, repo_root: Path) -> Path:
    validate_request(request, repo_root=repo_root)
    if request.agent in {"mini-swe-agent", ZAI_OPENCODE_AGENT, TERMINUS_AGENT, MIMO_AGENT}:
        decision = preflight_request(request)
        if not decision.proceed:
            raise RuntimeError(f"{request.agent} credential preflight stopped: {decision.reason}")
    harness_refusal = preflight_harness_agent_imports(request, repo_root=repo_root)
    if harness_refusal is not None:
        raise RuntimeError(harness_refusal)
    local_binding = (
        resolve_ollama_binding(TERMINUS_LOCAL_MODEL_SELECTOR)
        if request.agent == TERMINUS_AGENT and request.model == TERMINUS_LOCAL_MODEL_SELECTOR
        else None
    )
    if not shutil.which("harbor"):
        raise RuntimeError("harbor is not installed or not on PATH")

    job_dir = request.jobs_dir / request.name
    if job_dir.exists():
        raise FileExistsError(
            f"Refusing to reuse existing job directory: {job_dir}. Choose a new explicit run name."
        )
    daytona_admission = _check_daytona_admission(request)

    request.jobs_dir.mkdir(parents=True, exist_ok=True)
    staging_dir = request.jobs_dir / ".exec-stage" / request.name
    harness_staging_dir = (
        request.jobs_dir / ".harness-staging" / request.name
        if request.harness_tree_path is not None
        else None
    )
    executor_log = _executor_log_path(request)
    started = datetime.now(UTC)
    try:
        staged_task, adaptation = stage_request_task(request, staging_dir)
        staged_request: RunRequest = replace(request, task=staged_task)
        staged_harness: Path | None = None
        harness_meta: dict[str, Any] | None = None
        if request.harness_tree_path is not None:
            from evallab.terminus_harness import stage_harness_tree

            if request.harness_tree_sha256 is None or harness_staging_dir is None:
                raise ValueError("harness tree requires its content digest")
            staged_harness, harness_meta = stage_harness_tree(
                request.harness_tree_path,
                request.harness_tree_sha256,
                staging_root=harness_staging_dir,
                repo_root=repo_root,
            )
            staged_request = replace(staged_request, harness_tree_path=staged_harness)
            base_request = replace(staged_request, harness_tree_path=None, harness_tree_sha256=None)
            staged_root = staged_harness.resolve()
            harness_meta.update(
                staged_root=staged_root.as_posix(),
                base_agent_kwargs=terminus_agent_kwargs(base_request),
                rendered_agent_kwargs=terminus_agent_kwargs(staged_request),
                rendered_rule_paths=(
                    [(staged_root / harness_meta["rules_path"]).as_posix()]
                    if harness_meta["rules_path"]
                    else []
                ),
                rendered_skill_paths=[
                    (staged_root / relative).as_posix() for relative in harness_meta["skill_roots"]
                ],
                execution_settings=_harness_execution_settings(
                    request, local_binding.to_dict() if local_binding is not None else None
                ),
            )
        staged_toolbox: Path | None = None
        toolbox_meta: dict[str, Any] | None = None
        if request.toolbox_path is not None:
            from evallab.toolbox import stage_toolbox

            staged_toolbox, toolbox_meta = stage_toolbox(
                request.toolbox_path,
                request.toolbox_sha256,
                staging_root=request.jobs_dir / ".toolbox-staging" / request.name,
                repo_root=repo_root,
            )
            staged_request = replace(staged_request, skill=staged_toolbox)

        _write_network_adaptation(request, adaptation)
        if daytona_admission is not None:
            persist_private_bytes(
                request.jobs_dir / ".executor" / f"{request.name}.daytona-usage.json",
                (json.dumps(daytona_admission, indent=2) + "\n").encode(),
                secrets=(),
            )

        from evallab.setup_fingerprint import (
            build_intended_fingerprint,
            lock_setup_fingerprint,
            maybe_write_fingerprints,
        )

        _intended: dict[str, Any] | None = None
        _fingerprint_error: str | None = None
        laminar_metadata: dict[str, Any] | None = None
        if request.agent == MIMO_AGENT and os.environ.get("LMNR_PROJECT_API_KEY"):
            provenance = request.provenance
            laminar_metadata = {
                "card": provenance.linear_card if provenance else None,
                "arm": provenance.arm_id if provenance else None,
                "task": request.task.name,
                "job_name": request.name,
                "intended_setup_fingerprint": None,
                "model_revision": None,
                "model_revision_source": None,
                "intended_lock_mode": None,
                "bearer_pattern": _BEARER_HEADER.pattern.decode("ascii"),
            }
            try:
                _intended = build_intended_fingerprint(
                    spec=request.experiment_spec,
                    task_dir=request.task,
                    model=request.model,
                    agent=request.agent,
                    environment=request.environment,
                    repo_root=repo_root,
                    request=request,
                )
                laminar_metadata.update(
                    {
                        "task": _intended["subject"]["task"],
                        "intended_setup_fingerprint": "sha256:"
                        + hashlib.sha256(
                            json.dumps(_intended, sort_keys=True, separators=(",", ":")).encode()
                        ).hexdigest(),
                        "model_revision": _intended["server"]["model_revision"],
                        "model_revision_source": _intended["server"]["sources"]["model_revision"],
                        "intended_lock_mode": _intended["lock"]["mode"],
                    }
                )
            except Exception as exc:  # fingerprint telemetry cannot fail execution
                _intended = {}
                _fingerprint_error = f"{type(exc).__name__}: {exc}"

        harbor_command = build_command(
            staged_request,
            setup_fingerprint=lock_setup_fingerprint(request, repo_root=repo_root),
            repo_root=repo_root,
        )
        command = subscription_command(staged_request, harbor_command, repo_root=_RUNTIME_ROOT)
        containers_before = (
            frozenset()
            if staged_request.environment in _DAYTONA_ENVIRONMENT_SELECTORS
            else harbor_container_ids(staged_request.task)
        )
        _write_executor_state(
            request,
            started_at=started,
            status="running",
            log_path=executor_log,
        )
        try:
            process = run_harbor_process(
                command,
                cwd=repo_root,
                timeout_seconds=request.job_timeout_seconds,
                log_path=executor_log,
                job_dir=job_dir,
                trial_timeout_seconds=request.trial_watchdog_seconds,
                lease_path=request.lease_path,
                lease_generation=request.lease_generation,
                proxy_attempt_id=_proxy_attempt_id(request),
                proxy_limits=_proxy_trial_limits(request),
                laminar_metadata=laminar_metadata,
                claude_gateway_model=(
                    staged_request.model if is_claude_gateway_model(staged_request.model) else None
                ),
                docker_platform=staged_request.docker_platform,
                include_modal_credentials=staged_request.environment == "modal",
            )
        except BaseException:
            _write_executor_state(
                request,
                started_at=started,
                status="failed",
                log_path=executor_log,
                finished_at=datetime.now(UTC),
            )
            raise
        finished = datetime.now(UTC)
        cancelled = _lease_cancelled_or_lost(
            request.lease_path,
            request.lease_generation,
        )
        _write_executor_state(
            request,
            started_at=started,
            status=(
                "failed" if cancelled or process.timed_out or process.returncode != 0 else "running"
            ),
            log_path=executor_log,
            finished_at=finished,
            process=process,
        )
        if staged_harness is not None and harness_meta is not None:
            from evallab.terminus_harness import retain_harness_tree_evidence

            retain_harness_tree_evidence(job_dir, staged_harness, harness_meta)
        _write_run_metadata(
            request,
            repo_root=repo_root,
            command=command,
            started=started,
            finished=finished,
            process=process,
            network_adaptation=adaptation,
            task_staging=_task_staging_provenance(request.task, staged_task, adaptation),
            toolbox=toolbox_meta,
            harness_tree=harness_meta,
            local_ollama=local_binding.to_dict() if local_binding is not None else None,
        )
        if staged_toolbox is not None and toolbox_meta is not None and job_dir.exists():
            from evallab.toolbox import retain_toolbox_evidence

            retain_toolbox_evidence(job_dir, staged_toolbox, toolbox_meta)
        if cancelled:
            cleanup_failure = _cleanup_failure(staged_request, containers_before, job_dir)
            cleanup_detail = f"; {cleanup_failure}" if cleanup_failure else ""
            raise ExecutionFailure(
                "execution_cancelled",
                f"campaign owner cancelled the active queue lease{cleanup_detail}",
            )

        if process.timed_out:
            cleanup_failure = _cleanup_failure(staged_request, containers_before, job_dir)
            scope = (
                f"trial {process.timed_out_trial!r} exceeded {request.timeout_seconds}s"
                if process.timed_out_trial is not None
                else f"Harbor exceeded aggregate fail-safe {request.job_timeout_seconds}s"
            )
            cleanup_detail = f"; {cleanup_failure}" if cleanup_failure else ""
            timeout_exc = TrialTimeoutFailure(f"{scope}; inspect {executor_log}{cleanup_detail}")
            timeout_exc.timed_out_trial = process.timed_out_trial
            raise timeout_exc
        secret_values = collected_secret_values()
        assert_no_secret_material((job_dir,), secrets=secret_values)
        _sanitize_persisted_job_tree(
            job_dir,
            tuple(value.encode() for value in secret_values),
        )
        transient_reason = _transient_reason_from_job(job_dir)
        if process.returncode != 0:
            cleanup_failure = _cleanup_failure(staged_request, containers_before, job_dir)
            cleanup_detail = f"; {cleanup_failure}" if cleanup_failure else ""
            if transient_reason is not None:
                raise TransientHarnessFailure(
                    transient_reason,
                    message=transient_reason + cleanup_detail,
                )
            raise ExecutionFailure(
                f"Harbor exited with {process.returncode}; inspect {executor_log}{cleanup_detail}"
            )
        if uses_provider_proxy(request.agent, request.model):
            provider_label = (
                "Mimo self-hosted"
                if is_mimo_selfhosted_model(request.model)
                else (
                    "Tinker"
                    if is_tinker_terminus_model(request.model)
                    else (
                        "Z.ai OpenAPI"
                        if (
                            request.agent in {TERMINUS_AGENT, MIMO_AGENT}
                            or (
                                request.agent == "mini-swe-agent"
                                and request.model is not None
                                and request.model.startswith("zai/")
                            )
                        )
                        else ("Z.ai" if request.agent == ZAI_OPENCODE_AGENT else "DeepSeek")
                    )
                )
            )
            if is_breaker_selfhosted_model(request.model):
                provider_label = "Breaker self-hosted"
            if process.proxy_usage is None:
                cleanup_failure = _cleanup_failure(staged_request, containers_before, job_dir)
                cleanup_detail = f"; {cleanup_failure}" if cleanup_failure else ""
                raise ExecutionFailure(
                    "proxy_usage_missing",
                    f"{provider_label} proxy usage report is missing{cleanup_detail}",
                )
            if process.proxy_usage.get("unresolved_requests") != 0:
                cleanup_failure = _cleanup_failure(staged_request, containers_before, job_dir)
                cleanup_detail = f"; {cleanup_failure}" if cleanup_failure else ""
                raise ExecutionFailure(
                    "proxy_usage_unreconciled",
                    f"{provider_label} proxy has unreconciled provider calls{cleanup_detail}",
                )
        job = load_job(job_dir)
        # Setup fingerprint into the batch and every trial (HAR-149): the
        # intended setup plus the per-trial observed lock. Best-effort: the
        # trial already ran, so a persistence failure is recorded, not raised.
        if _intended is None:
            try:
                _intended = build_intended_fingerprint(
                    spec=request.experiment_spec,
                    task_dir=request.task,
                    model=request.model,
                    agent=request.agent,
                    environment=request.environment,
                    repo_root=repo_root,
                    request=request,
                )
            except Exception as exc:  # fingerprint persistence cannot fail a run
                _intended = {}
                _fingerprint_error = f"{type(exc).__name__}: {exc}"
        if _intended:
            _fingerprint_error = maybe_write_fingerprints(job_dir, _intended)
        if _fingerprint_error is not None:
            with suppress(Exception):
                (job_dir / "setup-fingerprint-error.txt").write_text(
                    f"{_fingerprint_error}\n", encoding="utf-8"
                )

        # Validate trial outcomes and evidence fidelity:
        metadata_path = job_dir / JOB_METADATA_PATH
        for trial in getattr(job, "trials", ()):
            native_traj = trial.path / TRIAL_NATIVE_TRAJECTORY_PATH
            atif_traj = trial.path / TRIAL_ATIF_TRAJECTORY_PATH
            traj_path = (
                native_traj
                if native_traj.is_file()
                else (atif_traj if atif_traj.is_file() else None)
            )

            if traj_path is not None:
                try:
                    json.loads(traj_path.read_text(encoding="utf-8"))
                except (json.JSONDecodeError, UnicodeDecodeError) as parse_err:
                    if metadata_path.is_file():
                        try:
                            meta = json.loads(metadata_path.read_text(encoding="utf-8"))
                            meta["trajectory_parse_failure"] = {
                                "trial": trial.path.name,
                                "path": str(traj_path.relative_to(job_dir)),
                                "error": str(parse_err),
                            }
                            meta["trajectory_status"] = "parse_failure"
                            persist_private_bytes(
                                metadata_path,
                                (json.dumps(meta, indent=2, sort_keys=True) + "\n").encode(),
                                secrets=tuple(v.encode() for v in collected_secret_values()),
                            )
                        except Exception:
                            pass
                    cleanup_failure = _cleanup_failure(staged_request, containers_before, job_dir)
                    cleanup_detail = f"; {cleanup_failure}" if cleanup_failure else ""
                    raise ExecutionFailure(
                        "trajectory_parse_failure",
                        f"Trial {trial.path.name} trajectory at {traj_path.name} is malformed: {parse_err}{cleanup_detail}",
                    ) from parse_err

            agent_res = (
                trial.result.get("agent_result")
                if isinstance(trial.result.get("agent_result"), dict)
                else {}
            )
            exit_code = agent_res.get("exit_code")
            if exit_code is None:
                exit_code = trial.result.get("exit_code")
            if exit_code is not None and exit_code != 0 and traj_path is None:
                cleanup_failure = _cleanup_failure(staged_request, containers_before, job_dir)
                cleanup_detail = f"; {cleanup_failure}" if cleanup_failure else ""
                raise ExecutionFailure(
                    "agent_nonzero_exit",
                    f"Trial {trial.path.name} agent exited with code {exit_code} without trajectory; no reward fabricated{cleanup_detail}",
                )

        if metadata_path.is_file():
            try:
                meta = json.loads(metadata_path.read_text(encoding="utf-8"))
                if meta.get("model_identity_mismatch"):
                    identity = meta.get("model_identity", {})
                    cleanup_failure = _cleanup_failure(staged_request, containers_before, job_dir)
                    cleanup_detail = f"; {cleanup_failure}" if cleanup_failure else ""
                    raise ExecutionFailure(
                        "model_identity_mismatch",
                        f"Provider returned model {identity.get('returned')!r} does not match requested {identity.get('requested')!r}{cleanup_detail}",
                    )
            except (ExecutionFailure, TransientHarnessFailure, TrialTimeoutFailure):
                raise
            except Exception:
                pass
        _write_executor_state(
            request,
            started_at=started,
            status="failed" if transient_reason is not None else "completed",
            log_path=executor_log,
            finished_at=finished,
            process=process,
        )
        if transient_reason is not None:
            cleanup_failure = _cleanup_failure(staged_request, containers_before, job_dir)
            cleanup_detail = f"; {cleanup_failure}" if cleanup_failure else ""
            raise TransientHarnessFailure(
                transient_reason,
                message=transient_reason + cleanup_detail,
            )
        # Independent-capture auto-link (HAR-145): each job links to its own
        # capture file via route token/session/chaining. Best-effort: the
        # round's final ``capture link`` per job remains the backstop, and a
        # link failure is recorded beside the job and never fails the run.
        try:
            capture_receipt = maybe_link_capture(job_dir)
            if capture_receipt is not None:
                with suppress(Exception):
                    _record_capture_link(job_dir, capture_receipt)
            elif capture_dir_from_environment() is not None:
                with suppress(Exception):
                    (job_dir / "capture-link-error.txt").write_text(
                        "auto-link returned no receipt; "
                        "run `evallab capture link <capture_dir> <job_dir>` by hand\n",
                        encoding="utf-8",
                    )
        except Exception:
            pass
        evidence_root = os.environ.get("EVALLAB_EVIDENCE_STORE_ROOT")
        if evidence_root:
            try:
                from evallab.evidence_store import archive_evidence

                archive_evidence(
                    job_dir,
                    Path(evidence_root),
                    record_id=str(job.id),
                    kind="job",
                )
            except Exception as exc:
                with suppress(Exception):
                    (job_dir / "evidence-archive-error.txt").write_text(
                        f"{type(exc).__name__}: {exc}\n"
                    )
        if os.environ.get("EVALLAB_NO_PROCESS_JOB") != "1":
            # Automatic post-finalize processing (HAR-107): ingest, detectors,
            # run/job reports under <job>/processed/. Best-effort: a processing
            # failure is recorded beside the job and never fails the run.
            try:
                from evallab.process_job import process_job

                process_job(job_dir, root=repo_root)
            except Exception as exc:  # noqa: BLE001
                with suppress(Exception):
                    (job_dir / "process-job-error.txt").write_text(f"{type(exc).__name__}: {exc}\n")
        return job_dir
    finally:
        _cleanup_stage(staging_dir)
        _cleanup_stage(harness_staging_dir)


def load_matrix(path: Path) -> ExperimentMatrix:
    try:
        return ExperimentMatrix.model_validate_json(path.read_text())
    except (OSError, ValidationError) as exc:
        raise ValueError(f"Invalid experiment matrix {path}: {exc}") from exc


def _pin_task_platform(task_dir: Path, platform: str) -> None:
    """Pin a staged execution copy to ``platform``. Never call this on an answer-key package."""
    if not re.fullmatch(r"linux/[a-z0-9_]+", platform):
        raise ValueError(f"unsupported docker platform {platform!r}")
    environment = task_dir / "environment"
    environment.mkdir(parents=True, exist_ok=True)
    compose = environment / "docker-compose.yaml"
    alternate = environment / "docker-compose.yml"
    target = compose if compose.exists() or not alternate.exists() else alternate
    if not target.exists():
        target.write_text(
            f"services:\n  main:\n    platform: {platform}\n",
            encoding="utf-8",
        )
    elif "platform:" not in target.read_text(encoding="utf-8"):
        raise ValueError(
            f"{target} exists without a platform pin; refusing to rewrite an authored compose file"
        )
    for relative in ("environment/Dockerfile", "tests/Dockerfile"):
        dockerfile = task_dir / relative
        if not dockerfile.is_file():
            continue
        original = dockerfile.read_text(encoding="utf-8")
        pinned = re.sub(
            r"^(FROM)(?!\s+--platform=)(\s+)",
            rf"\1 --platform={platform}\2",
            original,
            flags=re.MULTILINE,
        )
        if pinned != original:
            dockerfile.write_text(pinned, encoding="utf-8")


def request_from_matrix(matrix: ExperimentMatrix, run: MatrixRun, *, repo_root: Path) -> RunRequest:
    return RunRequest(
        task=(repo_root / matrix.task).resolve(),
        agent=run.agent,
        name=run.name,
        jobs_dir=(repo_root / matrix.jobs_dir).resolve(),
        environment=matrix.environment,
        modal_app_name=matrix.modal_app_name,
        modal_resource_policy=matrix.modal_resource_policy,
        modal_sandbox_timeout_seconds=matrix.modal_sandbox_timeout_seconds,
        modal_sandbox_create_max_attempts=matrix.modal_sandbox_create_max_attempts,
        docker_platform=matrix.docker_platform,
        model=run.model,
        concurrency=matrix.concurrency,
        attempts=run.attempts,
        timeout_seconds=matrix.timeout_seconds,
        allow_billable=run.allow_billable,
    )


@contextmanager
def staged_matrix_request(
    matrix: ExperimentMatrix, run: MatrixRun, *, repo_root: Path
) -> Iterator[tuple[RunRequest, dict[str, str]]]:
    """Keep a solution-control snapshot alive only for the duration of its run.

    A requested ``docker_platform`` is applied only to that snapshot. The
    answer-key package bytes stay unchanged.
    """
    from evallab.registry import compute_task_digests

    request = request_from_matrix(matrix, run, repo_root=repo_root)
    platform = matrix.docker_platform
    if platform and matrix.environment != "docker":
        raise ValueError("docker_platform applies only to environment='docker'")
    if run.solution is None and not platform:
        yield request, {}
        return

    script: bytes | None = None
    source = request.task
    if run.solution is not None:
        relative = Path(run.solution)
        solution = (repo_root / relative).resolve()
        if relative.is_absolute() or not solution.is_relative_to(repo_root.resolve()):
            raise ValueError(
                "matrix solution must be a repo-root-relative path inside the repository"
            )
        if not solution.is_file():
            raise ValueError(f"matrix solution is not a regular file: {run.solution}")
        script = solution.read_bytes()
        task_config = tomllib.loads((source / "task.toml").read_text())
        if task_config.get("steps"):
            raise ValueError(
                "matrix solution overrides do not support declared task steps; "
                "the override contract selects only root solution/solve.sh"
            )
    with tempfile.TemporaryDirectory(prefix="evallab-matrix-") as temporary:
        staged = Path(temporary) / source.name
        shutil.copytree(
            source,
            staged,
            symlinks=True,
            ignore=lambda directory, names: (
                {"controls"} if Path(directory) == source and "controls" in names else set()
            ),
        )
        if any(path.is_symlink() for path in staged.rglob("*")):
            raise ValueError("task package snapshots reject symlinks")
        _make_snapshot_writable(staged)
        if script is not None:
            solve = staged / "solution" / "solve.sh"
            solve.parent.mkdir(parents=True, exist_ok=True)
            solve.write_bytes(script)
            solve.chmod(0o755)
        if platform:
            _pin_task_platform(staged, platform)
        provenance = {"staged_task_digest": compute_task_digests(staged).package}
        if script is not None:
            provenance["solution_sha256"] = hashlib.sha256(script).hexdigest()
        if platform:
            provenance["docker_platform"] = platform
        yield replace(request, task=staged), provenance


def matrix_run_outcome(job: JobRecord, run: MatrixRun) -> dict[str, Any]:
    """Never count harness failures or absent/non-finite rewards as negative controls."""
    if job.result.get("exception_info") or len(job.trials) != run.attempts:
        return {"status": "infra", "rewards": [], "error": "job exception or trial count mismatch"}
    rewards: list[float] = []
    for trial in job.trials:
        if run.agent == "oracle":
            # Harbor 0.21/0.22 writes exit-code.txt only on nonzero script exit;
            # a successful Harbor process and reward zero do not establish setup.
            exit_path = trial.path / "agent" / "exit-code.txt"
            try:
                exit_code = int(exit_path.read_text()) if exit_path.exists() else None
            except (OSError, ValueError):
                return {
                    "status": "infra",
                    "rewards": [],
                    "error": f"trial {trial.path.name} has unreadable oracle exit evidence",
                }
            if exit_code is not None and exit_code != 0:
                return {
                    "status": "infra",
                    "rewards": [],
                    "error": f"trial {trial.path.name} oracle script exited {exit_code}",
                }
            phases = trial.result.get("step_results") or [trial.result]
            if not (trial.path / "agent" / "oracle.txt").is_file() or any(
                phase.get("exception_info")
                or not (phase.get("agent_execution") or {}).get("started_at")
                or not (phase.get("agent_execution") or {}).get("finished_at")
                for phase in phases
            ):
                return {
                    "status": "infra",
                    "rewards": [],
                    "error": f"trial {trial.path.name} has no completed oracle execution evidence",
                }
        reward = trial.primary_reward
        raw = (trial.result.get("verifier_result") or {}).get("rewards") or {}
        if (
            trial.result.get("exception_info")
            or not trial.result.get("finished_at")
            or isinstance(raw.get("reward"), bool)
            or reward is None
            or not math.isfinite(reward)
        ):
            return {
                "status": "infra",
                "rewards": [],
                "error": f"trial {trial.path.name} has an exception or no valid reward",
            }
        rewards.append(reward)
    expected = expected_primary_reward(run)
    mismatch = expected is not None and any(reward != expected for reward in rewards)
    return {"status": "mismatch" if mismatch else "ok", "rewards": rewards, "error": None}


def expected_primary_reward(run: MatrixRun) -> float | None:
    return run.expect_reward


@dataclass(frozen=True)
class MatrixExecution:
    """Observed result of one matrix invocation; receipts stay the evidence."""

    exit_code: int
    results: list[dict[str, Any]]
    completed: list[JobRecord]
    receipt_path: Path
    invocation_path: Path


def run_matrix(
    matrix: ExperimentMatrix,
    *,
    root: Path,
    reuse_existing: bool = False,
    harbor: Any | None = None,
) -> MatrixExecution:
    """Run every control in a matrix through the free local direct path.

    Moved here from ``cli._matrix_command`` so a second caller (the
    reward-hacking audit) requests the *same* execution instead of a parallel
    implementation. Execution stays model-free and un-gated: matrices are
    structurally incapable of spending (``Executor.execute_direct`` refuses any
    agent outside ``CONTROL_AGENTS``, consults no policy gate and writes no
    queue state), which is why they need no approval of their own.
    """
    completed: list[JobRecord] = []
    results: list[dict[str, Any]] = []
    receipt_path = root / Path(matrix.jobs_dir) / ".executor" / f"{matrix.matrix_id}.matrix.json"
    invocation_path = receipt_path.with_suffix(".invocations.jsonl")
    saved_receipt: dict[str, Any] = {"matrix": matrix.model_dump(mode="json"), "results": []}
    if receipt_path.is_file():
        saved_receipt = json.loads(receipt_path.read_text())
    previous = {result["name"]: result for result in saved_receipt.get("results", [])}
    saved_results = dict(previous)
    if harbor is not None:
        executor = None
    else:
        from evallab.queue import Executor

        executor = Executor.from_repo(root)
    for run in matrix.runs:
        result: dict[str, Any] = {"name": run.name, "expect_reward": run.expect_reward}
        try:
            with staged_matrix_request(matrix, run, repo_root=root) as (request, provenance):
                result.update(provenance)
                job_dir = request.jobs_dir / request.name
                if reuse_existing and job_dir.is_dir():
                    prior = previous.get(run.name, {})
                    keys = ("solution_sha256", "staged_task_digest")
                    if (
                        any(prior.get(key) != provenance.get(key) for key in keys)
                        or prior.get("status") == "infra"
                    ):
                        raise ValueError(
                            "existing job has no matching successful control provenance"
                        )
                    state_path = executor_state_path(request)
                    if state_path.is_file():
                        state = json.loads(state_path.read_text())
                        if state.get("status") != "completed" or state.get("exit_code", 0) != 0:
                            raise ValueError(
                                "existing job has a failed or incomplete Harbor execution"
                            )
                elif job_dir.exists():
                    raise FileExistsError(
                        f"Refusing to reuse existing job directory: {job_dir}. "
                        "Use --reuse-existing to validate its evidence."
                    )
                elif harbor is not None:
                    if request.agent not in {"oracle", "nop"}:
                        raise ValueError("direct execution is restricted to oracle/nop")
                    from evallab.fetch import ControlCall

                    harbor.run_control(
                        ControlCall(
                            task_path=request.task,
                            agent=request.agent,
                            job_name=request.name,
                            jobs_dir=request.jobs_dir,
                            n_concurrent=request.concurrency,
                            n_attempts=request.attempts,
                        )
                    )
                else:
                    assert executor is not None
                    job_dir = executor.execute_direct(request)
                job = load_job(job_dir)
                result.update(matrix_run_outcome(job, run))
                if result["status"] != "infra":
                    completed.append(job)
        except Exception as exc:
            result.update(status="infra", rewards=[], error=f"{type(exc).__name__}: {exc}")
        results.append(result)
        status = result["status"]
        detail = result["error"] or f"expected {run.expect_reward}, got {result['rewards']}"
        print(
            f"{run.name}: {status} ({detail})",
            file=sys.stdout if status == "ok" else sys.stderr,
        )
        receipt_path.parent.mkdir(parents=True, exist_ok=True)
        # The job receipt is evidence, not the status of the latest invocation.
        # Refusing a rerun must not erase the binding used by --reuse-existing.
        if saved_results.get(run.name, {}).get("status") not in {"ok", "mismatch"}:
            saved_results[run.name] = result
            saved_receipt["results"] = list(saved_results.values())
            receipt_path.write_text(json.dumps(saved_receipt, indent=2) + "\n")
        with invocation_path.open("a") as stream:
            stream.write(
                json.dumps(
                    {
                        "recorded_at": datetime.now(UTC).isoformat(),
                        "matrix": matrix.model_dump(mode="json"),
                        "reuse_existing": reuse_existing,
                        "result": result,
                    }
                )
                + "\n"
            )
    return MatrixExecution(
        exit_code=1 if any(result["status"] != "ok" for result in results) else 0,
        results=results,
        completed=completed,
        receipt_path=receipt_path,
        invocation_path=invocation_path,
    )


def database_url_from_environment(explicit: str | None = None) -> str:
    return explicit or os.environ.get(
        "DATABASE_URL",
        "postgresql://evallab:local-development-only@localhost:54329/evallab",
    )


# ---------------------------------------------------------------------------
# M003: profile-aware preflight (additive; wiring into the queue is a later
# integrator change). An auth failure here stops before any trial exists —
# it can never be recorded as a reward.
# ---------------------------------------------------------------------------

if TYPE_CHECKING:
    from evallab.profiles import AgentProfile, PreflightDecision, ProbeFn


def profile_for_request(request: RunRequest) -> AgentProfile:
    """Resolve the immutable profile for a request's agent (+ optional model).

    Raises ValueError when no profile matches or the requested model differs
    from the profile's pin — change profiles, not pins.
    """
    from evallab import profiles as profiles_module

    registry = profiles_module.builtin_profiles()
    candidates = [p for p in registry.values() if p.adapter == request.agent]
    if not candidates:
        raise ValueError(f"no profile declared for agent {request.agent!r}")
    if request.model is not None:
        for profile in candidates:
            if profile.model == request.model:
                return profile
        # Fine-tuned weights on a pinned base (Tinker checkpoint, admitted
        # self-hosted LoRA adapter) inherit the base model's profile.
        pinned = profiles_module.pinned_model(request.model)
        for profile in candidates:
            if profile.model == pinned:
                return profile
        raise ValueError(
            f"no profile pins model {request.model!r} for agent {request.agent!r}; "
            "add a profile instead of overriding a pin"
        )
    return candidates[0]


def preflight_request(
    request: RunRequest,
    *,
    probe: ProbeFn | None = None,
    home: Path | None = None,
) -> PreflightDecision:
    """Fail-closed credential preflight for one request.

    Control agents pass with no credential. Billable profiles require a
    passing probe; a missing or failing probe blocks dispatch with a reason
    and no trial is started (auth failure never becomes reward zero).
    """
    from evallab import profiles as profiles_module

    profile = profile_for_request(request)
    profiles_module.validate_model_pin(profile, request.model)
    if probe is None and profile.auth_mode != "none":
        env = subscription_environment()
        probe = profiles_module.default_probe_for(
            profile,
            home=home or Path.home(),
            security_runner=_security_status,
            keychain_account=env.get("HARBOR_CLAUDE_KEYCHAIN_ACCOUNT", env.get("USER", "")),
        )
    return profiles_module.preflight(profile, probe)


# ---------------------------------------------------------------------------
# HAR-126 G0: harness agent-import preflight. HAR-116 wave A burned its
# dispatch on an agent-side import (ModuleNotFoundError: duckdb) that failed
# inside Harbor's tool venv, which never had the package. When a spec's
# harness tree enables lab agent knobs, the trial loads lab adapter code in
# that venv — so dispatch first proves the import works there, before any
# sandbox or Modal spend. Runs once per spec, only when knobs are on.
# ---------------------------------------------------------------------------

#: Harness-tree knobs whose code executes inside Harbor's tool venv at trial
#: time. A tree enabling any of them opts into the import preflight.
LAB_AGENT_KNOB_KEYS = ("loop_break", "output_cap_chars", "completion_fix")

#: The adapter plus the live closure the loop break and completion fix run:
#: exactly the import chain that died as ModuleNotFoundError in wave A.
HARBOR_AGENT_PROBE_IMPORTS = (
    "evallab.harbor_terminus",
    "evallab.loopfix",
    "evallab.token_flow",
    "evallab.edit_signals",
    "evallab.mimo_tool_calls",
)

#: Env override for the Harbor tool python (tests point it at a fake).
HARBOR_PYTHON_ENV = "EVALLAB_HARBOR_PYTHON"


def _harbor_tool_python() -> Path | None:
    """Harbor's tool-venv python, the interpreter trial agents run in."""
    override = os.environ.get(HARBOR_PYTHON_ENV)
    if override:
        candidate = Path(override)
        return candidate if candidate.exists() else None
    harbor = shutil.which("harbor")
    if not harbor:
        return None
    candidate = Path(harbor).resolve().parent / "python"
    return candidate if candidate.exists() else None


def preflight_harness_agent_imports(
    request: RunRequest,
    *,
    repo_root: Path,
    python: Path | None = None,
) -> str | None:
    """Refusal reason, or None when the spec may dispatch.

    Only harness-tree terminus-2 specs enabling lab agent knobs pay for this:
    one subprocess running Harbor's python with the lab ``src`` on its path,
    importing the agent modules the trial will load. Anything else returns
    None without spawning anything.
    """
    if request.agent != TERMINUS_AGENT or request.harness_tree_path is None:
        return None
    from evallab.terminus_harness import load_harness_tree

    tree = load_harness_tree(request.harness_tree_path, request.harness_tree_sha256)
    enabled = sorted(key for key in LAB_AGENT_KNOB_KEYS if tree.config.get(key))
    if not enabled:
        return None
    exe = Path(python) if python is not None else _harbor_tool_python()
    if exe is None or not exe.exists():
        return (
            f"refusing {request.name}: harness tree enables lab agent knobs "
            f"({', '.join(enabled)}) but Harbor's python is unavailable, so the "
            "trial's agent import cannot be proven before dispatch"
        )
    env = dict(os.environ)
    src = str(Path(repo_root) / "src")
    env["PYTHONPATH"] = src + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    try:
        completed = subprocess.run(
            [str(exe), "-c", "import " + ", ".join(HARBOR_AGENT_PROBE_IMPORTS)],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            timeout=60,
            cwd=repo_root,
            env=env,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        return (
            f"refusing {request.name}: harness tree enables lab agent knobs "
            f"({', '.join(enabled)}) but the agent-import probe could not run "
            f"({exe}: {exc})"
        )
    if completed.returncode != 0:
        detail = (completed.stderr or "").strip().splitlines()
        tail = " ".join(detail[-3:])[:500] or f"exit {completed.returncode}"
        return (
            f"refusing {request.name}: harness tree enables lab agent knobs "
            f"({', '.join(enabled)}) but Harbor's python cannot import the trial "
            f"agent modules ({tail}) — fix the agent closure before dispatch; "
            "no sandbox or Modal spend happened"
        )
    return None


def _security_status(args: list[str]) -> int:
    """Existence check via /usr/bin/security; output discarded unread."""
    completed = subprocess.run(
        ["/usr/bin/security", *args],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=10,
        env=subscription_environment(),
    )
    return completed.returncode

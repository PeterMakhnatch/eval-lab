"""Round inputs: the 33 v7.1 held-out packages, digests and production source allowlists.

Allowlist = non-test production files touched by the reference patch (paths only; the
reference content never enters a seeker prompt). Wave2 source contexts are reused where
they exist (13 tasks); the rest are exported read-only after the package healthcheck.
"""
from pathlib import Path
import base64, hashlib, json, re, sys
from evallab.registry import task_directory_digest

HERE = Path(__file__).resolve().parent
V71 = Path('/Users/petermakhnatch/Developer/research-context/bridge/2026-10-19-night/heldout-v7.1.json')
WAVE2 = Path('/Users/petermakhnatch/Developer/eval-lab/.worktrees/qa-task-v7-wave2-20261018/runs/.qa-task/v7-wave2-source-context-20261018')
TESTY = re.compile(r'(^|/)(tests?|testing)(/|$)|(^|/)test_[^/]*$|_test\.py$|conftest\.py$')


def reference_patch(package: Path) -> str:
    solve = (package / 'solution/solve.sh').read_text()
    blobs = re.findall(r'echo "([A-Za-z0-9+/=]{40,})"', solve)
    return ''.join(base64.b64decode(b).decode('utf-8', 'replace') for b in blobs)


def main() -> None:
    manifest = json.loads(V71.read_text())
    cases = []
    for task in manifest['tasks']:
        target = task['evaluation_target']
        package = Path(target['package_path'])
        digest = task_directory_digest(package)
        if digest != target['package_digest']:
            raise SystemExit(f"digest mismatch {task['task_id']}: {digest}")
        short = task['task_id'].rsplit('-', 1)[-1]
        ref = reference_patch(package)
        ref_paths = sorted(set(re.findall(r'^diff --git a/(\S+) b/', ref, re.M)))
        allow = [p for p in ref_paths if p.endswith('.py') and not TESTY.search(p)]
        wave2 = WAVE2 / short / ('source-context-resolved.json' if short == '001425' else 'source-context.json')
        cases.append({
            'task_id': task['task_id'], 'short': short,
            'version_column': target.get('version_column'),
            'successor_selection': task.get('successor_selection'),
            'package_path': str(package), 'package_digest': digest,
            'verifier_digest': target.get('verifier_digest'),
            'reference_paths': ref_paths, 'allowed_production_paths': allow,
            'wave2_context': str(wave2) if wave2.is_file() else None,
            'wave2_context_sha256': hashlib.sha256(wave2.read_bytes()).hexdigest() if wave2.is_file() else None,
        })
    out = {'schema': 'hardening.round-inputs/v1', 'source_manifest': str(V71),
           'source_manifest_sha256': hashlib.sha256(V71.read_bytes()).hexdigest(), 'cases': cases}
    (HERE / 'inputs.json').write_text(json.dumps(out, indent=2, sort_keys=True) + '\n')
    for c in cases:
        print(c['short'], c['version_column'], bool(c['wave2_context']), c['allowed_production_paths'])


if __name__ == '__main__':
    main()

"""Modal native-Harbor lane for fixer probes and qualification (EnvCheck's $1.00 share).

One persistent reservation ledger across processes. Every environment start reserves
MODAL_RESERVATIONS_PER_ENVIRONMENT x USD_PER_EXECUTION (a separate verifier reserves again),
as in evallab.qa.task_modal. Reservations are estimates, not bills.
"""
from contextlib import contextmanager
from pathlib import Path
import fcntl, json

from evallab.regrade import CloudSpendGate

HERE = Path(__file__).resolve().parent
LEDGER = HERE / 'modal-ledger.json'
CAP_USD = 1.00
# 2 CPU / 8 GiB sandbox for ~5 minutes at Modal list prices is about $0.013; one reservation
# unit is $0.005 and each start reserves three units, so one start reserves $0.015.
USD_PER_EXECUTION = 0.005
APPROVAL = "Main 2026-10-19 deep Track A: EnvCheck's remaining Modal share, $1.00 cap, fixer probes/qualification"


@contextmanager
def gate():
    with (HERE / 'modal-ledger.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        prior = json.loads(LEDGER.read_text())['executions'] if LEDGER.exists() else 0
        spend = CloudSpendGate(approval=APPROVAL, cap_usd=CAP_USD, usd_per_execution=USD_PER_EXECUTION, executions=prior)
        try:
            yield spend
        finally:
            LEDGER.write_text(json.dumps({**spend.to_json(), 'note': 'reservations, not bills'}, indent=2) + '\n')


def backend(spend):
    from evallab.qa.task_modal import ModalBackend
    return ModalBackend(repo_root=HERE.parents[1], spend_gate=spend)
